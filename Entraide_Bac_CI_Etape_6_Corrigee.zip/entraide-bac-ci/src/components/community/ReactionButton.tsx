"use client";

import { ThumbsUp } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

export function ReactionButton({ postId, initialCount, initialActive, loggedIn }: { postId: string; initialCount: number; initialActive: boolean; loggedIn: boolean }) {
  const router = useRouter();
  const [active, setActive] = useState(initialActive);
  const [count, setCount] = useState(initialCount);
  const [pending, setPending] = useState(false);

  async function toggle() {
    if (!loggedIn) {
      router.push(`/connexion?redirige=${encodeURIComponent(`/communaute/${postId}`)}`);
      return;
    }
    setPending(true);
    const supabase = createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) {
      setPending(false);
      return;
    }
    const next = !active;
    setActive(next);
    setCount((c) => c + (next ? 1 : -1));
    const { error } = next
      ? await supabase.from("post_reactions").insert({ user_id: user.id, post_id: postId })
      : await supabase.from("post_reactions").delete().eq("user_id", user.id).eq("post_id", postId);
    if (error) {
      setActive(!next);
      setCount((c) => c + (next ? -1 : 1));
    }
    setPending(false);
  }

  return (
    <button
      type="button"
      onClick={toggle}
      disabled={pending}
      aria-pressed={active}
      className={`btn border ${active ? "border-brand bg-brand/10 text-brand" : "border-line text-ink-soft hover:border-brand hover:text-brand"} disabled:opacity-60`}
    >
      <ThumbsUp size={17} className={active ? "fill-current" : ""} /> Utile · {count}
    </button>
  );
}
