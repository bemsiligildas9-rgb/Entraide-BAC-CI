"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { addComment } from "@/app/communaute/actions";
import { FormMessage } from "../auth/Field";

export function CommentForm({ postId }: { postId: string }) {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    setError(null);
    setPending(true);
    const r = await addComment({ postId, body: String(new FormData(form).get("body") ?? "") });
    setPending(false);
    if (!r.ok) return setError(r.error);
    form.reset();
    router.refresh();
  }

  return (
    <form onSubmit={onSubmit} className="space-y-3">
      <label htmlFor="body" className="block text-sm font-semibold">Ta réponse ou ton commentaire</label>
      <textarea id="body" name="body" rows={4} maxLength={5000} className="input py-2.5" required />
      {error ? <FormMessage kind="error">{error}</FormMessage> : null}
      <button type="submit" disabled={pending} className="btn-primary disabled:opacity-60">{pending ? "Envoi…" : "Publier ma réponse"}</button>
    </form>
  );
}
