"use client";

import { Flag } from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import { reportContent } from "@/app/communaute/actions";
import { FormMessage } from "../auth/Field";

export function ReportButton({ postId, commentId, loggedIn }: { postId?: string; commentId?: string; loggedIn: boolean }) {
  const [open, setOpen] = useState(false);
  const [msg, setMsg] = useState<{ kind: "error" | "success"; text: string } | null>(null);
  const [pending, setPending] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setPending(true);
    const reason = String(new FormData(e.currentTarget).get("reason") ?? "");
    const r = await reportContent({ postId, commentId, reason });
    setPending(false);
    if (r.ok) {
      setMsg({ kind: "success", text: r.message ?? "Signalement envoyé." });
      setOpen(false);
    } else {
      setMsg({ kind: "error", text: r.error });
    }
  }

  if (!loggedIn) {
    return (
      <Link href="/connexion" className="inline-flex min-h-[40px] items-center gap-1.5 text-sm text-ink-soft hover:text-brand">
        <Flag size={15} /> Signaler
      </Link>
    );
  }

  return (
    <div>
      <button type="button" onClick={() => setOpen((o) => !o)} aria-expanded={open} className="inline-flex min-h-[40px] items-center gap-1.5 text-sm text-ink-soft hover:text-brand">
        <Flag size={15} /> Signaler
      </button>
      {open ? (
        <form onSubmit={onSubmit} className="mt-2 max-w-md space-y-2">
          <label htmlFor={`reason-${postId ?? commentId}`} className="block text-sm font-semibold">Pourquoi signales-tu ce contenu ?</label>
          <textarea id={`reason-${postId ?? commentId}`} name="reason" rows={3} maxLength={500} className="input py-2.5" required />
          <div className="flex gap-2">
            <button type="submit" disabled={pending} className="btn-primary min-h-[40px] px-4 disabled:opacity-60">{pending ? "Envoi…" : "Envoyer le signalement"}</button>
            <button type="button" onClick={() => setOpen(false)} className="btn-outline min-h-[40px] px-4">Annuler</button>
          </div>
        </form>
      ) : null}
      {msg ? <div className="mt-2 max-w-md"><FormMessage kind={msg.kind}>{msg.text}</FormMessage></div> : null}
    </div>
  );
}
