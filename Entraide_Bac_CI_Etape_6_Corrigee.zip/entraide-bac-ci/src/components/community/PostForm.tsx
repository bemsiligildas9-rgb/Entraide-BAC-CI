"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { createPost } from "@/app/communaute/actions";
import type { Subject } from "@/lib/types";
import { Field, FormMessage } from "../auth/Field";

export function PostForm({ subjects }: { subjects: Subject[] }) {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    const fd = new FormData(e.currentTarget);
    setPending(true);
    const r = await createPost({
      kind: fd.get("kind"),
      title: String(fd.get("title") ?? ""),
      body: String(fd.get("body") ?? ""),
      subjectId: fd.get("subjectId") ? Number(fd.get("subjectId")) : null,
    });
    setPending(false);
    if (!r.ok) return setError(r.error);
    router.push(`/communaute/${r.id}`);
    router.refresh();
  }

  return (
    <form onSubmit={onSubmit} className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <Field id="kind" label="Type de publication">
          <select id="kind" name="kind" defaultValue="question" className="input">
            <option value="question">Poser une question</option>
            <option value="methode">Partager une méthode</option>
          </select>
        </Field>
        <Field id="subjectId" label="Matière (facultatif)">
          <select id="subjectId" name="subjectId" defaultValue="" className="input">
            <option value="">Aucune</option>
            {subjects.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
        </Field>
      </div>
      <Field id="title" label="Titre">
        <input id="title" name="title" className="input" maxLength={200} required />
      </Field>
      <Field id="body" label="Détails" hint="Explique ce que tu as essayé ou détaille ta méthode.">
        <textarea id="body" name="body" rows={7} maxLength={5000} className="input py-2.5" required />
      </Field>
      {error ? <FormMessage kind="error">{error}</FormMessage> : null}
      <button type="submit" disabled={pending} className="btn-primary disabled:opacity-60">{pending ? "Publication…" : "Publier"}</button>
    </form>
  );
}
