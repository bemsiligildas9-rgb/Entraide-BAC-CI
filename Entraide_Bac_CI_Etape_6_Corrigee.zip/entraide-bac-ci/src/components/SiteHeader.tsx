import { Bell, Search } from "lucide-react";
import Link from "next/link";
import { getUser, isAdmin } from "@/lib/auth";
import { getUnreadCount } from "@/lib/data";
import { navLinks } from "@/lib/nav";
import { Logo } from "./Logo";
import { LogoutButton } from "./LogoutButton";
import { MobileNav } from "./MobileNav";
import { ThemeToggle } from "./ThemeToggle";

export async function SiteHeader() {
  const user = await getUser();
  const [admin, unread] = user ? await Promise.all([isAdmin(), getUnreadCount(user.id)]) : [false, 0];
  const iconBtn = "relative inline-flex h-11 w-11 items-center justify-center rounded-pill border border-line bg-raised text-ink transition hover:border-brand hover:text-brand";
  const mobileLinks = [
    ...navLinks,
    { href: "/recherche", label: "Rechercher" },
    ...(user ? [{ href: "/notifications", label: unread > 0 ? `Notifications (${unread})` : "Notifications" }] : []),
  ];
  return (
    <header className="sticky top-0 z-40 border-b border-line bg-bg/90 backdrop-blur">
      <div className="container-page relative flex h-16 items-center justify-between gap-4">
        <Link href="/" aria-label="Entraide Bac CI — accueil">
          <Logo />
        </Link>
        <nav className="hidden items-center gap-7 lg:flex" aria-label="Navigation principale">
          {navLinks.map((l) => (
            <Link key={l.href} href={l.href} className="text-sm font-semibold text-ink-soft transition hover:text-brand">
              {l.label}
            </Link>
          ))}
        </nav>
        <div className="hidden items-center gap-2 lg:flex">
          <Link href="/recherche" aria-label="Rechercher" className={iconBtn}><Search size={18} /></Link>
          {user ? (
            <Link href="/notifications" aria-label={unread > 0 ? `Notifications : ${unread} non lue${unread > 1 ? "s" : ""}` : "Notifications"} className={iconBtn}>
              <Bell size={18} />
              {unread > 0 ? <span className="absolute -right-1 -top-1 min-w-[20px] rounded-full bg-brand px-1 text-center text-xs font-bold leading-5 text-white dark:text-night">{unread > 9 ? "9+" : unread}</span> : null}
            </Link>
          ) : null}
          <ThemeToggle />
          {user ? (
            <>
              {admin ? <Link href="/admin" className="btn-outline">Administration</Link> : null}
              <Link href="/tableau-de-bord" className="btn-primary">Mon espace</Link>
              <LogoutButton />
            </>
          ) : (
            <>
              <Link href="/connexion" className="btn-outline">Connexion</Link>
              <Link href="/inscription" className="btn-primary">Inscription</Link>
            </>
          )}
        </div>
        <div className="flex items-center gap-2 lg:hidden">
          <ThemeToggle />
          <MobileNav loggedIn={!!user} isAdmin={admin} links={mobileLinks} />
        </div>
      </div>
    </header>
  );
}
