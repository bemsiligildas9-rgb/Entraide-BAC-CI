"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { fieldErrors, loginSchema } from "@/lib/validation";
import { Field, FormMessage } from "./Field";

export function ConnexionForm({ redirectTo, notice }: { redirectTo: string; notice?: string }) {
  const router = useRouter();
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setFormError(null);
    const parsed = loginSchema.safeParse(Object.fromEntries(new FormData(e.currentTarget)));
    if (!parsed.success) {
      setErrors(fieldErrors(parsed.error));
      return;
    }
    setErrors({});
    setPending(true);
    const { error } = await createClient().auth.signInWithPassword(parsed.data);
    setPending(false);
    if (error) {
      const msg = error.message.toLowerCase();
      setFormError(
        msg.includes("confirm")
          ? "Ton adresse e-mail n'est pas encore confirmée. Clique sur le lien reçu par e-mail."
          : msg.includes("rate") || error.status === 429
            ? "Trop de tentatives. Patiente quelques minutes avant de réessayer."
            : "E-mail ou mot de passe incorrect.",
      );
      return;
    }
    router.push(redirectTo);
    router.refresh();
  }

  return (
    <form onSubmit={onSubmit} noValidate className="space-y-4">
      {notice ? <FormMessage kind="error">{notice}</FormMessage> : null}
      <Field id="email" label="Adresse e-mail" error={errors.email}>
        <input id="email" name="email" type="email" inputMode="email" autoComplete="email" className="input" required />
      </Field>
      <Field id="password" label="Mot de passe" error={errors.password}>
        <input id="password" name="password" type="password" autoComplete="current-password" className="input" required />
      </Field>
      <div className="text-right">
        <Link href="/mot-de-passe-oublie" className="text-sm font-semibold text-brand hover:underline">Mot de passe oublié ?</Link>
      </div>
      {formError ? <FormMessage kind="error">{formError}</FormMessage> : null}
      <button type="submit" disabled={pending} className="btn-primary w-full disabled:opacity-60">
        {pending ? "Connexion…" : "Se connecter"}
      </button>
      <p className="text-center text-sm text-ink-soft">
        Pas encore de compte ? <Link href="/inscription" className="font-semibold text-brand hover:underline">Inscription</Link>
      </p>
    </form>
  );
}
