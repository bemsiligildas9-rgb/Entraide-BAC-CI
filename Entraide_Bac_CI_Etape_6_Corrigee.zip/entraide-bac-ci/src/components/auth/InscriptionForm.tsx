"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { fieldErrors, signupSchema } from "@/lib/validation";
import type { Level, Serie } from "@/lib/types";
import { Field, FormMessage } from "./Field";

export function InscriptionForm({ levels, series }: { levels: Level[]; series: Serie[] }) {
  const router = useRouter();
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);
  const [done, setDone] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setFormError(null);
    const parsed = signupSchema.safeParse(Object.fromEntries(new FormData(e.currentTarget)));
    if (!parsed.success) {
      setErrors(fieldErrors(parsed.error));
      return;
    }
    setErrors({});
    setPending(true);
    const v = parsed.data;
    const { data, error } = await createClient().auth.signUp({
      email: v.email,
      password: v.password,
      options: {
        data: { first_name: v.firstName, last_name: v.lastName, school: v.school ?? "", city: v.city, level: v.level, serie: v.serie },
        emailRedirectTo: `${window.location.origin}/auth/callback?next=/tableau-de-bord`,
      },
    });
    setPending(false);
    if (error) {
      setFormError(
        error.message.toLowerCase().includes("password")
          ? "Mot de passe trop faible : utilise au moins 8 caractères."
          : "Inscription impossible pour le moment. Vérifie tes informations puis réessaie.",
      );
      return;
    }
    if (data.session) {
      router.push("/tableau-de-bord");
      router.refresh();
      return;
    }
    setDone(true);
  }

  if (done) {
    return (
      <FormMessage kind="success">
        Presque terminé ! Nous t'avons envoyé un e-mail : clique sur le lien qu'il contient pour confirmer ton compte, puis{" "}
        <Link href="/connexion" className="font-semibold underline">connecte-toi</Link>. Pense à regarder dans tes courriers indésirables.
      </FormMessage>
    );
  }

  return (
    <form onSubmit={onSubmit} noValidate className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <Field id="lastName" label="Nom" error={errors.lastName}>
          <input id="lastName" name="lastName" autoComplete="family-name" className="input" required />
        </Field>
        <Field id="firstName" label="Prénom" error={errors.firstName}>
          <input id="firstName" name="firstName" autoComplete="given-name" className="input" required />
        </Field>
      </div>
      <Field id="email" label="Adresse e-mail" error={errors.email}>
        <input id="email" name="email" type="email" inputMode="email" autoComplete="email" className="input" required />
      </Field>
      <Field id="password" label="Mot de passe" error={errors.password} hint="8 caractères minimum.">
        <input id="password" name="password" type="password" autoComplete="new-password" className="input" required />
      </Field>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field id="level" label="Classe" error={errors.level}>
          <select id="level" name="level" defaultValue="" className="input" required>
            <option value="" disabled>Choisir…</option>
            {levels.map((l) => <option key={l.id} value={l.slug}>{l.name}</option>)}
          </select>
        </Field>
        <Field id="serie" label="Série" error={errors.serie}>
          <select id="serie" name="serie" defaultValue="" className="input" required>
            <option value="" disabled>Choisir…</option>
            {series.map((s) => <option key={s.id} value={s.slug}>{s.name}</option>)}
          </select>
        </Field>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field id="city" label="Ville" error={errors.city}>
          <input id="city" name="city" autoComplete="address-level2" className="input" required />
        </Field>
        <Field id="school" label="Établissement (facultatif)" error={errors.school}>
          <input id="school" name="school" className="input" />
        </Field>
      </div>
      {formError ? <FormMessage kind="error">{formError}</FormMessage> : null}
      <button type="submit" disabled={pending} className="btn-primary w-full disabled:opacity-60">
        {pending ? "Création du compte…" : "Créer mon compte"}
      </button>
      <p className="text-center text-sm text-ink-soft">
        Déjà inscrit ? <Link href="/connexion" className="font-semibold text-brand hover:underline">Connexion</Link>
      </p>
    </form>
  );
}
