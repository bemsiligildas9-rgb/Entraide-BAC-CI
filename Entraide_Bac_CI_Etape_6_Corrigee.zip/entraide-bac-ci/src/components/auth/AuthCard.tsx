export function AuthCard({ title, intro, children }: { title: string; intro?: string; children: React.ReactNode }) {
  return (
    <div className="container-page flex justify-center py-12 sm:py-16">
      <div className="card w-full max-w-lg p-6 shadow-sm sm:p-8">
        <h1 className="text-3xl font-bold">{title}</h1>
        {intro ? <p className="mt-2 text-ink-soft">{intro}</p> : null}
        <div className="mt-6">{children}</div>
      </div>
    </div>
  );
}
