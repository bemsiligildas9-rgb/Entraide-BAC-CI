"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { fieldErrors, passwordChangeSchema } from "@/lib/validation";
import { Field, FormMessage } from "./Field";

export function PasswordForm({ redirectAfter }: { redirectAfter?: string }) {
  const router = useRouter();
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [ok, setOk] = useState(false);
  const [pending, setPending] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    setFormError(null);
    setOk(false);
    const parsed = passwordChangeSchema.safeParse(Object.fromEntries(new FormData(form)));
    if (!parsed.success) {
      setErrors(fieldErrors(parsed.error));
      return;
    }
    setErrors({});
    setPending(true);
    const { error } = await createClient().auth.updateUser({ password: parsed.data.password });
    setPending(false);
    if (error) {
      setFormError("Impossible de modifier le mot de passe. Choisis-en un différent de l'ancien, ou reconnecte-toi puis réessaie.");
      return;
    }
    form.reset();
    setOk(true);
    if (redirectAfter) {
      router.push(redirectAfter);
      router.refresh();
    }
  }

  return (
    <form onSubmit={onSubmit} noValidate className="space-y-4">
      <Field id="password" label="Nouveau mot de passe" error={errors.password} hint="8 caractères minimum.">
        <input id="password" name="password" type="password" autoComplete="new-password" className="input" required />
      </Field>
      <Field id="confirm" label="Confirmer le mot de passe" error={errors.confirm}>
        <input id="confirm" name="confirm" type="password" autoComplete="new-password" className="input" required />
      </Field>
      {formError ? <FormMessage kind="error">{formError}</FormMessage> : null}
      {ok ? <FormMessage kind="success">Mot de passe modifié.</FormMessage> : null}
      <button type="submit" disabled={pending} className="btn-primary disabled:opacity-60">
        {pending ? "Enregistrement…" : "Modifier le mot de passe"}
      </button>
    </form>
  );
}
