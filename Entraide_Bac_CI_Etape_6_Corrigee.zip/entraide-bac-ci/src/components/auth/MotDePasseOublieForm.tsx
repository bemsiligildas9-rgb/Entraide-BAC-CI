"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { emailSchema, fieldErrors } from "@/lib/validation";
import { Field, FormMessage } from "./Field";

export function MotDePasseOublieForm() {
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [pending, setPending] = useState(false);
  const [sent, setSent] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const parsed = emailSchema.safeParse(Object.fromEntries(new FormData(e.currentTarget)));
    if (!parsed.success) {
      setErrors(fieldErrors(parsed.error));
      return;
    }
    setErrors({});
    setPending(true);
    await createClient().auth.resetPasswordForEmail(parsed.data.email, {
      redirectTo: `${window.location.origin}/auth/callback?next=/reinitialiser-mot-de-passe`,
    });
    setPending(false);
    setSent(true); // Réponse identique que l'adresse existe ou non (évite de révéler les comptes).
  }

  if (sent) {
    return <FormMessage kind="success">Si un compte existe avec cette adresse, un e-mail de réinitialisation vient d'être envoyé.</FormMessage>;
  }

  return (
    <form onSubmit={onSubmit} noValidate className="space-y-4">
      <Field id="email" label="Adresse e-mail" error={errors.email}>
        <input id="email" name="email" type="email" inputMode="email" autoComplete="email" className="input" required />
      </Field>
      <button type="submit" disabled={pending} className="btn-primary w-full disabled:opacity-60">
        {pending ? "Envoi…" : "Envoyer le lien"}
      </button>
    </form>
  );
}
