"use client";

import { CheckCircle2, XCircle } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { FormMessage } from "../auth/Field";

export type QuizQuestion = { id: string; prompt: string; choices: string[]; multiple: boolean };
type Result = { question_id: string; given: number[]; correct: number[]; ok: boolean; explanation: string | null };
type Outcome = { attempt_id: string; score: number; total: number; results: Result[] };

export function QuizRunner({ quizId, questions }: { quizId: string; questions: QuizQuestion[] }) {
  const router = useRouter();
  const [index, setIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number[]>>({});
  const [outcome, setOutcome] = useState<Outcome | null>(null);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const q = questions[index];
  const isLast = index === questions.length - 1;
  const unanswered = questions.filter((x) => !(answers[x.id]?.length > 0)).length;

  function choose(i: number) {
    setAnswers((prev) => {
      const cur = prev[q.id] ?? [];
      const next = q.multiple ? (cur.includes(i) ? cur.filter((x) => x !== i) : [...cur, i]) : [i];
      return { ...prev, [q.id]: next };
    });
  }

  async function submit() {
    setPending(true);
    setError(null);
    const { data, error: err } = await createClient().rpc("submit_quiz_attempt", { p_quiz_id: quizId, p_answers: answers });
    setPending(false);
    if (err || !data) {
      setError("Impossible d'enregistrer ton résultat. Vérifie ta connexion, reconnecte-toi si besoin, puis réessaie.");
      return;
    }
    setOutcome(data as Outcome);
    window.scrollTo({ top: 0 });
    router.refresh();
  }

  if (outcome) {
    const pct = Math.round((outcome.score / outcome.total) * 100);
    const byId = new Map(outcome.results.map((r) => [r.question_id, r]));
    return (
      <div>
        <div className="card p-6 text-center">
          <p className="text-sm text-ink-soft">Ton score</p>
          <p className="mt-1 font-display text-5xl font-extrabold text-brand">{outcome.score} / {outcome.total}</p>
          <p className="mt-1 text-lg font-semibold">{pct} %</p>
          <p className="mt-3 text-ink-soft">
            {pct >= 80 ? "Excellent travail !" : pct >= 50 ? "Bien joué, continue à t'entraîner." : "Relis les explications ci-dessous puis réessaie."}
          </p>
          <div className="mt-5 flex flex-wrap justify-center gap-2">
            <button type="button" onClick={() => { setOutcome(null); setAnswers({}); setIndex(0); }} className="btn-primary">Refaire le quiz</button>
            <Link href="/quiz" className="btn-outline">Autres quiz</Link>
            <Link href="/tableau-de-bord/resultats" className="btn-outline">Mon historique</Link>
          </div>
        </div>

        <h2 className="mt-10 text-2xl font-bold">Correction détaillée</h2>
        <ol className="mt-4 space-y-5">
          {questions.map((question, n) => {
            const r = byId.get(question.id);
            if (!r) return null;
            return (
              <li key={question.id} className="card p-5">
                <p className="flex items-center gap-2 text-sm font-semibold">
                  {r.ok ? <CheckCircle2 size={18} className="text-emerald-600" /> : <XCircle size={18} className="text-red-600" />}
                  Question {n + 1} — {r.ok ? "juste" : "incorrecte"}
                </p>
                <p className="mt-2 font-display text-lg font-bold">{question.prompt}</p>
                <ul className="mt-3 space-y-2">
                  {question.choices.map((c, i) => {
                    const isCorrect = r.correct.includes(i);
                    const isGiven = r.given.includes(i);
                    return (
                      <li
                        key={i}
                        className={`rounded-xl border px-3.5 py-2.5 ${
                          isCorrect ? "border-emerald-500 bg-emerald-50 dark:bg-emerald-500/10" : isGiven ? "border-red-400 bg-red-50 dark:bg-red-500/10" : "border-line"
                        }`}
                      >
                        {c}
                        {isCorrect ? <span className="ml-2 text-sm font-semibold">— bonne réponse</span> : null}
                        {isGiven && !isCorrect ? <span className="ml-2 text-sm font-semibold">— ta réponse</span> : null}
                        {isGiven && isCorrect ? <span className="ml-2 text-sm text-ink-soft">(ta réponse)</span> : null}
                      </li>
                    );
                  })}
                </ul>
                {r.given.length === 0 ? <p className="mt-2 text-sm text-ink-soft">Tu n'as pas répondu à cette question.</p> : null}
                {r.explanation ? (
                  <p className="mt-3 rounded-xl bg-surface p-3 text-ink-soft"><span className="font-semibold text-ink">Explication : </span>{r.explanation}</p>
                ) : null}
              </li>
            );
          })}
        </ol>
      </div>
    );
  }

  const current = answers[q.id] ?? [];
  return (
    <div>
      <div className="flex items-center justify-between text-sm text-ink-soft">
        <span>Question {index + 1} sur {questions.length}</span>
        <span>{questions.length - unanswered} répondue{questions.length - unanswered > 1 ? "s" : ""}</span>
      </div>
      <div className="mt-2 h-2 overflow-hidden rounded-pill bg-surface" role="progressbar" aria-valuemin={1} aria-valuemax={questions.length} aria-valuenow={index + 1} aria-label="Avancement du quiz">
        <div className="h-full rounded-pill bg-brand transition-all" style={{ width: `${((index + 1) / questions.length) * 100}%` }} />
      </div>

      <fieldset className="mt-6">
        <legend className="font-display text-xl font-bold leading-snug">{q.prompt}</legend>
        <p className="mt-1 text-sm text-ink-soft">{q.multiple ? "Plusieurs réponses possibles." : "Une seule réponse."}</p>
        <div className="mt-4 space-y-2">
          {q.choices.map((c, i) => (
            <label key={i} className={`flex min-h-[48px] cursor-pointer items-center gap-3 rounded-xl border px-4 py-3 transition ${current.includes(i) ? "border-brand bg-brand/10" : "border-line hover:border-brand"}`}>
              <input
                type={q.multiple ? "checkbox" : "radio"}
                name={`q-${q.id}`}
                checked={current.includes(i)}
                onChange={() => choose(i)}
                className="h-5 w-5 shrink-0 accent-[rgb(var(--brand))]"
              />
              <span>{c}</span>
            </label>
          ))}
        </div>
      </fieldset>

      {isLast && unanswered > 0 ? (
        <p className="mt-5 text-sm text-ink-soft">Il te reste {unanswered} question{unanswered > 1 ? "s" : ""} sans réponse (elles compteront comme fausses).</p>
      ) : null}
      {error ? <div className="mt-5"><FormMessage kind="error">{error}</FormMessage></div> : null}

      <div className="mt-6 flex items-center justify-between gap-3">
        <button type="button" onClick={() => setIndex((i) => i - 1)} disabled={index === 0} className="btn-outline disabled:opacity-40">Précédent</button>
        {isLast ? (
          <button type="button" onClick={submit} disabled={pending} className="btn-primary disabled:opacity-60">{pending ? "Correction…" : "Terminer et voir mon score"}</button>
        ) : (
          <button type="button" onClick={() => setIndex((i) => i + 1)} className="btn-primary">Suivant</button>
        )}
      </div>
    </div>
  );
}
