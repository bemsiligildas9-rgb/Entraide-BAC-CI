"use client";

import { Heart } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

export function FavoriteButton({ resourceId, initial, loggedIn }: { resourceId: string; initial: boolean; loggedIn: boolean }) {
  const router = useRouter();
  const [fav, setFav] = useState(initial);
  const [pending, setPending] = useState(false);

  async function toggle() {
    if (!loggedIn) {
      const back = window.location.pathname + window.location.search;
      router.push(`/connexion?redirige=${encodeURIComponent(back)}`);
      return;
    }
    setPending(true);
    const supabase = createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) {
      setPending(false);
      router.push("/connexion");
      return;
    }
    const next = !fav;
    setFav(next); // mise à jour immédiate, annulée en cas d'erreur
    const { error } = next
      ? await supabase.from("favorites").insert({ user_id: user.id, resource_id: resourceId })
      : await supabase.from("favorites").delete().eq("user_id", user.id).eq("resource_id", resourceId);
    if (error) setFav(!next);
    setPending(false);
    router.refresh();
  }

  return (
    <button
      type="button"
      onClick={toggle}
      disabled={pending}
      aria-pressed={fav}
      aria-label={fav ? "Retirer des favoris" : "Ajouter aux favoris"}
      className="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-pill border border-line text-ink-soft transition hover:border-brand hover:text-brand disabled:opacity-60"
    >
      <Heart size={19} className={fav ? "fill-current text-brand" : ""} />
    </button>
  );
}
