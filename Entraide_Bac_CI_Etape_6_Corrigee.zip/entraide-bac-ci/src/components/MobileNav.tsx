"use client";

import { Menu, X } from "lucide-react";
import Link from "next/link";
import { useEffect, useState } from "react";
import { LogoutButton } from "./LogoutButton";

export function MobileNav({ loggedIn, isAdmin = false, links }: { loggedIn: boolean; isAdmin?: boolean; links: readonly { href: string; label: string }[] }) {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open]);

  const close = () => setOpen(false);

  return (
    <div>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        aria-controls="menu-mobile"
        aria-label={open ? "Fermer le menu" : "Ouvrir le menu"}
        className="inline-flex h-11 w-11 items-center justify-center rounded-pill border border-line bg-raised text-ink"
      >
        {open ? <X size={20} /> : <Menu size={20} />}
      </button>
      {open ? (
        <nav
          id="menu-mobile"
          aria-label="Menu mobile"
          className="absolute inset-x-0 top-16 border-b border-line bg-bg px-4 pb-5 pt-3 shadow-lg"
        >
          <ul className="flex flex-col">
            {links.map((l) => (
              <li key={l.href}>
                <Link href={l.href} onClick={close} className="block border-b border-line py-3 text-base font-medium text-ink">
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
          <div className="mt-4 flex flex-col gap-2">
            {loggedIn ? (
              <>
                {isAdmin ? <Link href="/admin" onClick={close} className="btn-outline">Administration</Link> : null}
                <Link href="/tableau-de-bord" onClick={close} className="btn-primary">Mon espace</Link>
                <LogoutButton />
              </>
            ) : (
              <>
                <Link href="/inscription" onClick={close} className="btn-primary">Inscription</Link>
                <Link href="/connexion" onClick={close} className="btn-outline">Connexion</Link>
              </>
            )}
          </div>
        </nav>
      ) : null}
    </div>
  );
}
