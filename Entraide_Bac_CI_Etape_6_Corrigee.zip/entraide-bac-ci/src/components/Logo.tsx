import { site } from "@/lib/site";

export function LogoMark({ size = 36 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" role="img" aria-label="Logo Entraide Bac CI" xmlns="http://www.w3.org/2000/svg">
      <rect width="32" height="32" rx="9" fill="#1769E0" />
      <path
        d="M16 12.6c-2.4-1.7-5.1-2.1-7.6-1.7v10.8c2.5-.4 5.2 0 7.6 1.7 2.4-1.7 5.1-2.1 7.6-1.7V10.9c-2.5-.4-5.2 0-7.6 1.7z"
        fill="#FFFFFF"
      />
      <path d="M16 12.6v10.9" stroke="#1769E0" strokeWidth="1.4" strokeLinecap="round" />
      <circle cx="24.2" cy="7.8" r="2.3" fill="#22D3EE" />
    </svg>
  );
}

export function Logo() {
  return (
    <span className="inline-flex items-center gap-2.5">
      <LogoMark />
      <span className="flex flex-col leading-none">
        <span className="font-display text-lg font-bold tracking-tight text-ink">{site.name}</span>
        <span className="mt-0.5 text-[11px] font-medium text-ink-soft">{site.signature}</span>
      </span>
    </span>
  );
}
