import Link from "next/link";

export function Pagination({
  basePath,
  params,
  page,
  totalPages,
}: {
  basePath: string;
  params: Record<string, string | undefined>;
  page: number;
  totalPages: number;
}) {
  if (totalPages <= 1) return null;
  const href = (p: number) => {
    const sp = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => v && sp.set(k, v));
    if (p > 1) sp.set("page", String(p));
    const qs = sp.toString();
    return qs ? `${basePath}?${qs}` : basePath;
  };
  return (
    <nav aria-label="Pagination" className="mt-10 flex items-center justify-between gap-4">
      {page > 1 ? <Link href={href(page - 1)} className="btn-outline">Précédent</Link> : <span />}
      <p className="text-sm text-ink-soft">Page {page} sur {totalPages}</p>
      {page < totalPages ? <Link href={href(page + 1)} className="btn-outline">Suivant</Link> : <span />}
    </nav>
  );
}
