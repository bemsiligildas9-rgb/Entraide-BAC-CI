"use client";

import { Plus, Trash2 } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { saveQuiz } from "@/app/admin/actions";
import { quizSchema, firstIssue } from "@/lib/admin-schemas";
import type { Level, Serie, Subject } from "@/lib/types";
import { Field, FormMessage } from "../auth/Field";

type Q = { prompt: string; choices: string[]; correct: number[]; explanation: string };
export type QuizInitial = {
  id: string;
  title: string;
  description: string;
  subjectId: number | null;
  levelId: number | null;
  serieId: number | null;
  isPublished: boolean;
  questions: Q[];
};

const blank = (): Q => ({ prompt: "", choices: ["", ""], correct: [], explanation: "" });
const toNum = (v: string) => (v ? Number(v) : null);

export function QuizForm({ initial, subjects, series, levels }: { initial?: QuizInitial; subjects: Subject[]; series: Serie[]; levels: Level[] }) {
  const router = useRouter();
  const [title, setTitle] = useState(initial?.title ?? "");
  const [description, setDescription] = useState(initial?.description ?? "");
  const [subjectId, setSubjectId] = useState(initial?.subjectId ? String(initial.subjectId) : "");
  const [levelId, setLevelId] = useState(initial?.levelId ? String(initial.levelId) : "");
  const [serieId, setSerieId] = useState(initial?.serieId ? String(initial.serieId) : "");
  const [isPublished, setIsPublished] = useState(initial?.isPublished ?? false);
  const [questions, setQuestions] = useState<Q[]>(initial?.questions.length ? initial.questions : [blank()]);
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  const patch = (i: number, p: Partial<Q>) => setQuestions((qs) => qs.map((q, n) => (n === i ? { ...q, ...p } : q)));

  function setChoice(i: number, c: number, value: string) {
    patch(i, { choices: questions[i].choices.map((x, n) => (n === c ? value : x)) });
  }
  function addChoice(i: number) {
    if (questions[i].choices.length < 8) patch(i, { choices: [...questions[i].choices, ""] });
  }
  function removeChoice(i: number, c: number) {
    const q = questions[i];
    if (q.choices.length <= 2) return;
    patch(i, {
      choices: q.choices.filter((_, n) => n !== c),
      correct: q.correct.filter((x) => x !== c).map((x) => (x > c ? x - 1 : x)),
    });
  }
  function toggleCorrect(i: number, c: number) {
    const q = questions[i];
    patch(i, { correct: q.correct.includes(c) ? q.correct.filter((x) => x !== c) : [...q.correct, c] });
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const input = {
      id: initial?.id,
      title,
      description: description.trim() || null,
      subjectId: toNum(subjectId),
      levelId: toNum(levelId),
      serieId: toNum(serieId),
      isPublished,
      questions: questions.map((q) => ({ prompt: q.prompt, choices: q.choices, correct: q.correct, explanation: q.explanation.trim() || null })),
    };
    const check = quizSchema.safeParse(input);
    if (!check.success) return setError(firstIssue(check.error));
    setPending(true);
    const r = await saveQuiz(input);
    setPending(false);
    if (!r.ok) return setError(r.error);
    router.push("/admin/quiz");
    router.refresh();
  }

  return (
    <form onSubmit={onSubmit} className="max-w-3xl space-y-6">
      <Field id="title" label="Titre du quiz">
        <input id="title" value={title} onChange={(e) => setTitle(e.target.value)} className="input" maxLength={200} required />
      </Field>
      <Field id="description" label="Description (facultatif)">
        <textarea id="description" value={description} onChange={(e) => setDescription(e.target.value)} rows={3} maxLength={1000} className="input py-2.5" />
      </Field>
      <div className="grid gap-4 sm:grid-cols-3">
        <Field id="subjectId" label="Matière">
          <select id="subjectId" value={subjectId} onChange={(e) => setSubjectId(e.target.value)} className="input">
            <option value="">Aucune</option>
            {subjects.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
        </Field>
        <Field id="serieId" label="Série">
          <select id="serieId" value={serieId} onChange={(e) => setSerieId(e.target.value)} className="input">
            <option value="">Toutes</option>
            {series.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
        </Field>
        <Field id="levelId" label="Classe">
          <select id="levelId" value={levelId} onChange={(e) => setLevelId(e.target.value)} className="input">
            <option value="">Toutes</option>
            {levels.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}
          </select>
        </Field>
      </div>

      <h2 className="pt-2 text-2xl font-bold">Questions</h2>
      <p className="-mt-3 text-sm text-ink-soft">Coche la ou les bonnes réponses. Si tu en coches plusieurs, l'élève verra des cases à cocher.</p>
      <ol className="space-y-5">
        {questions.map((q, i) => (
          <li key={i} className="card space-y-3 p-4">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-lg font-bold">Question {i + 1}</h3>
              {questions.length > 1 ? (
                <button type="button" onClick={() => setQuestions((qs) => qs.filter((_, n) => n !== i))} className="inline-flex min-h-[40px] items-center gap-1.5 rounded-pill px-3 text-sm font-semibold text-red-700 hover:bg-red-50 dark:text-red-300 dark:hover:bg-red-500/10">
                  <Trash2 size={16} /> Supprimer
                </button>
              ) : null}
            </div>
            <Field id={`prompt-${i}`} label="Énoncé">
              <textarea id={`prompt-${i}`} value={q.prompt} onChange={(e) => patch(i, { prompt: e.target.value })} rows={2} maxLength={1000} className="input py-2.5" />
            </Field>
            <fieldset className="space-y-2">
              <legend className="mb-1 text-sm font-semibold">Choix (coche les bonnes réponses)</legend>
              {q.choices.map((c, ci) => (
                <div key={ci} className="flex items-center gap-2">
                  <input type="checkbox" checked={q.correct.includes(ci)} onChange={() => toggleCorrect(i, ci)} aria-label={`Choix ${ci + 1} : bonne réponse`} className="h-5 w-5 shrink-0 accent-[rgb(var(--brand))]" />
                  <input value={c} onChange={(e) => setChoice(i, ci, e.target.value)} aria-label={`Texte du choix ${ci + 1}`} className="input" maxLength={300} placeholder={`Choix ${ci + 1}`} />
                  {q.choices.length > 2 ? (
                    <button type="button" onClick={() => removeChoice(i, ci)} aria-label={`Retirer le choix ${ci + 1}`} className="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-pill text-ink-soft hover:text-red-600">
                      <Trash2 size={17} />
                    </button>
                  ) : null}
                </div>
              ))}
              {q.choices.length < 8 ? (
                <button type="button" onClick={() => addChoice(i)} className="inline-flex min-h-[40px] items-center gap-1.5 text-sm font-semibold text-brand hover:underline">
                  <Plus size={16} /> Ajouter un choix
                </button>
              ) : null}
            </fieldset>
            <Field id={`explanation-${i}`} label="Explication affichée après la réponse (facultatif)">
              <textarea id={`explanation-${i}`} value={q.explanation} onChange={(e) => patch(i, { explanation: e.target.value })} rows={2} maxLength={1500} className="input py-2.5" />
            </Field>
          </li>
        ))}
      </ol>
      {questions.length < 100 ? (
        <button type="button" onClick={() => setQuestions((qs) => [...qs, blank()])} className="btn-outline">
          <Plus size={17} /> Ajouter une question
        </button>
      ) : null}

      <label className="flex min-h-[44px] items-center gap-3">
        <input type="checkbox" checked={isPublished} onChange={(e) => setIsPublished(e.target.checked)} className="h-5 w-5 accent-[rgb(var(--brand))]" />
        <span className="font-semibold">Publié (visible par les élèves)</span>
      </label>
      {error ? <FormMessage kind="error">{error}</FormMessage> : null}
      <div className="flex gap-3">
        <button type="submit" disabled={pending} className="btn-primary disabled:opacity-60">{pending ? "Enregistrement…" : "Enregistrer le quiz"}</button>
        <button type="button" onClick={() => router.push("/admin/quiz")} className="btn-outline">Annuler</button>
      </div>
    </form>
  );
}
