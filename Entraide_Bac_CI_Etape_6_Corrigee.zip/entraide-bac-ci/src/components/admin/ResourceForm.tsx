"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { saveResource } from "@/app/admin/actions";
import { resourceSchema } from "@/lib/admin-schemas";
import { slugify } from "@/lib/files";
import { kindLabels, kindOrder } from "@/lib/labels";
import { createClient } from "@/lib/supabase/client";
import type { Level, ResourceKind, Serie, Subject } from "@/lib/types";
import { Field, FormMessage } from "../auth/Field";

export type ResourceInitial = {
  id: string;
  kind: ResourceKind;
  title: string;
  description: string | null;
  subjectId: number;
  levelId: number | null;
  serieId: number | null;
  chapterId: number | null;
  filePath: string | null;
  fileSize: number | null;
  videoUrl: string | null;
  examYear: number | null;
  epreuve: string | null;
  publishedDate: string;
  isPublished: boolean;
};

export type ChapterOption = { id: number; subject_id: number; title: string };

const MAX_BYTES = 50 * 1024 * 1024;
const EXTENSIONS = ["pdf", "png", "jpg", "jpeg", "webp"];
const optNum = (v: FormDataEntryValue | null) => (v ? Number(v) : null);
const optText = (v: FormDataEntryValue | null) => (typeof v === "string" && v.trim() ? v.trim() : null);

export function ResourceForm({
  initial,
  subjects,
  series,
  levels,
  chapters,
}: {
  initial?: ResourceInitial;
  subjects: Subject[];
  series: Serie[];
  levels: Level[];
  chapters: ChapterOption[];
}) {
  const router = useRouter();
  const [kind, setKind] = useState<ResourceKind>(initial?.kind ?? "cours");
  const [subjectId, setSubjectId] = useState<string>(initial ? String(initial.subjectId) : "");
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    const fd = new FormData(e.currentTarget);
    const title = String(fd.get("title") ?? "").trim();
    const file = fd.get("file");
    const newFile = file instanceof File && file.size > 0 ? file : null;

    let ext = "";
    if (newFile) {
      ext = (newFile.name.split(".").pop() ?? "").toLowerCase();
      if (!EXTENSIONS.includes(ext)) return setError("Format non accepté. Utilise un PDF, PNG, JPG ou WEBP.");
      if (newFile.size > MAX_BYTES) return setError("Le fichier dépasse 50 Mo.");
    }
    const uploadPath = newFile ? `${kind}/${crypto.randomUUID()}-${slugify(title)}.${ext}` : null;

    const input = {
      id: initial?.id,
      kind,
      title,
      description: optText(fd.get("description")),
      subjectId: Number(fd.get("subjectId")),
      levelId: optNum(fd.get("levelId")),
      serieId: optNum(fd.get("serieId")),
      chapterId: optNum(fd.get("chapterId")),
      filePath: uploadPath ?? initial?.filePath ?? null,
      fileSize: newFile ? newFile.size : (initial?.fileSize ?? null),
      videoUrl: optText(fd.get("videoUrl")),
      examYear: optNum(fd.get("examYear")),
      epreuve: optText(fd.get("epreuve")),
      publishedDate: String(fd.get("publishedDate") ?? ""),
      isPublished: fd.get("isPublished") === "on",
    };

    const check = resourceSchema.safeParse(input);
    if (!check.success) return setError(check.error.issues[0].message);

    setPending(true);
    const supabase = createClient();
    if (newFile && uploadPath) {
      // Envoi direct vers le stockage Supabase (droits admin vérifiés par la RLS) : pas de limite de taille serveur.
      const { error: upError } = await supabase.storage.from("documents").upload(uploadPath, newFile, { contentType: newFile.type || undefined });
      if (upError) {
        setPending(false);
        return setError("L'envoi du fichier a échoué. Vérifie ta connexion et que tu es bien connecté en administrateur.");
      }
    }
    const result = await saveResource(input);
    if (!result.ok) {
      if (uploadPath) await supabase.storage.from("documents").remove([uploadPath]); // évite un fichier orphelin
      setPending(false);
      return setError(result.error);
    }
    router.push("/admin/ressources");
    router.refresh();
  }

  const subjectChapters = chapters.filter((c) => String(c.subject_id) === subjectId);

  return (
    <form onSubmit={onSubmit} className="max-w-3xl space-y-5">
      <div className="grid gap-4 sm:grid-cols-2">
        <Field id="kind" label="Catégorie">
          <select id="kind" value={kind} onChange={(e) => setKind(e.target.value as ResourceKind)} className="input">
            {kindOrder.map((k) => <option key={k} value={k}>{kindLabels[k]}</option>)}
          </select>
        </Field>
        <Field id="subjectId" label="Matière">
          <select id="subjectId" name="subjectId" value={subjectId} onChange={(e) => setSubjectId(e.target.value)} className="input" required>
            <option value="" disabled>Choisir…</option>
            {subjects.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
        </Field>
      </div>
      <Field id="title" label="Titre">
        <input id="title" name="title" defaultValue={initial?.title} className="input" maxLength={200} required />
      </Field>
      <Field id="description" label="Description (facultatif)">
        <textarea id="description" name="description" defaultValue={initial?.description ?? ""} rows={4} maxLength={2000} className="input py-2.5" />
      </Field>
      <div className="grid gap-4 sm:grid-cols-3">
        <Field id="serieId" label={kind === "annale" ? "Série / examen" : "Série"} hint={kind === "annale" ? undefined : "« Toutes » si le document concerne plusieurs séries."}>
          <select id="serieId" name="serieId" defaultValue={initial?.serieId ?? ""} className="input">
            <option value="">Toutes</option>
            {series.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
        </Field>
        <Field id="levelId" label="Classe">
          <select id="levelId" name="levelId" defaultValue={initial?.levelId ?? ""} className="input">
            <option value="">Toutes</option>
            {levels.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}
          </select>
        </Field>
        <Field id="chapterId" label="Chapitre">
          <select id="chapterId" name="chapterId" defaultValue={initial?.chapterId ?? ""} className="input" key={subjectId}>
            <option value="">Aucun</option>
            {subjectChapters.map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}
          </select>
        </Field>
      </div>
      {kind === "annale" ? (
        <div className="grid gap-4 sm:grid-cols-2">
          <Field id="examYear" label="Année de l'examen">
            <input id="examYear" name="examYear" type="number" min={1960} max={2100} defaultValue={initial?.examYear ?? ""} className="input" />
          </Field>
          <Field id="epreuve" label="Type d'épreuve (facultatif)">
            <input id="epreuve" name="epreuve" defaultValue={initial?.epreuve ?? ""} maxLength={120} className="input" />
          </Field>
        </div>
      ) : null}
      <Field id="file" label={initial?.filePath ? "Remplacer le fichier" : "Fichier (PDF, image)"} hint={initial?.filePath ? "Un fichier est déjà associé. Laisse vide pour le conserver." : "50 Mo maximum."}>
        <input id="file" name="file" type="file" accept=".pdf,.png,.jpg,.jpeg,.webp,application/pdf,image/*" className="input py-2" />
      </Field>
      <Field id="videoUrl" label="Lien vidéo (facultatif)" hint="Lien https, par exemple YouTube.">
        <input id="videoUrl" name="videoUrl" type="url" defaultValue={initial?.videoUrl ?? ""} className="input" placeholder="https://" />
      </Field>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field id="publishedDate" label="Date de publication" hint="Une date future programme la mise en ligne.">
          <input id="publishedDate" name="publishedDate" type="date" defaultValue={initial?.publishedDate ?? new Date().toISOString().slice(0, 10)} className="input" required />
        </Field>
        <label className="flex min-h-[44px] items-center gap-3 self-end">
          <input type="checkbox" name="isPublished" defaultChecked={initial?.isPublished ?? true} className="h-5 w-5 accent-[rgb(var(--brand))]" />
          <span className="font-semibold">Publié (visible par les élèves)</span>
        </label>
      </div>
      {error ? <FormMessage kind="error">{error}</FormMessage> : null}
      <div className="flex gap-3">
        <button type="submit" disabled={pending} className="btn-primary disabled:opacity-60">
          {pending ? "Enregistrement…" : initial ? "Enregistrer les modifications" : "Publier"}
        </button>
        <button type="button" onClick={() => router.push("/admin/ressources")} className="btn-outline">Annuler</button>
      </div>
    </form>
  );
}
