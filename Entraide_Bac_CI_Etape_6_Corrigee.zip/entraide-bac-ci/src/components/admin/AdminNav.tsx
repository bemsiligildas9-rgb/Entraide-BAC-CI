"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const items = [
  { href: "/admin", label: "Tableau de bord" },
  { href: "/admin/ressources", label: "Ressources" },
  { href: "/admin/quiz", label: "Quiz" },
  { href: "/admin/referentiels", label: "Matières et classes" },
  { href: "/admin/chapitres", label: "Chapitres" },
  { href: "/admin/moderation", label: "Modération" },
  { href: "/admin/messages", label: "Messages" },
  { href: "/admin/annonces", label: "Annonces" },
  { href: "/admin/utilisateurs", label: "Utilisateurs" },
  { href: "/admin/reglages", label: "Réglages" },
];

export function AdminNav() {
  const pathname = usePathname();
  return (
    <nav aria-label="Administration" className="mt-5 flex gap-1 overflow-x-auto border-b border-line">
      {items.map((it) => {
        const active = it.href === "/admin" ? pathname === "/admin" : pathname.startsWith(it.href);
        return (
          <Link
            key={it.href}
            href={it.href}
            aria-current={active ? "page" : undefined}
            className={`-mb-px whitespace-nowrap border-b-2 px-3.5 py-3 text-sm font-semibold transition ${
              active ? "border-brand text-brand" : "border-transparent text-ink-soft hover:text-ink"
            }`}
          >
            {it.label}
          </Link>
        );
      })}
    </nav>
  );
}
