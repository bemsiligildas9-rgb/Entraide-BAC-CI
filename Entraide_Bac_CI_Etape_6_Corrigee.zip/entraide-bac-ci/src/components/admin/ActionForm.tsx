"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import type { ActionResult } from "@/lib/action-result";
import { FormMessage } from "../auth/Field";

export function ActionForm({
  action,
  submitLabel,
  children,
  resetOnSuccess = true,
  className = "space-y-4",
}: {
  action: (fd: FormData) => Promise<ActionResult>;
  submitLabel: string;
  children: React.ReactNode;
  resetOnSuccess?: boolean;
  className?: string;
}) {
  const router = useRouter();
  const [pending, start] = useTransition();
  const [msg, setMsg] = useState<{ kind: "error" | "success"; text: string } | null>(null);

  function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const fd = new FormData(form);
    setMsg(null);
    start(async () => {
      const r = await action(fd);
      if (r.ok) {
        setMsg({ kind: "success", text: r.message ?? "Enregistré." });
        if (resetOnSuccess) form.reset();
        router.refresh();
      } else {
        setMsg({ kind: "error", text: r.error });
      }
    });
  }

  return (
    <form onSubmit={onSubmit} className={className}>
      {children}
      {msg ? <FormMessage kind={msg.kind}>{msg.text}</FormMessage> : null}
      <button type="submit" disabled={pending} className="btn-primary disabled:opacity-60">
        {pending ? "Enregistrement…" : submitLabel}
      </button>
    </form>
  );
}
