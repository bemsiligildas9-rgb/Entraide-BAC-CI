"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import type { ActionResult } from "@/lib/action-result";

const styles = {
  outline: "btn-outline",
  primary: "btn-primary",
  danger: "btn border border-red-300 text-red-700 hover:bg-red-50 dark:border-red-500/50 dark:text-red-300 dark:hover:bg-red-500/10",
} as const;

export function ActionButton({
  action,
  label,
  confirm: confirmText,
  variant = "outline",
}: {
  action: () => Promise<ActionResult>;
  label: string;
  confirm?: string;
  variant?: keyof typeof styles;
}) {
  const router = useRouter();
  const [pending, start] = useTransition();
  const [error, setError] = useState<string | null>(null);

  function run() {
    if (confirmText && !window.confirm(confirmText)) return;
    setError(null);
    start(async () => {
      const r = await action();
      if (r.ok) router.refresh();
      else setError(r.error);
    });
  }

  return (
    <span className="inline-flex flex-col items-start gap-1">
      <button type="button" onClick={run} disabled={pending} className={`${styles[variant]} min-h-[40px] px-4 disabled:opacity-60`}>
        {pending ? "…" : label}
      </button>
      {error ? <span role="alert" className="max-w-xs text-xs font-medium text-red-600 dark:text-red-400">{error}</span> : null}
    </span>
  );
}
