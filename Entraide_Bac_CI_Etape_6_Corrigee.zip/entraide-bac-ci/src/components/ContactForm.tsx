"use client";

import { useState } from "react";
import { sendContactMessage } from "@/app/contact/actions";
import { Field, FormMessage } from "./auth/Field";

export function ContactForm() {
  const [msg, setMsg] = useState<{ kind: "error" | "success"; text: string } | null>(null);
  const [pending, setPending] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const fd = new FormData(form);
    setMsg(null);
    setPending(true);
    const r = await sendContactMessage({
      name: String(fd.get("name") ?? ""),
      email: String(fd.get("email") ?? ""),
      message: String(fd.get("message") ?? ""),
      website: String(fd.get("website") ?? ""),
    });
    setPending(false);
    if (r.ok) {
      setMsg({ kind: "success", text: r.message ?? "Message envoyé." });
      form.reset();
    } else {
      setMsg({ kind: "error", text: r.error });
    }
  }

  return (
    <form onSubmit={onSubmit} className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <Field id="name" label="Nom">
          <input id="name" name="name" autoComplete="name" className="input" maxLength={100} required />
        </Field>
        <Field id="email" label="Adresse e-mail">
          <input id="email" name="email" type="email" inputMode="email" autoComplete="email" className="input" maxLength={200} required />
        </Field>
      </div>
      <Field id="message" label="Message">
        <textarea id="message" name="message" rows={6} maxLength={4000} className="input py-2.5" required />
      </Field>
      {/* Champ piège anti-robots : invisible pour les humains */}
      <div aria-hidden="true" className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
        <label>Ne pas remplir <input name="website" tabIndex={-1} autoComplete="off" /></label>
      </div>
      {msg ? <FormMessage kind={msg.kind}>{msg.text}</FormMessage> : null}
      <button type="submit" disabled={pending} className="btn-primary disabled:opacity-60">{pending ? "Envoi…" : "Envoyer le message"}</button>
    </form>
  );
}
