import Link from "next/link";
import { getSeries } from "@/lib/data";
import { site } from "@/lib/site";
import { Logo } from "./Logo";

export async function SiteFooter() {
  const series = await getSeries();
  return (
    <footer className="mt-24 border-t border-line bg-surface">
      <div className="container-page grid gap-10 py-12 md:grid-cols-[1.4fr_1fr_1fr_1fr]">
        <div>
          <Logo />
          <p className="mt-4 max-w-xs text-sm text-ink-soft">{site.slogan} Une plateforme créée par {site.owner} pour les élèves de Côte d'Ivoire.</p>
        </div>
        <nav aria-label="Plateforme">
          <h2 className="font-display text-base font-bold">Plateforme</h2>
          <ul className="mt-3 space-y-2 text-sm text-ink-soft">
            <li><Link href="/documents" className="hover:text-brand">Documents</Link></li>
            <li><Link href="/annales" className="hover:text-brand">Annales</Link></li>
            <li><Link href="/quiz" className="hover:text-brand">Quiz</Link></li>
            <li><Link href="/communaute" className="hover:text-brand">Communauté</Link></li>
            <li><Link href="/#categories" className="hover:text-brand">Séries</Link></li>
            <li><Link href="/#matieres" className="hover:text-brand">Matières</Link></li>
            <li><Link href="/#ressources" className="hover:text-brand">Dernières ressources</Link></li>
            <li><Link href="/inscription" className="hover:text-brand">Inscription</Link></li>
            <li><Link href="/connexion" className="hover:text-brand">Connexion</Link></li>
          </ul>
        </nav>
        <nav aria-label="Informations">
          <h2 className="font-display text-base font-bold">Informations</h2>
          <ul className="mt-3 space-y-2 text-sm text-ink-soft">
            <li><Link href="/a-propos" className="hover:text-brand">À propos</Link></li>
            <li><Link href="/faq" className="hover:text-brand">Questions fréquentes</Link></li>
            <li><Link href="/contact" className="hover:text-brand">Contact</Link></li>
            <li><Link href="/conditions-utilisation" className="hover:text-brand">Conditions d'utilisation</Link></li>
            <li><Link href="/politique-confidentialite" className="hover:text-brand">Politique de confidentialité</Link></li>
          </ul>
        </nav>
        <nav aria-label="Séries">
          <h2 className="font-display text-base font-bold">Préparer un examen</h2>
          <ul className="mt-3 space-y-2 text-sm text-ink-soft">
            {series.map((s) => (
              <li key={s.id}><Link href={`/series/${s.slug}`} className="hover:text-brand">Préparation {s.name}</Link></li>
            ))}
          </ul>
        </nav>
      </div>
      <div className="border-t border-line">
        <div className="container-page flex flex-col gap-1 py-5 text-sm text-ink-soft sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} {site.fullName}</p>
          <p>Créateur et propriétaire : {site.owner}</p>
        </div>
      </div>
    </footer>
  );
}
