"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const tabs = [
  { href: "/tableau-de-bord", label: "Vue d'ensemble" },
  { href: "/tableau-de-bord/resultats", label: "Mes résultats" },
  { href: "/tableau-de-bord/profil", label: "Mon profil" },
];

export function DashboardTabs() {
  const pathname = usePathname();
  return (
    <nav aria-label="Espace élève" className="mt-6 flex gap-2 overflow-x-auto border-b border-line">
      {tabs.map((t) => {
        const active = pathname === t.href;
        return (
          <Link
            key={t.href}
            href={t.href}
            aria-current={active ? "page" : undefined}
            className={`-mb-px whitespace-nowrap border-b-2 px-4 py-3 text-sm font-semibold transition ${
              active ? "border-brand text-brand" : "border-transparent text-ink-soft hover:text-ink"
            }`}
          >
            {t.label}
          </Link>
        );
      })}
    </nav>
  );
}
