"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { fieldErrors, profileSchema } from "@/lib/validation";
import type { Level, Profile, Serie } from "@/lib/types";
import { Field, FormMessage } from "../auth/Field";

export function ProfileForm({ profile, levels, series }: { profile: Profile; levels: Level[]; series: Serie[] }) {
  const router = useRouter();
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [ok, setOk] = useState(false);
  const [pending, setPending] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setFormError(null);
    setOk(false);
    const parsed = profileSchema.safeParse(Object.fromEntries(new FormData(e.currentTarget)));
    if (!parsed.success) {
      setErrors(fieldErrors(parsed.error));
      return;
    }
    setErrors({});
    setPending(true);
    const v = parsed.data;
    // Seules ces colonnes existent côté profil : aucun rôle ne peut être modifié ici.
    const { error } = await createClient()
      .from("profiles")
      .update({
        first_name: v.firstName,
        last_name: v.lastName,
        school: v.school || null,
        city: v.city,
        level_id: Number(v.level),
        serie_id: Number(v.serie),
      })
      .eq("id", profile.id);
    setPending(false);
    if (error) {
      setFormError("Impossible d'enregistrer le profil pour le moment. Réessaie dans un instant.");
      return;
    }
    setOk(true);
    router.refresh();
  }

  return (
    <form onSubmit={onSubmit} noValidate className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <Field id="lastName" label="Nom" error={errors.lastName}>
          <input id="lastName" name="lastName" defaultValue={profile.last_name} className="input" required />
        </Field>
        <Field id="firstName" label="Prénom" error={errors.firstName}>
          <input id="firstName" name="firstName" defaultValue={profile.first_name} className="input" required />
        </Field>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field id="level" label="Classe" error={errors.level}>
          <select id="level" name="level" defaultValue={profile.level_id ?? ""} className="input" required>
            <option value="" disabled>Choisir…</option>
            {levels.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}
          </select>
        </Field>
        <Field id="serie" label="Série" error={errors.serie}>
          <select id="serie" name="serie" defaultValue={profile.serie_id ?? ""} className="input" required>
            <option value="" disabled>Choisir…</option>
            {series.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
        </Field>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field id="city" label="Ville" error={errors.city}>
          <input id="city" name="city" defaultValue={profile.city ?? ""} className="input" required />
        </Field>
        <Field id="school" label="Établissement (facultatif)" error={errors.school}>
          <input id="school" name="school" defaultValue={profile.school ?? ""} className="input" />
        </Field>
      </div>
      {formError ? <FormMessage kind="error">{formError}</FormMessage> : null}
      {ok ? <FormMessage kind="success">Profil enregistré.</FormMessage> : null}
      <button type="submit" disabled={pending} className="btn-primary disabled:opacity-60">
        {pending ? "Enregistrement…" : "Enregistrer le profil"}
      </button>
    </form>
  );
}
