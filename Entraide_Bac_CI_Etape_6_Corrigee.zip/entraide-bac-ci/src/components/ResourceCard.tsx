import { Download, Eye } from "lucide-react";
import Link from "next/link";
import { formatDate, kindSingular } from "@/lib/labels";
import type { ResourceItem } from "@/lib/types";
import { FavoriteButton } from "./FavoriteButton";

export function ResourceCard({ resource: r, isFavorite, loggedIn }: { resource: ResourceItem; isFavorite: boolean; loggedIn: boolean }) {
  const meta = [r.subjects?.name, r.levels?.name, r.series?.name, r.exam_year ? String(r.exam_year) : null, r.epreuve].filter(Boolean);
  return (
    <article className="card flex h-full flex-col p-5">
      <p className="text-sm font-semibold text-brand">{kindSingular[r.kind]}</p>
      <h3 className="mt-1 font-display text-lg font-bold leading-snug">{r.title}</h3>
      {meta.length > 0 ? <p className="mt-1 text-sm text-ink-soft">{meta.join(" · ")}</p> : null}
      {r.description ? <p className="mt-3 line-clamp-3 text-ink-soft">{r.description}</p> : null}
      <p className="mt-3 text-xs text-ink-soft">Publié le {formatDate(r.published_at)}</p>
      <div className="mt-auto flex flex-wrap items-center gap-2 pt-4">
        <Link href={`/documents/${r.id}`} className="btn-primary">
          <Eye size={17} /> Consulter
        </Link>
        {r.has_file ? (
          // <a> volontaire : un <Link> pourrait précharger la route et fausser le compteur de téléchargements.
          <a href={`/documents/${r.id}/telecharger`} className="btn-outline">
            <Download size={17} /> Télécharger
          </a>
        ) : null}
        <span className="ml-auto">
          <FavoriteButton resourceId={r.id} initial={isFavorite} loggedIn={loggedIn} />
        </span>
      </div>
    </article>
  );
}
