"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

export function MarkAllRead() {
  const router = useRouter();
  const [pending, setPending] = useState(false);
  async function run() {
    setPending(true);
    const supabase = createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (user) await supabase.from("notifications").update({ read_at: new Date().toISOString() }).eq("user_id", user.id).is("read_at", null);
    setPending(false);
    router.refresh();
  }
  return (
    <button type="button" onClick={run} disabled={pending} className="btn-outline disabled:opacity-60">
      {pending ? "…" : "Tout marquer comme lu"}
    </button>
  );
}
