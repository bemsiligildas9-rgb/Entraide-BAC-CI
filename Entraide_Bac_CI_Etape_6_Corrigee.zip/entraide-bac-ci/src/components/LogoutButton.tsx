export function LogoutButton({ className = "btn-outline" }: { className?: string }) {
  return (
    <form action="/auth/deconnexion" method="post">
      <button type="submit" className={className}>Déconnexion</button>
    </form>
  );
}
