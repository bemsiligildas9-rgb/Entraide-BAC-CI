import Link from "next/link";
import { kindLabels, kindOrder } from "@/lib/labels";

type Opt = { slug: string; name: string };
export type FilterValues = { q?: string; kind?: string; matiere?: string; serie?: string; niveau?: string; annee?: string; epreuve?: string };

export function LibraryFilters({
  action,
  values,
  subjects,
  series,
  levels,
  years,
  epreuves,
  showKind = false,
  showSearch = true,
}: {
  action: string;
  values: FilterValues;
  subjects: Opt[];
  series: Opt[];
  levels?: Opt[];
  years?: number[];
  epreuves?: string[];
  showKind?: boolean;
  showSearch?: boolean;
}) {
  return (
    <form action={action} method="get" className="card grid gap-3 p-4 sm:grid-cols-2 lg:grid-cols-3" role="search">
      {showSearch ? (
        <div className="sm:col-span-2 lg:col-span-3">
          <label htmlFor="q" className="sr-only">Rechercher</label>
          <input id="q" name="q" type="search" defaultValue={values.q} placeholder="Rechercher un titre, un mot-clé…" className="input" maxLength={80} />
        </div>
      ) : null}
      {showKind ? (
        <Select id="kind" label="Type" value={values.kind} options={kindOrder.map((k) => ({ value: k, label: kindLabels[k] }))} />
      ) : null}
      <Select id="matiere" label="Matière" value={values.matiere} options={subjects.map((s) => ({ value: s.slug, label: s.name }))} />
      <Select id="serie" label="Série" value={values.serie} options={series.map((s) => ({ value: s.slug, label: s.name }))} />
      {levels ? <Select id="niveau" label="Classe" value={values.niveau} options={levels.map((l) => ({ value: l.slug, label: l.name }))} /> : null}
      {years ? <Select id="annee" label="Année" value={values.annee} options={years.map((y) => ({ value: String(y), label: String(y) }))} /> : null}
      {epreuves ? <Select id="epreuve" label="Épreuve" value={values.epreuve} options={epreuves.map((e) => ({ value: e, label: e }))} /> : null}
      <div className="flex items-end gap-2">
        <button type="submit" className="btn-primary">Filtrer</button>
        <Link href={action} className="btn-outline">Réinitialiser</Link>
      </div>
    </form>
  );
}

function Select({ id, label, value, options }: { id: string; label: string; value?: string; options: { value: string; label: string }[] }) {
  return (
    <div>
      <label htmlFor={id} className="mb-1 block text-sm font-semibold">{label}</label>
      <select id={id} name={id} defaultValue={value ?? ""} className="input">
        <option value="">Tous</option>
        {options.map((o) => (
          <option key={o.value} value={o.value}>{o.label}</option>
        ))}
      </select>
    </div>
  );
}
