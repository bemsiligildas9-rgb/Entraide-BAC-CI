export function Prose({ title, intro, children }: { title: string; intro?: string; children: React.ReactNode }) {
  return (
    <div className="container-page max-w-3xl py-12 sm:py-16">
      <h1 className="text-4xl font-extrabold sm:text-5xl">{title}</h1>
      {intro ? <p className="mt-3 text-lg text-ink-soft">{intro}</p> : null}
      <div className="mt-8 space-y-4 leading-relaxed [&_a]:font-semibold [&_a]:text-brand [&_a]:underline [&_h2]:!mt-10 [&_h2]:text-2xl [&_h2]:font-bold [&_li]:text-ink-soft [&_p]:text-ink-soft [&_ul]:list-disc [&_ul]:space-y-1.5 [&_ul]:pl-6">
        {children}
      </div>
    </div>
  );
}
