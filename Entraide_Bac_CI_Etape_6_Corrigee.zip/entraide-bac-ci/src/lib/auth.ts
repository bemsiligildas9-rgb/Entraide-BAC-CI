import { notFound, redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import type { Profile } from "@/lib/types";

export async function getUser() {
  try {
    const {
      data: { user },
    } = await createClient().auth.getUser();
    return user;
  } catch {
    return null;
  }
}

export async function requireUser() {
  const user = await getUser();
  if (!user) redirect("/connexion");
  return user;
}

export async function getProfile(userId: string): Promise<Profile | null> {
  try {
    const { data } = await createClient()
      .from("profiles")
      .select("id, first_name, last_name, school, city, level_id, serie_id")
      .eq("id", userId)
      .maybeSingle();
    return (data as Profile | null) ?? null;
  } catch {
    return null;
  }
}

// N'autorise que les chemins internes (empêche les redirections vers un site externe).
export function safeRedirectPath(value: string | null | undefined, fallback = "/tableau-de-bord") {
  if (value && value.startsWith("/") && !value.startsWith("//") && !value.includes("\\")) return value;
  return fallback;
}

// Le droit administrateur est vérifié par la base (fonction public.is_admin), jamais par le navigateur.
export async function isAdmin(): Promise<boolean> {
  try {
    const { data } = await createClient().rpc("is_admin");
    return data === true;
  } catch {
    return false;
  }
}

// Pour les pages /admin : visiteur -> connexion ; élève -> 404 (la page n'est pas révélée).
export async function requireAdmin() {
  const user = await requireUser();
  if (!(await isAdmin())) notFound();
  return user;
}
