import { createClient } from "@/lib/supabase/server";

export type QuizItem = {
  id: string;
  title: string;
  description: string | null;
  subjects: { name: string } | null;
  levels: { name: string } | null;
  series: { name: string } | null;
  questionCount: number;
};

type Joined<T> = T | T[] | null;
const first = <T,>(v: Joined<T>): T | null => (Array.isArray(v) ? (v[0] ?? null) : v);

export async function getQuizzes(f: { subjectId?: number; serieId?: number }): Promise<QuizItem[]> {
  try {
    let q = createClient()
      .from("quizzes")
      .select("id, title, description, subjects(name), levels(name), series(name), quiz_questions(count)")
      .eq("is_published", true);
    if (f.subjectId) q = q.eq("subject_id", f.subjectId);
    if (f.serieId) q = q.or(`serie_id.eq.${f.serieId},serie_id.is.null`);
    const { data, error } = await q.order("created_at", { ascending: false }).limit(60);
    if (error || !data) return [];
    return (data as Record<string, unknown>[])
      .map((r) => ({
        id: r.id as string,
        title: r.title as string,
        description: (r.description as string | null) ?? null,
        subjects: first(r.subjects as Joined<{ name: string }>),
        levels: first(r.levels as Joined<{ name: string }>),
        series: first(r.series as Joined<{ name: string }>),
        questionCount: ((r.quiz_questions as { count: number }[] | null)?.[0]?.count as number) ?? 0,
      }))
      .filter((r) => r.questionCount > 0);
  } catch {
    return [];
  }
}

// Dernier résultat de l'élève pour chaque quiz : { quizId -> { score, total } }
export async function getLastScores(userId: string | undefined): Promise<Map<string, { score: number; total: number }>> {
  const map = new Map<string, { score: number; total: number }>();
  if (!userId) return map;
  try {
    const { data } = await createClient()
      .from("quiz_attempts")
      .select("quiz_id, score, total")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
      .limit(200);
    for (const a of (data ?? []) as { quiz_id: string; score: number; total: number }[]) {
      if (!map.has(a.quiz_id)) map.set(a.quiz_id, { score: a.score, total: a.total });
    }
  } catch {
    /* base non configurée : aucun score */
  }
  return map;
}
