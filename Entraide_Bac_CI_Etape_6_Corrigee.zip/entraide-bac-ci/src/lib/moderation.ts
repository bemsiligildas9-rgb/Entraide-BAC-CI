// Filtre automatique des publications (en complément des signalements et de la modération manuelle).
// L'administrateur peut compléter cette liste (mots écrits sans accents, en minuscules).
const BLOCKED_WORDS = [
  "connard", "connasse", "salope", "pute", "encule", "enculee", "batard", "batarde",
  "fils de pute", "nique ta mere", "ntm", "fdp", "ta gueule", "sale con",
];

const normalize = (s: string) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();

export function checkText(raw: string): string | null {
  const t = normalize(raw);
  for (const w of BLOCKED_WORDS) {
    if (new RegExp(`(^|[^a-z0-9])${w}([^a-z0-9]|$)`).test(t)) {
      return "Ton message contient des propos injurieux. Reformule-le avec respect.";
    }
  }
  const links = (raw.match(/https?:\/\/|www\./gi) ?? []).length;
  if (links > 2) return "Trop de liens : les messages publicitaires ne sont pas acceptés.";
  if (/(.)\1{9,}/.test(raw)) return "Évite de répéter le même caractère de nombreuses fois.";
  const letters = raw.replace(/[^A-Za-zÀ-ÿ]/g, "");
  if (letters.length > 30 && letters.replace(/[^A-ZÀ-Þ]/g, "").length / letters.length > 0.7) {
    return "Évite d'écrire tout en majuscules.";
  }
  return null;
}
