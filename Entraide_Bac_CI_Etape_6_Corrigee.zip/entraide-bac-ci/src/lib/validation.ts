import { z } from "zod";

const password = z.string().min(8, "8 caractères minimum").max(72, "72 caractères maximum");

export const signupSchema = z.object({
  lastName: z.string().trim().min(1, "Indique ton nom").max(80),
  firstName: z.string().trim().min(1, "Indique ton prénom").max(80),
  email: z.string().trim().toLowerCase().email("Adresse e-mail invalide"),
  password,
  school: z.string().trim().max(120).optional(),
  level: z.string().min(1, "Choisis ta classe"),
  serie: z.string().min(1, "Choisis ta série"),
  city: z.string().trim().min(1, "Indique ta ville").max(80),
});

export const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email("Adresse e-mail invalide"),
  password: z.string().min(1, "Indique ton mot de passe"),
});

export const emailSchema = z.object({ email: z.string().trim().toLowerCase().email("Adresse e-mail invalide") });

export const profileSchema = z.object({
  lastName: z.string().trim().min(1, "Indique ton nom").max(80),
  firstName: z.string().trim().min(1, "Indique ton prénom").max(80),
  school: z.string().trim().max(120).optional(),
  level: z.string().min(1, "Choisis ta classe"),
  serie: z.string().min(1, "Choisis ta série"),
  city: z.string().trim().min(1, "Indique ta ville").max(80),
});

export const passwordChangeSchema = z
  .object({ password, confirm: z.string() })
  .refine((v) => v.password === v.confirm, { message: "Les mots de passe ne correspondent pas", path: ["confirm"] });

export function fieldErrors(error: z.ZodError) {
  const out: Record<string, string> = {};
  for (const issue of error.issues) {
    const key = String(issue.path[0]);
    if (!out[key]) out[key] = issue.message;
  }
  return out;
}
