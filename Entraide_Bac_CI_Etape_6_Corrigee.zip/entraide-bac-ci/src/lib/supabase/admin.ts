import "server-only";
import { createClient } from "@supabase/supabase-js";

// Client à privilèges élevés (contourne la RLS) : réservé au serveur, utilisé uniquement
// pour la gestion des comptes, APRÈS vérification du rôle administrateur.
export function createAdminClient() {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!key) throw new Error("SUPABASE_SERVICE_ROLE_KEY n'est pas configurée");
  return createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, key, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}
