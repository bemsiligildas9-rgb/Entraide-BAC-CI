import type { ResourceKind } from "./types";

export const kindLabels: Record<ResourceKind, string> = {
  cours: "Cours",
  exercice: "Exercices",
  corrige: "Corrigés",
  annale: "Annales",
  fiche: "Fiches de révision",
  methode: "Fiches de méthode",
  video: "Vidéos",
};

export const kindSingular: Record<ResourceKind, string> = {
  cours: "Cours",
  exercice: "Exercice",
  corrige: "Corrigé",
  annale: "Annale",
  fiche: "Fiche de révision",
  methode: "Fiche de méthode",
  video: "Vidéo",
};

export const kindOrder: ResourceKind[] = ["cours", "fiche", "exercice", "corrige", "annale", "methode", "video"];

export const serieTaglines: Record<string, string> = {
  bepc: "Brevet d'Études du Premier Cycle",
  a: "Lettres et philosophie",
  c: "Mathématiques et sciences physiques",
  d: "Mathématiques et sciences de la nature",
  e: "Mathématiques et technique",
  f: "Technologies industrielles",
  g: "Gestion et administration",
};

export function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" });
}

export function parseKind(v: string | undefined): ResourceKind | undefined {
  return kindOrder.includes(v as ResourceKind) ? (v as ResourceKind) : undefined;
}

export function toInt(v: string | undefined): number | undefined {
  const n = Number(v);
  return v && Number.isInteger(n) && n > 0 ? n : undefined;
}

export function str(v: string | string[] | undefined): string | undefined {
  const s = Array.isArray(v) ? v[0] : v;
  return s && s.trim() ? s.trim() : undefined;
}
