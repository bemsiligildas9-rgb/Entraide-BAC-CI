import { createClient } from "@/lib/supabase/server";

export type PostKind = "question" | "methode";
export const postKindLabels: Record<PostKind, string> = { question: "Question", methode: "Méthode partagée" };

export type PostSummary = {
  id: string;
  kind: PostKind;
  title: string;
  body: string;
  created_at: string;
  author_id: string;
  authorName: string;
  subject: string | null;
  answers: number;
  reactions: number;
};

type Joined<T> = T | T[] | null;
const first = <T,>(v: Joined<T>): T | null => (Array.isArray(v) ? (v[0] ?? null) : v);

export async function getAuthorNames(ids: string[]): Promise<Map<string, string>> {
  const map = new Map<string, string>();
  const unique = Array.from(new Set(ids));
  if (unique.length === 0) return map;
  try {
    const { data } = await createClient().from("public_profiles").select("id, display_name").in("id", unique);
    for (const p of (data ?? []) as { id: string; display_name: string }[]) map.set(p.id, p.display_name);
  } catch {
    /* noms indisponibles */
  }
  return map;
}

// Même nettoyage que pour la bibliothèque : retire les caractères spéciaux du filtre PostgREST et les jokers ILIKE.
export function cleanTerm(input?: string) {
  return (input ?? "").replace(/[%_,()*\\"'`:;]/g, " ").replace(/\s+/g, " ").trim().slice(0, 80);
}

export async function getPosts(f: { q?: string; subjectId?: number; kind?: PostKind; page?: number; pageSize?: number }): Promise<{ items: PostSummary[]; total: number }> {
  try {
    const pageSize = f.pageSize ?? 15;
    const page = Math.max(1, f.page ?? 1);
    let q = createClient()
      .from("posts")
      .select("id, kind, title, body, created_at, author_id, subjects(name), comments(count), post_reactions(count)", { count: "exact" })
      .eq("status", "visible");
    if (f.kind) q = q.eq("kind", f.kind);
    if (f.subjectId) q = q.eq("subject_id", f.subjectId);
    const term = cleanTerm(f.q);
    if (term) q = q.or(`title.ilike.%${term}%,body.ilike.%${term}%`);
    const { data, count, error } = await q.order("created_at", { ascending: false }).range((page - 1) * pageSize, page * pageSize - 1);
    if (error || !data) return { items: [], total: 0 };
    const rows = data as unknown as Record<string, unknown>[];
    const names = await getAuthorNames(rows.map((r) => r.author_id as string));
    const items = rows.map((r) => ({
      id: r.id as string,
      kind: r.kind as PostKind,
      title: r.title as string,
      body: r.body as string,
      created_at: r.created_at as string,
      author_id: r.author_id as string,
      authorName: names.get(r.author_id as string) ?? "Élève",
      subject: first(r.subjects as Joined<{ name: string }>)?.name ?? null,
      answers: (r.comments as { count: number }[] | null)?.[0]?.count ?? 0,
      reactions: (r.post_reactions as { count: number }[] | null)?.[0]?.count ?? 0,
    }));
    return { items, total: count ?? items.length };
  } catch {
    return { items: [], total: 0 };
  }
}
