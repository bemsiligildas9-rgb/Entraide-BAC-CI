export const site = {
  name: "Entraide Bac CI",
  fullName: "Entraide Bac CI — By Gildas",
  signature: "By Gildas",
  slogan: "Réussir le Bac, ensemble !",
  description:
    "Cours, exercices corrigés, annales, fiches de révision et quiz pour préparer le BEPC et le Baccalauréat en Côte d'Ivoire.",
  owner: "Gildas Bemsili",
  url: process.env.NEXT_PUBLIC_SITE_URL ?? "https://entraidebacci.com",
} as const;
