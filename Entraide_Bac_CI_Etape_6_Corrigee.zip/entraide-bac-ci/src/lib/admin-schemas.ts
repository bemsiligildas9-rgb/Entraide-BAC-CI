import { z } from "zod";

export const RESOURCE_KINDS = ["cours", "exercice", "corrige", "annale", "fiche", "methode", "video"] as const;
export const SETTING_KEYS = ["contact_email", "whatsapp_url", "facebook_url", "tiktok_url", "instagram_url"] as const;

const posIntNull = z.number().int().positive().nullable();

export const resourceSchema = z
  .object({
    id: z.string().uuid().optional(),
    kind: z.enum(RESOURCE_KINDS),
    title: z.string().trim().min(3, "Le titre doit contenir au moins 3 caractères").max(200),
    description: z.string().trim().max(2000, "Description trop longue (2000 caractères maximum)").nullable(),
    subjectId: z.number({ invalid_type_error: "Choisis une matière" }).int().positive("Choisis une matière"),
    levelId: posIntNull,
    serieId: posIntNull,
    chapterId: posIntNull,
    filePath: z.string().regex(/^(cours|exercice|corrige|annale|fiche|methode|video)\/[A-Za-z0-9._-]{1,200}$/, "Chemin de fichier invalide").nullable(),
    fileSize: z.number().int().nonnegative().nullable(),
    videoUrl: z.string().trim().url("Lien vidéo invalide").startsWith("https://", "Le lien vidéo doit commencer par https://").nullable(),
    examYear: z.number().int().min(1960, "Année invalide").max(2100, "Année invalide").nullable(),
    epreuve: z.string().trim().max(120).nullable(),
    publishedDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Date de publication invalide"),
    isPublished: z.boolean(),
  })
  .superRefine((v, ctx) => {
    if (!v.filePath && !v.videoUrl) ctx.addIssue({ code: "custom", path: ["filePath"], message: "Ajoute un fichier ou un lien vidéo" });
    if (v.kind === "annale") {
      if (!v.examYear) ctx.addIssue({ code: "custom", path: ["examYear"], message: "Indique l'année de l'examen" });
      if (!v.serieId) ctx.addIssue({ code: "custom", path: ["serieId"], message: "Choisis la série ou l'examen concerné" });
    }
  });
export type ResourceInput = z.infer<typeof resourceSchema>;

export const quizSchema = z
  .object({
    id: z.string().uuid().optional(),
    title: z.string().trim().min(3, "Le titre doit contenir au moins 3 caractères").max(200),
    description: z.string().trim().max(1000).nullable(),
    subjectId: posIntNull,
    levelId: posIntNull,
    serieId: posIntNull,
    isPublished: z.boolean(),
    questions: z
      .array(
        z.object({
          prompt: z.string().trim().min(3, "énoncé trop court").max(1000),
          choices: z.array(z.string().trim().min(1, "un choix est vide").max(300)).min(2, "au moins 2 choix").max(8, "8 choix maximum"),
          correct: z.array(z.number().int().min(0).max(7)).min(1, "coche au moins une bonne réponse"),
          explanation: z.string().trim().max(1500).nullable(),
        }),
      )
      .min(1, "Ajoute au moins une question")
      .max(100, "100 questions maximum"),
  })
  .superRefine((v, ctx) => {
    v.questions.forEach((q, i) => {
      if (q.correct.some((c) => c >= q.choices.length)) {
        ctx.addIssue({ code: "custom", path: ["questions", i, "correct"], message: "bonne réponse invalide" });
      }
    });
  });
export type QuizInput = z.infer<typeof quizSchema>;

export function firstIssue(error: z.ZodError): string {
  const issue = error.issues[0];
  if (issue.path[0] === "questions" && typeof issue.path[1] === "number") return `Question ${issue.path[1] + 1} : ${issue.message}`;
  return issue.message;
}
