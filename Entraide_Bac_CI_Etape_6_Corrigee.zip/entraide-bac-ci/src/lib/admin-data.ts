import type { ChapterOption } from "@/components/admin/ResourceForm";
import { getLevels, getSeries, getSubjects } from "@/lib/data";
import { createClient } from "@/lib/supabase/server";

export async function getFormLists() {
  const [subjects, series, levels] = await Promise.all([getSubjects(), getSeries(), getLevels()]);
  let chapters: ChapterOption[] = [];
  try {
    const { data } = await createClient().from("chapters").select("id, subject_id, title").order("position").order("id");
    chapters = (data ?? []) as ChapterOption[];
  } catch {
    /* base non configurée */
  }
  return { subjects, series, levels, chapters };
}

export const one = <T,>(v: T | T[] | null | undefined): T | null => (Array.isArray(v) ? (v[0] ?? null) : (v ?? null));
