export type Level = { id: number; slug: string; name: string };
export type Serie = { id: number; slug: string; name: string; exam: "BEPC" | "BAC" };
export type Subject = { id: number; slug: string; name: string; description: string | null };
export type ResourceKind = "cours" | "exercice" | "corrige" | "annale" | "fiche" | "methode" | "video";
export type ResourceItem = {
  id: string;
  kind: ResourceKind;
  title: string;
  description: string | null;
  published_at: string;
  exam_year: number | null;
  epreuve: string | null;
  has_file: boolean;
  video_url: string | null;
  subjects: { name: string; slug: string } | null;
  levels: { name: string } | null;
  series: { name: string } | null;
};

export type Profile = {
  id: string;
  first_name: string;
  last_name: string;
  school: string | null;
  city: string | null;
  level_id: number | null;
  serie_id: number | null;
};
