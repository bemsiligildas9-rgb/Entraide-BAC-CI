export const navLinks = [
  { href: "/documents", label: "Documents" },
  { href: "/annales", label: "Annales" },
  { href: "/quiz", label: "Quiz" },
  { href: "/communaute", label: "Communauté" },
] as const;
