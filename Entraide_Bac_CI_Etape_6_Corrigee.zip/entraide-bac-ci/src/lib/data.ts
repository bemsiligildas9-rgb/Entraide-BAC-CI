import { createClient } from "@/lib/supabase/server";
import type { Level, ResourceItem, ResourceKind, Serie, Subject } from "@/lib/types";

// Chaque lecture renvoie une valeur par défaut si la base n'est pas (encore) configurée,
// afin que le site s'affiche toujours au lieu de planter.
async function safe<T>(run: () => PromiseLike<{ data: unknown; error: unknown }>, fallback: T): Promise<T> {
  try {
    const { data, error } = await run();
    if (error || data == null) return fallback;
    return data as T;
  } catch {
    return fallback;
  }
}

export const getLevels = () =>
  safe<Level[]>(() => createClient().from("levels").select("id, slug, name").order("position"), []);

export const getSeries = () =>
  safe<Serie[]>(() => createClient().from("series").select("id, slug, name, exam").order("position"), []);

export const getSubjects = (limit?: number) =>
  safe<Subject[]>(
    () => createClient().from("subjects").select("id, slug, name, description").order("position").limit(limit ?? 100),
    [],
  );

export const getSerieBySlug = (slug: string) =>
  safe<Serie | null>(
    () => createClient().from("series").select("id, slug, name, exam").eq("slug", slug).maybeSingle(),
    null,
  );

export const getSubjectBySlug = (slug: string) =>
  safe<Subject | null>(
    () => createClient().from("subjects").select("id, slug, name, description").eq("slug", slug).maybeSingle(),
    null,
  );

export async function getSubjectsForSerie(serieId: number): Promise<Subject[]> {
  const rows = await safe<{ subjects: Subject | Subject[] | null }[]>(
    () => createClient().from("serie_subjects").select("subjects(id, slug, name, description)").eq("serie_id", serieId),
    [],
  );
  return rows
    .map((r) => (Array.isArray(r.subjects) ? r.subjects[0] : r.subjects))
    .filter((s): s is Subject => !!s)
    .sort((a, b) => a.id - b.id);
}

const RESOURCE_COLUMNS =
  "id, kind, title, description, published_at, exam_year, epreuve, file_path, video_url, subjects(name, slug), levels(name), series(name)";

type Joined<T> = T | T[] | null;
const first = <T,>(v: Joined<T>): T | null => (Array.isArray(v) ? (v[0] ?? null) : v);

// Le chemin du fichier reste côté serveur : on ne transmet que "has_file".
function normalizeResources(rows: unknown[]): ResourceItem[] {
  return (rows as Record<string, unknown>[]).map((r) => ({
    id: r.id as string,
    kind: r.kind as ResourceKind,
    title: r.title as string,
    description: (r.description as string | null) ?? null,
    published_at: r.published_at as string,
    exam_year: (r.exam_year as number | null) ?? null,
    epreuve: (r.epreuve as string | null) ?? null,
    has_file: !!r.file_path,
    video_url: (r.video_url as string | null) ?? null,
    subjects: first(r.subjects as Joined<{ name: string; slug: string }>),
    levels: first(r.levels as Joined<{ name: string }>),
    series: first(r.series as Joined<{ name: string }>),
  }));
}

export async function getLatestResources(limit = 6): Promise<ResourceItem[]> {
  const rows = await safe<unknown[]>(
    () =>
      createClient()
        .from("resources")
        .select(RESOURCE_COLUMNS)
        .eq("is_published", true)
        .order("published_at", { ascending: false })
        .limit(limit),
    [],
  );
  return normalizeResources(rows);
}

export type ResourceFilters = {
  q?: string;
  kind?: ResourceKind;
  subjectId?: number;
  serieId?: number;
  levelId?: number;
  year?: number;
  epreuve?: string;
  strictSerie?: boolean; // annales : la série doit correspondre exactement
  orderByYear?: boolean;
  page?: number;
  pageSize?: number;
};

// Retire les caractères spéciaux du langage de filtre PostgREST et les jokers ILIKE.
function sanitizeSearch(input?: string) {
  return (input ?? "").replace(/[%_,()*\\"'`:;]/g, " ").replace(/\s+/g, " ").trim().slice(0, 80);
}

export async function getResources(f: ResourceFilters): Promise<{ items: ResourceItem[]; total: number }> {
  try {
    const pageSize = f.pageSize ?? 12;
    const page = Math.max(1, f.page ?? 1);
    let q = createClient().from("resources").select(RESOURCE_COLUMNS, { count: "exact" }).eq("is_published", true);
    if (f.kind) q = q.eq("kind", f.kind);
    if (f.subjectId) q = q.eq("subject_id", f.subjectId);
    if (f.levelId) q = q.eq("level_id", f.levelId);
    if (f.year) q = q.eq("exam_year", f.year);
    if (f.epreuve) q = q.eq("epreuve", f.epreuve);
    if (f.serieId) q = f.strictSerie ? q.eq("serie_id", f.serieId) : q.or(`serie_id.eq.${f.serieId},serie_id.is.null`);
    const term = sanitizeSearch(f.q);
    if (term) q = q.or(`title.ilike.%${term}%,description.ilike.%${term}%`);
    q = f.orderByYear
      ? q.order("exam_year", { ascending: false, nullsFirst: false }).order("published_at", { ascending: false })
      : q.order("published_at", { ascending: false });
    const { data, count, error } = await q.range((page - 1) * pageSize, page * pageSize - 1);
    if (error || !data) return { items: [], total: 0 };
    return { items: normalizeResources(data), total: count ?? data.length };
  } catch {
    return { items: [], total: 0 };
  }
}

export async function getAnnaleFacets(): Promise<{ years: number[]; epreuves: string[] }> {
  const rows = await safe<{ exam_year: number | null; epreuve: string | null }[]>(
    () => createClient().from("resources").select("exam_year, epreuve").eq("is_published", true).eq("kind", "annale"),
    [],
  );
  const years = Array.from(new Set(rows.map((r) => r.exam_year).filter((y): y is number => !!y))).sort((a, b) => b - a);
  const epreuves = Array.from(new Set(rows.map((r) => r.epreuve).filter((e): e is string => !!e))).sort();
  return { years, epreuves };
}

export async function getFavoriteIds(userId: string | undefined, resourceIds: string[]): Promise<Set<string>> {
  if (!userId || resourceIds.length === 0) return new Set();
  const rows = await safe<{ resource_id: string }[]>(
    () => createClient().from("favorites").select("resource_id").eq("user_id", userId).in("resource_id", resourceIds),
    [],
  );
  return new Set(rows.map((r) => r.resource_id));
}

export type Announcement = { id: string; title: string; body: string };

export const getActiveAnnouncements = (limit = 2) =>
  safe<Announcement[]>(
    () =>
      createClient()
        .from("announcements")
        .select("id, title, body")
        .eq("is_active", true)
        .order("created_at", { ascending: false })
        .limit(limit),
    [],
  );

export type ChapterItem = { id: number; title: string; levels: { name: string } | null };

export async function getChapters(subjectId: number, serieId?: number): Promise<ChapterItem[]> {
  const rows = await safe<{ id: number; title: string; levels: { name: string } | { name: string }[] | null }[]>(() => {
    let q = createClient().from("chapters").select("id, title, levels(name)").eq("subject_id", subjectId);
    if (serieId) q = q.or(`serie_id.eq.${serieId},serie_id.is.null`);
    return q.order("position").order("id");
  }, []);
  return rows.map((r) => ({ id: r.id, title: r.title, levels: first(r.levels) }));
}

export async function getUnreadCount(userId: string): Promise<number> {
  try {
    const { count } = await createClient()
      .from("notifications")
      .select("*", { count: "exact", head: true })
      .eq("user_id", userId)
      .is("read_at", null);
    return count ?? 0;
  } catch {
    return 0;
  }
}
