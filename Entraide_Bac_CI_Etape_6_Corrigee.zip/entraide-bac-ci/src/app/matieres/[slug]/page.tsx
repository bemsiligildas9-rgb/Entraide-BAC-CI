import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ResourceCard } from "@/components/ResourceCard";
import { getUser } from "@/lib/auth";
import { getChapters, getFavoriteIds, getResources, getSerieBySlug, getSubjectBySlug } from "@/lib/data";
import { kindLabels, kindOrder } from "@/lib/labels";

type Props = { params: { slug: string }; searchParams: { serie?: string } };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const subject = await getSubjectBySlug(params.slug);
  if (!subject) return {};
  return {
    title: subject.name,
    description: `Cours, fiches de révision, exercices corrigés et annales de ${subject.name}.`,
    alternates: { canonical: `/matieres/${subject.slug}` },
  };
}

export default async function MatierePage({ params, searchParams }: Props) {
  const subject = await getSubjectBySlug(params.slug);
  if (!subject) notFound();
  const serie = searchParams.serie ? await getSerieBySlug(searchParams.serie) : null;
  const [user, { items: resources }, chapters] = await Promise.all([
    getUser(),
    getResources({ subjectId: subject.id, serieId: serie?.id, pageSize: 100 }),
    getChapters(subject.id, serie?.id),
  ]);
  const favorites = await getFavoriteIds(user?.id, resources.map((r) => r.id));

  return (
    <div className="container-page py-12 sm:py-16">
      <nav aria-label="Fil d'Ariane" className="text-sm text-ink-soft">
        {serie ? (
          <>
            <Link href={`/series/${serie.slug}`} className="hover:text-brand">{serie.name}</Link> /{" "}
          </>
        ) : (
          <>
            <Link href="/#matieres" className="hover:text-brand">Matières</Link> /{" "}
          </>
        )}
        <span className="text-ink">{subject.name}</span>
      </nav>
      <h1 className="mt-4 text-4xl font-extrabold sm:text-5xl">{subject.name}</h1>
      {serie ? <p className="mt-3 text-lg text-ink-soft">Ressources pour le {serie.name}</p> : null}

      {chapters.length > 0 ? (
        <section className="mt-10" aria-labelledby="programme">
          <h2 id="programme" className="text-2xl font-bold">Chapitres du programme</h2>
          <ol className="card mt-4 divide-y divide-line">
            {chapters.map((c, i) => (
              <li key={c.id} className="flex items-baseline gap-3 p-4">
                <span className="font-display font-bold text-brand">{i + 1}.</span>
                <span className="font-semibold">{c.title}</span>
                {c.levels ? <span className="ml-auto text-sm text-ink-soft">{c.levels.name}</span> : null}
              </li>
            ))}
          </ol>
        </section>
      ) : null}

      {resources.length === 0 ? (
        <p className="card mt-10 p-6 text-ink-soft">Aucune ressource n'est encore publiée pour cette matière.</p>
      ) : (
        kindOrder.map((kind) => {
          const items = resources.filter((r) => r.kind === kind);
          if (items.length === 0) return null;
          return (
            <section key={kind} className="mt-10">
              <h2 className="text-2xl font-bold">{kindLabels[kind]}</h2>
              <ul className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {items.map((r) => (
                  <li key={r.id}>
                    <ResourceCard resource={r} isFavorite={favorites.has(r.id)} loggedIn={!!user} />
                  </li>
                ))}
              </ul>
            </section>
          );
        })
      )}
    </div>
  );
}
