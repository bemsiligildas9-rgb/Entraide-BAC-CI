import type { Metadata } from "next";
import Link from "next/link";
import { Prose } from "@/components/Prose";
import { site } from "@/lib/site";

export const metadata: Metadata = {
  title: "À propos",
  description: `${site.name} : une plateforme éducative créée par ${site.owner} pour aider les élèves de Côte d'Ivoire à réussir le BEPC et le Bac.`,
  alternates: { canonical: "/a-propos" },
};

export default function AboutPage() {
  return (
    <Prose title="À propos" intro={`${site.slogan}`}>
      <h2>Notre mission</h2>
      <p>
        {site.name} rassemble au même endroit ce dont les élèves de Côte d'Ivoire ont besoin pour préparer le BEPC et le Baccalauréat : cours,
        fiches de révision, exercices corrigés, annales, vidéos pédagogiques et conseils. L'objectif est simple : rendre la révision plus accessible,
        mieux organisée et plus collective.
      </p>
      <h2>Ce que tu y trouves</h2>
      <ul>
        <li>Des ressources classées par série (BEPC, Bac A, C, D, E, F, G), par matière et par classe.</li>
        <li>Une bibliothèque de documents à consulter et à télécharger.</li>
        <li>Des annales publiées par année, série, matière et type d'épreuve.</li>
        <li>Des quiz corrigés automatiquement, avec l'explication de chaque réponse et le suivi de tes résultats.</li>
        <li>Une communauté d'entraide pour poser des questions et partager des méthodes.</li>
      </ul>
      <h2>Une plateforme sérieuse</h2>
      <p>
        Les annales et les documents sont ajoutés par l'administrateur à partir de sources autorisées. Aucun sujet officiel n'est inventé.
        Vérifie toujours les consignes de ton établissement et des autorités scolaires pour tes examens.
      </p>
      <h2>Le créateur</h2>
      <p>
        {site.fullName} a été créée et appartient à <strong>{site.owner}</strong>, qui en est l'administrateur principal.
        Une idée, une correction, un document à proposer ? <Link href="/contact">Écris-nous</Link>.
      </p>
    </Prose>
  );
}
