import type { MetadataRoute } from "next";
import { site } from "@/lib/site";
import { createClient } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

async function rows(table: string, columns: string, filter?: (q: any) => any, limit = 1000) { // eslint-disable-line @typescript-eslint/no-explicit-any
  try {
    let q = createClient().from(table).select(columns).limit(limit);
    if (filter) q = filter(q);
    const { data } = await q;
    return (data ?? []) as unknown as Record<string, string>[];
  } catch {
    return [];
  }
}

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = site.url.replace(/\/$/, "");
  const now = new Date();
  const fixed = ["", "/documents", "/annales", "/quiz", "/communaute", "/a-propos", "/faq", "/contact", "/conditions-utilisation", "/politique-confidentialite", "/inscription"];
  const [series, subjects, resources, quizzes, posts] = await Promise.all([
    rows("series", "slug"),
    rows("subjects", "slug"),
    rows("resources", "id, updated_at", (q) => q.eq("is_published", true).lte("published_at", now.toISOString())),
    rows("quizzes", "id", (q) => q.eq("is_published", true)),
    rows("posts", "id, updated_at", (q) => q.eq("status", "visible"), 500),
  ]);
  return [
    ...fixed.map((p) => ({ url: `${base}${p}`, lastModified: now, changeFrequency: "weekly" as const, priority: p === "" ? 1 : 0.7 })),
    ...series.map((s) => ({ url: `${base}/series/${s.slug}`, lastModified: now, priority: 0.8 })),
    ...subjects.map((s) => ({ url: `${base}/matieres/${s.slug}`, lastModified: now, priority: 0.8 })),
    ...resources.map((r) => ({ url: `${base}/documents/${r.id}`, lastModified: new Date(r.updated_at), priority: 0.6 })),
    ...quizzes.map((z) => ({ url: `${base}/quiz/${z.id}`, lastModified: now, priority: 0.5 })),
    ...posts.map((p) => ({ url: `${base}/communaute/${p.id}`, lastModified: new Date(p.updated_at), priority: 0.4 })),
  ];
}
