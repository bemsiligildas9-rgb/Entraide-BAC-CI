import type { Metadata } from "next";
import Link from "next/link";
import { MarkAllRead } from "@/components/MarkAllRead";
import { requireUser } from "@/lib/auth";
import { formatDate } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";

export const metadata: Metadata = { title: "Notifications", robots: { index: false } };

export default async function NotificationsPage() {
  const user = await requireUser();
  const { data } = await createClient()
    .from("notifications")
    .select("id, title, body, link, read_at, created_at")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })
    .limit(50);
  const rows = (data ?? []) as { id: string; title: string; body: string | null; link: string | null; read_at: string | null; created_at: string }[];
  const unread = rows.filter((r) => !r.read_at).length;

  return (
    <div className="container-page max-w-3xl py-12 sm:py-16">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-3xl font-extrabold sm:text-4xl">Notifications</h1>
        {unread > 0 ? <MarkAllRead /> : null}
      </div>
      {rows.length === 0 ? (
        <p className="card mt-8 p-6 text-ink-soft">Aucune notification pour le moment. Tu en recevras quand quelqu'un répondra à tes publications.</p>
      ) : (
        <ul className="mt-8 space-y-3">
          {rows.map((n) => {
            const inner = (
              <>
                <p className="flex items-center gap-2 font-semibold">
                  {!n.read_at ? <span className="h-2.5 w-2.5 rounded-full bg-brand" aria-hidden="true" /> : null}
                  {n.title}
                  {!n.read_at ? <span className="sr-only">(non lue)</span> : null}
                </p>
                {n.body ? <p className="mt-1 text-ink-soft">{n.body}</p> : null}
                <p className="mt-1 text-sm text-ink-soft">{formatDate(n.created_at)}</p>
              </>
            );
            const safeLink = n.link && n.link.startsWith("/") && !n.link.startsWith("//") ? n.link : null;
            return (
              <li key={n.id}>
                {safeLink ? <Link href={safeLink} className="card block p-4 transition hover:border-brand">{inner}</Link> : <div className="card p-4">{inner}</div>}
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
