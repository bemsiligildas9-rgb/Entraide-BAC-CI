import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getSerieBySlug, getSubjectsForSerie } from "@/lib/data";
import { serieTaglines } from "@/lib/labels";

type Props = { params: { slug: string } };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const serie = await getSerieBySlug(params.slug);
  if (!serie) return {};
  return {
    title: `Préparation ${serie.name}`,
    description: `Cours, exercices corrigés et annales pour préparer le ${serie.name} en Côte d'Ivoire.`,
    alternates: { canonical: `/series/${serie.slug}` },
  };
}

export default async function SeriePage({ params }: Props) {
  const serie = await getSerieBySlug(params.slug);
  if (!serie) notFound();
  const subjects = await getSubjectsForSerie(serie.id);

  return (
    <div className="container-page py-12 sm:py-16">
      <nav aria-label="Fil d'Ariane" className="text-sm text-ink-soft">
        <Link href="/#categories" className="hover:text-brand">Séries</Link> / <span className="text-ink">{serie.name}</span>
      </nav>
      <h1 className="mt-4 text-4xl font-extrabold sm:text-5xl">Préparation {serie.name}</h1>
      <p className="mt-3 text-lg text-ink-soft">{serieTaglines[serie.slug] ?? ""}</p>
      <h2 className="mt-12 text-2xl font-bold">Matières</h2>
      {subjects.length === 0 ? (
        <p className="card mt-5 p-6 text-ink-soft">Aucune matière n'est encore associée à cette série.</p>
      ) : (
        <ul className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {subjects.map((m) => (
            <li key={m.id}>
              <Link href={`/matieres/${m.slug}?serie=${serie.slug}`} className="card block p-5 font-display text-lg font-bold transition hover:border-brand hover:text-brand">
                {m.name}
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
