import Link from "next/link";
import { ActionButton } from "@/components/admin/ActionButton";
import { ActionForm } from "@/components/admin/ActionForm";
import { Field } from "@/components/auth/Field";
import { one } from "@/lib/admin-data";
import { getLevels, getSeries, getSubjects } from "@/lib/data";
import { toInt } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";
import { addChapter, deleteChapter } from "../actions";

type Row = {
  id: number;
  title: string;
  position: number;
  subjects: { name: string } | { name: string }[] | null;
  series: { name: string } | { name: string }[] | null;
  levels: { name: string } | { name: string }[] | null;
};

export default async function AdminChapters({ searchParams }: { searchParams: { matiere?: string } }) {
  const filterId = toInt(searchParams.matiere);
  const [subjects, series, levels] = await Promise.all([getSubjects(), getSeries(), getLevels()]);
  let q = createClient().from("chapters").select("id, title, position, subjects(name), series(name), levels(name)");
  if (filterId) q = q.eq("subject_id", filterId);
  const { data } = await q.order("subject_id").order("position").order("id").limit(300);
  const rows = (data ?? []) as unknown as Row[];

  return (
    <div className="space-y-10">
      <section aria-labelledby="ajout">
        <h2 id="ajout" className="text-2xl font-bold">Ajouter un chapitre du programme</h2>
        <div className="card mt-5 max-w-2xl p-5">
          <ActionForm action={addChapter} submitLabel="Ajouter le chapitre">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field id="subject_id" label="Matière">
                <select id="subject_id" name="subject_id" defaultValue={filterId ?? ""} className="input" required>
                  <option value="" disabled>Choisir…</option>
                  {subjects.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
              </Field>
              <Field id="position" label="Ordre d'affichage" hint="1 s'affiche en premier.">
                <input id="position" name="position" type="number" min={0} max={1000} defaultValue={1} className="input" />
              </Field>
              <Field id="serie_id" label="Série">
                <select id="serie_id" name="serie_id" defaultValue="" className="input">
                  <option value="">Toutes</option>
                  {series.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
              </Field>
              <Field id="level_id" label="Classe">
                <select id="level_id" name="level_id" defaultValue="" className="input">
                  <option value="">Toutes</option>
                  {levels.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}
                </select>
              </Field>
            </div>
            <Field id="title" label="Titre du chapitre">
              <input id="title" name="title" className="input" maxLength={200} required />
            </Field>
          </ActionForm>
        </div>
      </section>

      <section aria-labelledby="liste">
        <h2 id="liste" className="text-2xl font-bold">Chapitres existants</h2>
        <nav aria-label="Filtrer par matière" className="mt-4 flex flex-wrap gap-2">
          <Link href="/admin/chapitres" className={`rounded-pill border px-3.5 py-1.5 text-sm font-semibold ${!filterId ? "border-brand text-brand" : "border-line text-ink-soft"}`}>Toutes</Link>
          {subjects.map((s) => (
            <Link key={s.id} href={`/admin/chapitres?matiere=${s.id}`} className={`rounded-pill border px-3.5 py-1.5 text-sm font-semibold ${filterId === s.id ? "border-brand text-brand" : "border-line text-ink-soft"}`}>{s.name}</Link>
          ))}
        </nav>
        {rows.length === 0 ? (
          <p className="card mt-5 p-5 text-ink-soft">Aucun chapitre pour ce filtre.</p>
        ) : (
          <ul className="card mt-5 divide-y divide-line">
            {rows.map((c) => (
              <li key={c.id} className="flex flex-wrap items-center justify-between gap-3 p-4">
                <div>
                  <p className="font-semibold">{c.position}. {c.title}</p>
                  <p className="text-sm text-ink-soft">{[one(c.subjects)?.name, one(c.series)?.name, one(c.levels)?.name].filter(Boolean).join(" · ")}</p>
                </div>
                <ActionButton action={deleteChapter.bind(null, c.id)} label="Supprimer" variant="danger" confirm="Supprimer ce chapitre ?" />
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
