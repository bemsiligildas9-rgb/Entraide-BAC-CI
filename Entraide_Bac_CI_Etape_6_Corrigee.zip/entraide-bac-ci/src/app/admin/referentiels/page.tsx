import { ActionButton } from "@/components/admin/ActionButton";
import { ActionForm } from "@/components/admin/ActionForm";
import { Field } from "@/components/auth/Field";
import { getLevels, getSeries, getSubjects } from "@/lib/data";
import { createClient } from "@/lib/supabase/server";
import { addLevel, addSubject, deleteLevel, deleteSubject, updateSubject } from "../actions";

export default async function Referentiels() {
  const [subjects, series, levels] = await Promise.all([getSubjects(), getSeries(), getLevels()]);
  const { data } = await createClient().from("serie_subjects").select("serie_id, subject_id");
  const links = (data ?? []) as { serie_id: number; subject_id: number }[];
  const isLinked = (subjectId: number, serieId: number) => links.some((l) => l.subject_id === subjectId && l.serie_id === serieId);

  return (
    <div className="space-y-14">
      <section aria-labelledby="matieres">
        <h2 id="matieres" className="text-2xl font-bold">Matières</h2>
        <ul className="mt-5 space-y-4">
          {subjects.map((s) => (
            <li key={s.id} className="card p-4">
              <ActionForm action={updateSubject} submitLabel="Enregistrer" resetOnSuccess={false}>
                <input type="hidden" name="id" value={s.id} />
                <Field id={`name-${s.id}`} label="Nom de la matière">
                  <input id={`name-${s.id}`} name="name" defaultValue={s.name} className="input" maxLength={120} required />
                </Field>
                <fieldset>
                  <legend className="mb-2 text-sm font-semibold">Séries concernées</legend>
                  <div className="flex flex-wrap gap-x-5 gap-y-1">
                    {series.map((se) => (
                      <label key={se.id} className="flex min-h-[40px] items-center gap-2">
                        <input type="checkbox" name="series" value={se.id} defaultChecked={isLinked(s.id, se.id)} className="h-5 w-5 accent-[rgb(var(--brand))]" />
                        {se.name}
                      </label>
                    ))}
                  </div>
                </fieldset>
              </ActionForm>
              <div className="mt-3 border-t border-line pt-3">
                <ActionButton action={deleteSubject.bind(null, s.id)} label="Supprimer la matière" variant="danger" confirm={`Supprimer la matière « ${s.name} » ?`} />
              </div>
            </li>
          ))}
        </ul>

        <div className="card mt-6 p-5">
          <h3 className="font-display text-lg font-bold">Ajouter une matière</h3>
          <div className="mt-4">
            <ActionForm action={addSubject} submitLabel="Ajouter la matière">
              <Field id="new-subject" label="Nom de la matière">
                <input id="new-subject" name="name" className="input" maxLength={120} required />
              </Field>
              <fieldset>
                <legend className="mb-2 text-sm font-semibold">Séries concernées</legend>
                <div className="flex flex-wrap gap-x-5 gap-y-1">
                  {series.map((se) => (
                    <label key={se.id} className="flex min-h-[40px] items-center gap-2">
                      <input type="checkbox" name="series" value={se.id} className="h-5 w-5 accent-[rgb(var(--brand))]" />
                      {se.name}
                    </label>
                  ))}
                </div>
              </fieldset>
            </ActionForm>
          </div>
        </div>
      </section>

      <section aria-labelledby="classes">
        <h2 id="classes" className="text-2xl font-bold">Classes</h2>
        <ul className="card mt-5 divide-y divide-line">
          {levels.map((l) => (
            <li key={l.id} className="flex flex-wrap items-center justify-between gap-3 p-4">
              <span className="font-semibold">{l.name}</span>
              <ActionButton action={deleteLevel.bind(null, l.id)} label="Supprimer" variant="danger" confirm={`Supprimer la classe « ${l.name} » ?`} />
            </li>
          ))}
        </ul>
        <div className="card mt-6 p-5">
          <h3 className="font-display text-lg font-bold">Ajouter une classe</h3>
          <div className="mt-4">
            <ActionForm action={addLevel} submitLabel="Ajouter la classe">
              <Field id="new-level" label="Nom de la classe">
                <input id="new-level" name="name" className="input" maxLength={60} required />
              </Field>
            </ActionForm>
          </div>
        </div>
      </section>
    </div>
  );
}
