import { ActionButton } from "@/components/admin/ActionButton";
import { formatDate } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";
import { deleteMessage, markMessageRead } from "../actions";

export default async function AdminMessages() {
  const { data } = await createClient().from("contact_messages").select("id, name, email, message, is_read, created_at").order("created_at", { ascending: false }).limit(200);
  const rows = (data ?? []) as { id: string; name: string; email: string; message: string; is_read: boolean; created_at: string }[];

  return (
    <div>
      <h2 className="text-2xl font-bold">Messages reçus ({rows.length})</h2>
      <p className="mt-2 text-ink-soft">Réponds directement à l'adresse e-mail indiquée par l'élève.</p>
      {rows.length === 0 ? (
        <p className="card mt-6 p-6 text-ink-soft">Aucun message pour le moment.</p>
      ) : (
        <ul className="mt-6 space-y-3">
          {rows.map((m) => (
            <li key={m.id} className={`card p-5 ${m.is_read ? "" : "border-brand"}`}>
              <p className="flex flex-wrap items-center gap-x-3 gap-y-1">
                <span className="font-semibold">{m.name}</span>
                {!m.is_read ? <span className="rounded-pill bg-brand/10 px-2.5 py-0.5 text-xs font-bold text-brand">Nouveau</span> : null}
                <a href={`mailto:${m.email}`} className="break-all text-sm font-semibold text-brand hover:underline">{m.email}</a>
                <span className="text-sm text-ink-soft">{formatDate(m.created_at)}</span>
              </p>
              <p className="mt-3 whitespace-pre-line">{m.message}</p>
              <div className="mt-4 flex flex-wrap gap-2">
                <ActionButton action={markMessageRead.bind(null, m.id, !m.is_read)} label={m.is_read ? "Marquer comme non lu" : "Marquer comme lu"} />
                <ActionButton action={deleteMessage.bind(null, m.id)} label="Supprimer" variant="danger" confirm="Supprimer ce message ?" />
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
