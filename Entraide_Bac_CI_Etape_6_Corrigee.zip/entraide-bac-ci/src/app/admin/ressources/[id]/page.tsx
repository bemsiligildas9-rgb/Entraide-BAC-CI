import { notFound } from "next/navigation";
import { ResourceForm } from "@/components/admin/ResourceForm";
import { getFormLists } from "@/lib/admin-data";
import { UUID_RE } from "@/lib/files";
import { createClient } from "@/lib/supabase/server";
import type { ResourceKind } from "@/lib/types";

export default async function EditResource({ params }: { params: { id: string } }) {
  if (!UUID_RE.test(params.id)) notFound();
  const [lists, { data: r }] = await Promise.all([
    getFormLists(),
    createClient().from("resources").select("*").eq("id", params.id).maybeSingle(),
  ]);
  if (!r) notFound();
  return (
    <div>
      <h2 className="mb-6 text-2xl font-bold">Modifier la ressource</h2>
      <ResourceForm
        {...lists}
        initial={{
          id: r.id,
          kind: r.kind as ResourceKind,
          title: r.title,
          description: r.description,
          subjectId: r.subject_id,
          levelId: r.level_id,
          serieId: r.serie_id,
          chapterId: r.chapter_id,
          filePath: r.file_path,
          fileSize: r.file_size,
          videoUrl: r.video_url,
          examYear: r.exam_year,
          epreuve: r.epreuve,
          publishedDate: String(r.published_at).slice(0, 10),
          isPublished: r.is_published,
        }}
      />
    </div>
  );
}
