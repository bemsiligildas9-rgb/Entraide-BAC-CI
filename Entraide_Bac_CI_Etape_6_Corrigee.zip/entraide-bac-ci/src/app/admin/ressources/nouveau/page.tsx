import { ResourceForm } from "@/components/admin/ResourceForm";
import { getFormLists } from "@/lib/admin-data";

export default async function NewResource() {
  const lists = await getFormLists();
  return (
    <div>
      <h2 className="mb-6 text-2xl font-bold">Nouvelle ressource</h2>
      {lists.subjects.length === 0 ? (
        <p className="card p-6 text-ink-soft">Aucune matière n'existe encore : exécute le fichier seed.sql ou ajoute une matière dans « Matières et classes ».</p>
      ) : (
        <ResourceForm {...lists} />
      )}
    </div>
  );
}
