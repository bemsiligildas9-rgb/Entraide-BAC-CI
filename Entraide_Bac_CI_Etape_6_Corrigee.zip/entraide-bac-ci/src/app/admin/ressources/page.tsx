import Link from "next/link";
import { ActionButton } from "@/components/admin/ActionButton";
import { one } from "@/lib/admin-data";
import { formatDate, kindSingular } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";
import type { ResourceKind } from "@/lib/types";
import { deleteResource, toggleResourcePublished } from "../actions";

type Row = {
  id: string;
  kind: ResourceKind;
  title: string;
  is_published: boolean;
  published_at: string;
  exam_year: number | null;
  subjects: { name: string } | { name: string }[] | null;
  series: { name: string } | { name: string }[] | null;
};

export default async function AdminResources() {
  const { data } = await createClient()
    .from("resources")
    .select("id, kind, title, is_published, published_at, exam_year, subjects(name), series(name)")
    .order("created_at", { ascending: false })
    .limit(200);
  const rows = (data ?? []) as unknown as Row[];
  const now = Date.now();

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-2xl font-bold">Ressources ({rows.length})</h2>
        <Link href="/admin/ressources/nouveau" className="btn-primary">Ajouter une ressource</Link>
      </div>
      {rows.length === 0 ? (
        <p className="card mt-6 p-6 text-ink-soft">Aucune ressource pour le moment. Ajoute ton premier cours, exercice ou sujet d'examen.</p>
      ) : (
        <ul className="mt-6 space-y-3">
          {rows.map((r) => {
            const scheduled = r.is_published && new Date(r.published_at).getTime() > now;
            const status = !r.is_published ? "Brouillon" : scheduled ? `Programmé le ${formatDate(r.published_at)}` : "Publié";
            const meta = [kindSingular[r.kind], one(r.subjects)?.name, one(r.series)?.name, r.exam_year].filter(Boolean).join(" · ");
            return (
              <li key={r.id} className="card flex flex-wrap items-center justify-between gap-3 p-4">
                <div className="min-w-0">
                  <p className="font-semibold">{r.title}</p>
                  <p className="text-sm text-ink-soft">{meta} · {status}</p>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <Link href={`/admin/ressources/${r.id}`} className="btn-outline min-h-[40px] px-4">Modifier</Link>
                  <ActionButton action={toggleResourcePublished.bind(null, r.id, !r.is_published)} label={r.is_published ? "Masquer" : "Publier"} />
                  <ActionButton action={deleteResource.bind(null, r.id)} label="Supprimer" variant="danger" confirm="Supprimer définitivement cette ressource et son fichier ?" />
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
