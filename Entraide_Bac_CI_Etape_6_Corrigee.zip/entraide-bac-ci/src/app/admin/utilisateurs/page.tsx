import Link from "next/link";
import { ActionButton } from "@/components/admin/ActionButton";
import { requireAdmin } from "@/lib/auth";
import { getLevels, getSeries } from "@/lib/data";
import { formatDate, toInt } from "@/lib/labels";
import { createAdminClient } from "@/lib/supabase/admin";
import { createClient } from "@/lib/supabase/server";
import { deleteUser, setUserRole } from "../actions";

const PER_PAGE = 50;

export default async function AdminUsers({ searchParams }: { searchParams: { page?: string } }) {
  const me = await requireAdmin();
  const page = toInt(searchParams.page) ?? 1;

  let users: { id: string; email: string | undefined; created_at: string }[] = [];
  try {
    const { data, error } = await createAdminClient().auth.admin.listUsers({ page, perPage: PER_PAGE });
    if (error) throw error;
    users = data.users.map((u) => ({ id: u.id, email: u.email, created_at: u.created_at }));
  } catch {
    return (
      <div className="card max-w-2xl p-6">
        <h2 className="text-xl font-bold">Gestion des utilisateurs non configurée</h2>
        <p className="mt-2 text-ink-soft">
          Pour lister et gérer les comptes, ajoute la variable <code className="rounded bg-surface px-1.5 py-0.5">SUPABASE_SERVICE_ROLE_KEY</code> (Supabase &gt; Project Settings &gt; API, clé « service_role ») dans
          ton fichier <code className="rounded bg-surface px-1.5 py-0.5">.env.local</code> et dans les variables d'environnement de Vercel, puis redémarre le site. Cette clé est secrète : ne la publie jamais.
        </p>
      </div>
    );
  }

  const ids = users.map((u) => u.id);
  const supabase = createClient();
  const [{ data: profiles }, { data: roles }, series, levels] = await Promise.all([
    supabase.from("profiles").select("id, first_name, last_name, city, school, level_id, serie_id").in("id", ids),
    supabase.from("user_roles").select("user_id, role").in("user_id", ids),
    getSeries(),
    getLevels(),
  ]);
  const profileById = new Map(((profiles ?? []) as { id: string; first_name: string; last_name: string; city: string | null; school: string | null; level_id: number | null; serie_id: number | null }[]).map((p) => [p.id, p]));
  const roleById = new Map(((roles ?? []) as { user_id: string; role: string }[]).map((r) => [r.user_id, r.role]));

  return (
    <div>
      <h2 className="text-2xl font-bold">Utilisateurs</h2>
      <ul className="mt-6 space-y-3">
        {users.map((u) => {
          const p = profileById.get(u.id);
          const role = roleById.get(u.id) ?? "student";
          const isMe = u.id === me.id;
          const detail = [
            levels.find((l) => l.id === p?.level_id)?.name,
            series.find((s) => s.id === p?.serie_id)?.name,
            p?.city,
            p?.school,
          ].filter(Boolean).join(" · ");
          return (
            <li key={u.id} className="card p-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="font-semibold">
                    {p ? `${p.first_name} ${p.last_name}` : "Profil manquant"}
                    {role === "admin" ? <span className="ml-2 rounded-pill bg-brand/10 px-2.5 py-0.5 text-xs font-bold text-brand">Administrateur</span> : null}
                    {isMe ? <span className="ml-2 text-xs text-ink-soft">(toi)</span> : null}
                  </p>
                  <p className="break-all text-sm text-ink-soft">{u.email}</p>
                  <p className="text-sm text-ink-soft">{[detail, `Inscrit le ${formatDate(u.created_at)}`].filter(Boolean).join(" · ")}</p>
                </div>
                {!isMe ? (
                  <div className="flex flex-wrap gap-2">
                    <ActionButton
                      action={setUserRole.bind(null, u.id, role === "admin" ? "student" : "admin")}
                      label={role === "admin" ? "Retirer admin" : "Nommer admin"}
                      confirm={role === "admin" ? "Retirer les droits administrateur de ce compte ?" : "Donner les droits administrateur à ce compte ?"}
                    />
                    <ActionButton action={deleteUser.bind(null, u.id)} label="Supprimer" variant="danger" confirm="Supprimer définitivement ce compte et toutes ses données ?" />
                  </div>
                ) : null}
              </div>
            </li>
          );
        })}
      </ul>
      <nav aria-label="Pagination" className="mt-8 flex items-center justify-between">
        {page > 1 ? <Link href={`/admin/utilisateurs?page=${page - 1}`} className="btn-outline">Précédent</Link> : <span />}
        {users.length === PER_PAGE ? <Link href={`/admin/utilisateurs?page=${page + 1}`} className="btn-outline">Suivant</Link> : <span />}
      </nav>
    </div>
  );
}
