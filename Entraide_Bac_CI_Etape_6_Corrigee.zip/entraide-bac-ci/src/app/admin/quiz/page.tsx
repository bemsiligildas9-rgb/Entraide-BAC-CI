import Link from "next/link";
import { ActionButton } from "@/components/admin/ActionButton";
import { one } from "@/lib/admin-data";
import { createClient } from "@/lib/supabase/server";
import { deleteQuiz, toggleQuizPublished } from "../actions";

type Row = {
  id: string;
  title: string;
  is_published: boolean;
  subjects: { name: string } | { name: string }[] | null;
  quiz_questions: { count: number }[] | null;
};

export default async function AdminQuizzes() {
  const { data } = await createClient()
    .from("quizzes")
    .select("id, title, is_published, subjects(name), quiz_questions(count)")
    .order("created_at", { ascending: false })
    .limit(200);
  const rows = (data ?? []) as unknown as Row[];

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-2xl font-bold">Quiz ({rows.length})</h2>
        <Link href="/admin/quiz/nouveau" className="btn-primary">Créer un quiz</Link>
      </div>
      {rows.length === 0 ? (
        <p className="card mt-6 p-6 text-ink-soft">Aucun quiz pour le moment.</p>
      ) : (
        <ul className="mt-6 space-y-3">
          {rows.map((q) => {
            const count = q.quiz_questions?.[0]?.count ?? 0;
            return (
              <li key={q.id} className="card flex flex-wrap items-center justify-between gap-3 p-4">
                <div className="min-w-0">
                  <p className="font-semibold">{q.title}</p>
                  <p className="text-sm text-ink-soft">
                    {[one(q.subjects)?.name, `${count} question${count > 1 ? "s" : ""}`, q.is_published ? "Publié" : "Brouillon"].filter(Boolean).join(" · ")}
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <Link href={`/admin/quiz/${q.id}`} className="btn-outline min-h-[40px] px-4">Modifier</Link>
                  <ActionButton action={toggleQuizPublished.bind(null, q.id, !q.is_published)} label={q.is_published ? "Masquer" : "Publier"} />
                  <ActionButton action={deleteQuiz.bind(null, q.id)} label="Supprimer" variant="danger" confirm="Supprimer ce quiz et l'historique associé ?" />
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
