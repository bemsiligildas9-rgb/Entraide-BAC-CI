import { QuizForm } from "@/components/admin/QuizForm";
import { getFormLists } from "@/lib/admin-data";

export default async function NewQuiz() {
  const { subjects, series, levels } = await getFormLists();
  return (
    <div>
      <h2 className="mb-6 text-2xl font-bold">Nouveau quiz</h2>
      <QuizForm subjects={subjects} series={series} levels={levels} />
    </div>
  );
}
