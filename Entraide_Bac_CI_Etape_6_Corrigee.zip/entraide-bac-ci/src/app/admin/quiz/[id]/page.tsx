import { notFound } from "next/navigation";
import { QuizForm } from "@/components/admin/QuizForm";
import { getFormLists, one } from "@/lib/admin-data";
import { UUID_RE } from "@/lib/files";
import { createClient } from "@/lib/supabase/server";

type Key = { correct_indexes: number[]; explanation: string | null };
type QRow = { id: string; prompt: string; choices: unknown; quiz_answer_keys: Key | Key[] | null };

export default async function EditQuiz({ params }: { params: { id: string } }) {
  if (!UUID_RE.test(params.id)) notFound();
  const supabase = createClient();
  const [lists, { data: quiz }, { data: qs }] = await Promise.all([
    getFormLists(),
    supabase.from("quizzes").select("*").eq("id", params.id).maybeSingle(),
    supabase.from("quiz_questions").select("id, prompt, choices, quiz_answer_keys(correct_indexes, explanation)").eq("quiz_id", params.id).order("position").order("id"),
  ]);
  if (!quiz) notFound();

  const questions = ((qs ?? []) as unknown as QRow[]).map((q) => {
    const key = one(q.quiz_answer_keys);
    return {
      prompt: q.prompt,
      choices: Array.isArray(q.choices) ? q.choices.map(String) : ["", ""],
      correct: key?.correct_indexes ?? [],
      explanation: key?.explanation ?? "",
    };
  });

  return (
    <div>
      <h2 className="mb-6 text-2xl font-bold">Modifier le quiz</h2>
      <QuizForm
        subjects={lists.subjects}
        series={lists.series}
        levels={lists.levels}
        initial={{
          id: quiz.id,
          title: quiz.title,
          description: quiz.description ?? "",
          subjectId: quiz.subject_id,
          levelId: quiz.level_id,
          serieId: quiz.serie_id,
          isPublished: quiz.is_published,
          questions,
        }}
      />
    </div>
  );
}
