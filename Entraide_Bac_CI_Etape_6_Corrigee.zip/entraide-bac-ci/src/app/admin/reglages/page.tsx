import { ActionForm } from "@/components/admin/ActionForm";
import { Field } from "@/components/auth/Field";
import { createClient } from "@/lib/supabase/server";
import { saveSettings } from "../actions";

export default async function AdminSettings() {
  const { data } = await createClient().from("site_settings").select("key, value");
  const values: Record<string, string> = {};
  for (const r of (data ?? []) as { key: string; value: unknown }[]) values[r.key] = typeof r.value === "string" ? r.value : "";

  return (
    <div className="max-w-2xl">
      <h2 className="text-2xl font-bold">Contacts et réseaux sociaux</h2>
      <p className="mt-2 text-ink-soft">Ces informations s'affichent sur la page Contact. Laisse un champ vide pour ne pas l'afficher.</p>
      <div className="card mt-6 p-5">
        <ActionForm action={saveSettings} submitLabel="Enregistrer les réglages" resetOnSuccess={false}>
          <Field id="contact_email" label="Adresse e-mail de contact">
            <input id="contact_email" name="contact_email" type="email" defaultValue={values.contact_email} className="input" />
          </Field>
          <Field id="whatsapp_url" label="Lien WhatsApp" hint="Par exemple https://wa.me/ suivi du numéro, sans espaces ni signe +.">
            <input id="whatsapp_url" name="whatsapp_url" type="url" defaultValue={values.whatsapp_url} className="input" placeholder="https://wa.me/…" />
          </Field>
          <Field id="facebook_url" label="Lien Facebook">
            <input id="facebook_url" name="facebook_url" type="url" defaultValue={values.facebook_url} className="input" placeholder="https://" />
          </Field>
          <Field id="tiktok_url" label="Lien TikTok">
            <input id="tiktok_url" name="tiktok_url" type="url" defaultValue={values.tiktok_url} className="input" placeholder="https://" />
          </Field>
          <Field id="instagram_url" label="Lien Instagram">
            <input id="instagram_url" name="instagram_url" type="url" defaultValue={values.instagram_url} className="input" placeholder="https://" />
          </Field>
        </ActionForm>
      </div>
    </div>
  );
}
