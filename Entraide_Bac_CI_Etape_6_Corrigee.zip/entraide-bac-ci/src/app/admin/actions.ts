"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import type { ActionResult } from "@/lib/action-result";
import { firstIssue, quizSchema, resourceSchema, SETTING_KEYS } from "@/lib/admin-schemas";
import { slugify } from "@/lib/files";
import { createAdminClient } from "@/lib/supabase/admin";
import { createClient } from "@/lib/supabase/server";

// ---------- Sécurité : chaque action revérifie le rôle admin côté serveur ----------
async function adminContext() {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return null;
  const { data } = await supabase.rpc("is_admin");
  return data === true ? { supabase, user } : null;
}

const DENIED: ActionResult = { ok: false, error: "Accès réservé à l'administrateur." };

function fail(error: string | { code?: string; message?: string }): ActionResult {
  if (typeof error === "string") return { ok: false, error };
  if (error.code === "23505") return { ok: false, error: "Cet élément existe déjà." };
  if (error.code === "23503") return { ok: false, error: "Action impossible : cet élément est encore utilisé ailleurs." };
  if (error.code === "42501") return { ok: false, error: "Droits insuffisants." };
  return { ok: false, error: "L'opération a échoué. Réessaie dans un instant." };
}

function refresh() {
  revalidatePath("/admin", "layout");
  revalidatePath("/", "layout");
}

const uuid = z.string().uuid();
const posInt = (v: FormDataEntryValue | null) => {
  const n = Number(v);
  return Number.isInteger(n) && n > 0 ? n : null;
};
const text = (v: FormDataEntryValue | null) => (typeof v === "string" ? v.trim() : "");

// ---------- Ressources ----------
export async function saveResource(raw: unknown): Promise<ActionResult> {
  const ctx = await adminContext();
  if (!ctx) return DENIED;
  const parsed = resourceSchema.safeParse(raw);
  if (!parsed.success) return fail(firstIssue(parsed.error));
  const v = parsed.data;

  const row = {
    kind: v.kind,
    title: v.title,
    description: v.description || null,
    subject_id: v.subjectId,
    level_id: v.levelId,
    serie_id: v.serieId,
    chapter_id: v.chapterId,
    file_path: v.filePath,
    file_size: v.filePath ? v.fileSize : null,
    video_url: v.videoUrl,
    exam_year: v.kind === "annale" ? v.examYear : null,
    epreuve: v.kind === "annale" ? v.epreuve || null : null,
    is_published: v.isPublished,
    published_at: new Date(`${v.publishedDate}T06:00:00Z`).toISOString(),
  };

  if (v.id) {
    const { data: current } = await ctx.supabase.from("resources").select("file_path").eq("id", v.id).maybeSingle();
    const { error } = await ctx.supabase.from("resources").update(row).eq("id", v.id);
    if (error) return fail(error);
    if (current?.file_path && current.file_path !== v.filePath) {
      await ctx.supabase.storage.from("documents").remove([current.file_path]);
    }
    refresh();
    return { ok: true, id: v.id, message: "Ressource enregistrée." };
  }

  const { data, error } = await ctx.supabase.from("resources").insert({ ...row, created_by: ctx.user.id }).select("id").single();
  if (error) return fail(error);
  refresh();
  return { ok: true, id: data.id, message: "Ressource publiée." };
}

export async function deleteResource(id: string): Promise<ActionResult> {
  const ctx = await adminContext();
  if (!ctx) return DENIED;
  if (!uuid.safeParse(id).success) return fail("Identifiant invalide.");
  const { data: current } = await ctx.supabase.from("resources").select("file_path").eq("id", id).maybeSingle();
  const { error } = await ctx.supabase.from("resources").delete().eq("id", id);
  if (error) return fail(error);
  if (current?.file_path) await ctx.supabase.storage.from("documents").remove([current.file_path]);
  refresh();
  return { ok: true, message: "Ressource supprimée." };
}

export async function toggleResourcePublished(id: string, published: boolean): Promise<ActionResult> {
  const ctx = await adminContext();
  if (!ctx) return DENIED;
  if (!uuid.safeParse(id).success) return fail("Identifiant invalide.");
  const { error } = await ctx.supabase.from("resources").update({ is_published: published }).eq("id", id);
  if (error) return fail(error);
  refresh();
  return { ok: true };
}

// ---------- Quiz ----------
export async function saveQuiz(raw: unknown): Promise<ActionResult> {
  const ctx = await adminContext();
  if (!ctx) return DENIED;
  const parsed = quizSchema.safeParse(raw);
  if (!parsed.success) return fail(firstIssue(parsed.error));
  const v = parsed.data;
  const { supabase } = ctx;

  const quizRow = {
    title: v.title,
    description: v.description || null,
    subject_id: v.subjectId,
    level_id: v.levelId,
    serie_id: v.serieId,
    is_published: v.isPublished,
  };

  let quizId = v.id;
  if (quizId) {
    const { error } = await supabase.from("quizzes").update(quizRow).eq("id", quizId);
    if (error) return fail(error);
    const { error: delError } = await supabase.from("quiz_questions").delete().eq("quiz_id", quizId);
    if (delError) return fail(delError);
  } else {
    const { data, error } = await supabase.from("quizzes").insert({ ...quizRow, created_by: ctx.user.id }).select("id").single();
    if (error) return fail(error);
    quizId = data.id as string;
  }

  const questions = v.questions.map((q, i) => {
    const correct = Array.from(new Set(q.correct)).sort((a, b) => a - b);
    return { id: crypto.randomUUID(), q, correct, position: i + 1, multiple: correct.length > 1 };
  });

  const { error: qError } = await supabase.from("quiz_questions").insert(
    questions.map((x) => ({ id: x.id, quiz_id: quizId, position: x.position, prompt: x.q.prompt, choices: x.q.choices, multiple: x.multiple })),
  );
  if (qError) return fail(qError);

  const { error: kError } = await supabase.from("quiz_answer_keys").insert(
    questions.map((x) => ({ question_id: x.id, correct_indexes: x.correct, explanation: x.q.explanation || null })),
  );
  if (kError) {
    await supabase.from("quiz_questions").delete().eq("quiz_id", quizId); // évite un quiz sans corrigé
    return fail(kError);
  }
  refresh();
  return { ok: true, id: quizId, message: "Quiz enregistré." };
}

export async function deleteQuiz(id: string): Promise<ActionResult> {
  const ctx = await adminContext();
  if (!ctx) return DENIED;
  if (!uuid.safeParse(id).success) return fail("Identifiant invalide.");
  const { error } = await ctx.supabase.from("quizzes").delete().eq("id", id);
  if (error) return fail(error);
  refresh();
  return { ok: true, message: "Quiz supprimé." };
}

export async function toggleQuizPublished(id: string, published: boolean): Promise<ActionResult> {
  const ctx = await adminContext();
  if (!ctx) return DENIED;
  if (!uuid.safeParse(id).success) return fail("Identifiant invalide.");
  const { error } = await ctx.supabase.from("quizzes").update({ is_published: published }).eq("id", id);
  if (error) return fail(error);
  refresh();
  return { ok: true };
}

// ---------- Matières, classes, chapitres ----------
export async function addSubject(fd: FormData): Promise<ActionResult> {
  const ctx = await adminContext();
  if (!ctx) return DENIED;
  const name = text(fd.get("name"));
  if (name.length < 2 || name.length > 120) return fail("Le nom de la matière doit contenir entre 2 et 120 caractères.");
  const { data: last } = await ctx.supabase.from("subjects").select("position").order("position", { ascending: false }).limit(1).maybeSingle();
  const { data, error } = await ctx.supabase.from("subjects").insert({ name, slug: slugify(name), position: (last?.position ?? 0) + 1 }).select("id").single();
  if (error) return fail(error);
  const serieIds = fd.getAll("series").map(posInt).filter((n): n is number => n !== null);
  if (serieIds.length) {
    const { error: linkError } = await ctx.supabase.from("serie_subjects").insert(serieIds.map((serie_id) => ({ serie_id, subject_id: data.id })));
    if (linkError) return fail(linkError);
  }
  refresh();
  return { ok: true, message: "Matière ajoutée." };
}

export async function updateSubject(fd: FormData): Promise<ActionResult> {
  const ctx = await adminContext();
  if (!ctx) return DENIED;
  const id = posInt(fd.get("id"));
  const name = text(fd.get("name"));
  if (!id) return fail("Matière introuvable.");
  if (name.length < 2 || name.length > 120) return fail("Le nom de la matière doit contenir entre 2 et 120 caractères.");
  const { error } = await ctx.supabase.from("subjects").update({ name }).eq("id", id);
  if (error) return fail(error);
  const serieIds = fd.getAll("series").map(posInt).filter((n): n is number => n !== null);
  const { error: delError } = await ctx.supabase.from("serie_subjects").delete().eq("subject_id", id);
  if (delError) return fail(delError);
  if (serieIds.length) {
    const { error: linkError } = await ctx.supabase.from("serie_subjects").insert(serieIds.map((serie_id) => ({ serie_id, subject_id: id })));
    if (linkError) return fail(linkError);
  }
  refresh();
  return { ok: true, message: "Matière mise à jour." };
}

export async function deleteSubject(id: number): Promise<ActionResult> {
  const ctx = await adminContext();
  if (!ctx) return DENIED;
  const { error } = await ctx.supabase.from("subjects").delete().eq("id", id);
  if (error) {
    return error.code === "23503" ? fail("Impossible : des ressources utilisent encore cette matière. Supprime-les ou change leur matière d'abord.") : fail(error);
  }
  refresh();
  return { ok: true, message: "Matière supprimée." };
}

export async function addLevel(fd: FormData): Promise<ActionResult> {
  const ctx = await adminContext();
  if (!ctx) return DENIED;
  const name = text(fd.get("name"));
  if (name.length < 2 || name.length > 60) return fail("Le nom de la classe doit contenir entre 2 et 60 caractères.");
  const { data: last } = await ctx.supabase.from("levels").select("position").order("position", { ascending: false }).limit(1).maybeSingle();
  const { error } = await ctx.supabase.from("levels").insert({ name, slug: slugify(name), position: (last?.position ?? 0) + 1 });
  if (error) return fail(error);
  refresh();
  return { ok: true, message: "Classe ajoutée." };
}

export async function deleteLevel(id: number): Promise<ActionResult> {
  const ctx = await adminContext();
  if (!ctx) return DENIED;
  const { error } = await ctx.supabase.from("levels").delete().eq("id", id);
  if (error) return fail(error);
  refresh();
  return { ok: true, message: "Classe supprimée." };
}

export async function addChapter(fd: FormData): Promise<ActionResult> {
  const ctx = await adminContext();
  if (!ctx) return DENIED;
  const subjectId = posInt(fd.get("subject_id"));
  const title = text(fd.get("title"));
  if (!subjectId) return fail("Choisis une matière.");
  if (title.length < 2 || title.length > 200) return fail("Le titre du chapitre doit contenir entre 2 et 200 caractères.");
  const position = Math.max(0, Math.min(1000, Math.trunc(Number(fd.get("position")) || 0)));
  const { error } = await ctx.supabase
    .from("chapters")
    .insert({ subject_id: subjectId, serie_id: posInt(fd.get("serie_id")), level_id: posInt(fd.get("level_id")), title, position });
  if (error) return fail(error);
  refresh();
  return { ok: true, message: "Chapitre ajouté." };
}

export async function deleteChapter(id: number): Promise<ActionResult> {
  const ctx = await adminContext();
  if (!ctx) return DENIED;
  const { error } = await ctx.supabase.from("chapters").delete().eq("id", id);
  if (error) return fail(error);
  refresh();
  return { ok: true, message: "Chapitre supprimé." };
}

// ---------- Annonces ----------
export async function addAnnouncement(fd: FormData): Promise<ActionResult> {
  const ctx = await adminContext();
  if (!ctx) return DENIED;
  const title = text(fd.get("title"));
  const body = text(fd.get("body"));
  if (title.length < 3 || title.length > 200) return fail("Le titre doit contenir entre 3 et 200 caractères.");
  if (body.length < 3 || body.length > 3000) return fail("Le message doit contenir entre 3 et 3000 caractères.");
  const { error } = await ctx.supabase.from("announcements").insert({ title, body, is_active: true, created_by: ctx.user.id });
  if (error) return fail(error);
  refresh();
  return { ok: true, message: "Annonce publiée." };
}

export async function toggleAnnouncement(id: string, active: boolean): Promise<ActionResult> {
  const ctx = await adminContext();
  if (!ctx) return DENIED;
  if (!uuid.safeParse(id).success) return fail("Identifiant invalide.");
  const { error } = await ctx.supabase.from("announcements").update({ is_active: active }).eq("id", id);
  if (error) return fail(error);
  refresh();
  return { ok: true };
}

export async function deleteAnnouncement(id: string): Promise<ActionResult> {
  const ctx = await adminContext();
  if (!ctx) return DENIED;
  if (!uuid.safeParse(id).success) return fail("Identifiant invalide.");
  const { error } = await ctx.supabase.from("announcements").delete().eq("id", id);
  if (error) return fail(error);
  refresh();
  return { ok: true, message: "Annonce supprimée." };
}

// ---------- Réglages (contacts et réseaux) ----------
const httpsUrl = (msg: string) => z.union([z.literal(""), z.string().trim().url(msg).startsWith("https://", msg)]);
const settingsSchema = z.object({
  contact_email: z.union([z.literal(""), z.string().trim().toLowerCase().email("Adresse e-mail de contact invalide")]),
  whatsapp_url: httpsUrl("Le lien WhatsApp doit commencer par https:// (ex. https://wa.me/…)"),
  facebook_url: httpsUrl("Le lien Facebook doit commencer par https://"),
  tiktok_url: httpsUrl("Le lien TikTok doit commencer par https://"),
  instagram_url: httpsUrl("Le lien Instagram doit commencer par https://"),
});

export async function saveSettings(fd: FormData): Promise<ActionResult> {
  const ctx = await adminContext();
  if (!ctx) return DENIED;
  const parsed = settingsSchema.safeParse(Object.fromEntries(SETTING_KEYS.map((k) => [k, text(fd.get(k))])));
  if (!parsed.success) return fail(parsed.error.issues[0].message);
  const rows = SETTING_KEYS.map((key) => ({ key, value: parsed.data[key] }));
  const { error } = await ctx.supabase.from("site_settings").upsert(rows);
  if (error) return fail(error);
  refresh();
  return { ok: true, message: "Réglages enregistrés." };
}

// ---------- Utilisateurs (nécessite SUPABASE_SERVICE_ROLE_KEY) ----------
export async function setUserRole(userId: string, role: "student" | "admin"): Promise<ActionResult> {
  const ctx = await adminContext();
  if (!ctx) return DENIED;
  if (!uuid.safeParse(userId).success || (role !== "student" && role !== "admin")) return fail("Demande invalide.");
  if (userId === ctx.user.id) return fail("Tu ne peux pas modifier ton propre rôle.");
  try {
    const { error } = await createAdminClient().from("user_roles").update({ role }).eq("user_id", userId);
    if (error) return fail(error);
  } catch {
    return fail("La clé SUPABASE_SERVICE_ROLE_KEY n'est pas configurée sur le serveur.");
  }
  refresh();
  return { ok: true, message: role === "admin" ? "Administrateur ajouté." : "Droits administrateur retirés." };
}

export async function deleteUser(userId: string): Promise<ActionResult> {
  const ctx = await adminContext();
  if (!ctx) return DENIED;
  if (!uuid.safeParse(userId).success) return fail("Demande invalide.");
  if (userId === ctx.user.id) return fail("Tu ne peux pas supprimer ton propre compte ici.");
  try {
    const { error } = await createAdminClient().auth.admin.deleteUser(userId);
    if (error) return fail("Suppression impossible pour le moment.");
  } catch {
    return fail("La clé SUPABASE_SERVICE_ROLE_KEY n'est pas configurée sur le serveur.");
  }
  refresh();
  return { ok: true, message: "Compte supprimé." };
}

// ---------- Modération de la communauté ----------
export async function resolveReport(id: string): Promise<ActionResult> {
  const ctx = await adminContext();
  if (!ctx) return DENIED;
  if (!uuid.safeParse(id).success) return fail("Identifiant invalide.");
  const { error } = await ctx.supabase.from("reports").update({ resolved: true }).eq("id", id);
  if (error) return fail(error);
  refresh();
  return { ok: true, message: "Signalement classé." };
}

export async function moderateContent(target: "post" | "comment", id: string, action: "hide" | "restore" | "delete"): Promise<ActionResult> {
  const ctx = await adminContext();
  if (!ctx) return DENIED;
  if (!uuid.safeParse(id).success || (target !== "post" && target !== "comment") || !["hide", "restore", "delete"].includes(action)) {
    return fail("Demande invalide.");
  }
  const table = target === "post" ? "posts" : "comments";
  const { data: row } = await ctx.supabase.from(table).select("author_id").eq("id", id).maybeSingle();
  if (!row) return fail("Contenu introuvable.");

  if (action === "delete") {
    const { error } = await ctx.supabase.from(table).delete().eq("id", id); // les signalements liés sont supprimés en cascade
    if (error) return fail(error);
  } else {
    const { error } = await ctx.supabase.from(table).update({ status: action === "hide" ? "hidden" : "visible" }).eq("id", id);
    if (error) return fail(error);
    if (action === "hide") {
      await ctx.supabase.from("reports").update({ resolved: true }).eq(target === "post" ? "post_id" : "comment_id", id);
    }
  }

  if ((action === "hide" || action === "delete") && row.author_id !== ctx.user.id) {
    await ctx.supabase.from("notifications").insert({
      user_id: row.author_id,
      title: action === "hide" ? "Un de tes contenus a été masqué par la modération" : "Un de tes contenus a été supprimé par la modération",
      body: "Il ne respectait pas les règles de la communauté. Relis les conditions d'utilisation avant de publier à nouveau.",
      link: "/conditions-utilisation",
    });
  }
  refresh();
  return { ok: true, message: action === "restore" ? "Contenu rétabli." : action === "hide" ? "Contenu masqué." : "Contenu supprimé." };
}

// ---------- Messages de contact ----------
export async function markMessageRead(id: string, read: boolean): Promise<ActionResult> {
  const ctx = await adminContext();
  if (!ctx) return DENIED;
  if (!uuid.safeParse(id).success) return fail("Identifiant invalide.");
  const { error } = await ctx.supabase.from("contact_messages").update({ is_read: read }).eq("id", id);
  if (error) return fail(error);
  refresh();
  return { ok: true };
}

export async function deleteMessage(id: string): Promise<ActionResult> {
  const ctx = await adminContext();
  if (!ctx) return DENIED;
  if (!uuid.safeParse(id).success) return fail("Identifiant invalide.");
  const { error } = await ctx.supabase.from("contact_messages").delete().eq("id", id);
  if (error) return fail(error);
  refresh();
  return { ok: true, message: "Message supprimé." };
}
