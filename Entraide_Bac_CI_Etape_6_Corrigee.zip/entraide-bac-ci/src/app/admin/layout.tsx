import type { Metadata } from "next";
import { AdminNav } from "@/components/admin/AdminNav";
import { requireAdmin } from "@/lib/auth";

export const metadata: Metadata = { title: "Administration", robots: { index: false, follow: false } };

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  await requireAdmin();
  return (
    <div className="container-page py-10 sm:py-14">
      <h1 className="text-3xl font-extrabold sm:text-4xl">Administration</h1>
      <AdminNav />
      <div className="pt-8">{children}</div>
    </div>
  );
}
