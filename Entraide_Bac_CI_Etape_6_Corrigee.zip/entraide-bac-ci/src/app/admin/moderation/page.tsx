import Link from "next/link";
import { ActionButton } from "@/components/admin/ActionButton";
import { one } from "@/lib/admin-data";
import { getAuthorNames } from "@/lib/community";
import { formatDate } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";
import { moderateContent, resolveReport } from "../actions";

type P = { id: string; title: string; body: string; author_id: string; status: string };
type C = { id: string; body: string; author_id: string; post_id: string; status: string };
type Report = { id: string; reason: string; created_at: string; post_id: string | null; comment_id: string | null; posts: P | P[] | null; comments: C | C[] | null };

export default async function ModerationPage() {
  const supabase = createClient();
  const [{ data: reportRows }, { data: hiddenPosts }, { data: hiddenComments }] = await Promise.all([
    supabase.from("reports").select("id, reason, created_at, post_id, comment_id, posts(id, title, body, author_id, status), comments(id, body, author_id, post_id, status)").eq("resolved", false).order("created_at", { ascending: false }).limit(100),
    supabase.from("posts").select("id, title, body, author_id, status").eq("status", "hidden").order("created_at", { ascending: false }).limit(50),
    supabase.from("comments").select("id, body, author_id, post_id, status").eq("status", "hidden").order("created_at", { ascending: false }).limit(50),
  ]);
  const reports = (reportRows ?? []) as unknown as Report[];
  const hp = (hiddenPosts ?? []) as P[];
  const hc = (hiddenComments ?? []) as C[];

  const authorIds = [
    ...reports.flatMap((r) => [one(r.posts)?.author_id, one(r.comments)?.author_id]),
    ...hp.map((p) => p.author_id),
    ...hc.map((c) => c.author_id),
  ].filter((x): x is string => !!x);
  const names = await getAuthorNames(authorIds);

  return (
    <div className="space-y-12">
      <section aria-labelledby="signalements">
        <h2 id="signalements" className="text-2xl font-bold">Signalements à traiter ({reports.length})</h2>
        {reports.length === 0 ? (
          <p className="card mt-5 p-5 text-ink-soft">Aucun signalement en attente.</p>
        ) : (
          <ul className="mt-5 space-y-4">
            {reports.map((r) => {
              const post = one(r.posts);
              const comment = one(r.comments);
              const target: "post" | "comment" = post ? "post" : "comment";
              const content = post ?? comment;
              const link = post ? `/communaute/${post.id}` : comment ? `/communaute/${comment.post_id}` : null;
              return (
                <li key={r.id} className="card p-5">
                  <p className="text-sm font-semibold text-brand">{post ? "Publication" : "Commentaire"} signalé(e) le {formatDate(r.created_at)}</p>
                  {content ? (
                    <>
                      {post ? <p className="mt-1 font-display text-lg font-bold">{post.title}</p> : null}
                      <p className="mt-1 line-clamp-4 whitespace-pre-line">{content.body}</p>
                      <p className="mt-1 text-sm text-ink-soft">Auteur : {names.get(content.author_id) ?? "Élève"}</p>
                    </>
                  ) : (
                    <p className="mt-1 text-ink-soft">Contenu déjà supprimé.</p>
                  )}
                  <p className="mt-3 rounded-xl bg-surface p-3 text-sm"><span className="font-semibold">Motif : </span>{r.reason}</p>
                  <div className="mt-4 flex flex-wrap items-center gap-2">
                    {link ? <Link href={link} className="btn-outline min-h-[40px] px-4">Voir</Link> : null}
                    {content ? (
                      <>
                        <ActionButton action={moderateContent.bind(null, target, content.id, "hide")} label="Masquer" confirm="Masquer ce contenu ? L'auteur sera prévenu." />
                        <ActionButton action={moderateContent.bind(null, target, content.id, "delete")} label="Supprimer" variant="danger" confirm="Supprimer définitivement ce contenu ?" />
                      </>
                    ) : null}
                    <ActionButton action={resolveReport.bind(null, r.id)} label="Ignorer le signalement" />
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </section>

      <section aria-labelledby="masques">
        <h2 id="masques" className="text-2xl font-bold">Contenus masqués ({hp.length + hc.length})</h2>
        {hp.length + hc.length === 0 ? (
          <p className="card mt-5 p-5 text-ink-soft">Aucun contenu masqué.</p>
        ) : (
          <ul className="mt-5 space-y-3">
            {hp.map((p) => (
              <li key={p.id} className="card p-4">
                <p className="text-sm font-semibold text-brand">Publication · {names.get(p.author_id) ?? "Élève"}</p>
                <p className="font-semibold">{p.title}</p>
                <p className="line-clamp-2 text-ink-soft">{p.body}</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  <ActionButton action={moderateContent.bind(null, "post", p.id, "restore")} label="Rétablir" />
                  <ActionButton action={moderateContent.bind(null, "post", p.id, "delete")} label="Supprimer" variant="danger" confirm="Supprimer définitivement ?" />
                </div>
              </li>
            ))}
            {hc.map((c) => (
              <li key={c.id} className="card p-4">
                <p className="text-sm font-semibold text-brand">Commentaire · {names.get(c.author_id) ?? "Élève"}</p>
                <p className="line-clamp-3 whitespace-pre-line">{c.body}</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  <ActionButton action={moderateContent.bind(null, "comment", c.id, "restore")} label="Rétablir" />
                  <ActionButton action={moderateContent.bind(null, "comment", c.id, "delete")} label="Supprimer" variant="danger" confirm="Supprimer définitivement ?" />
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
