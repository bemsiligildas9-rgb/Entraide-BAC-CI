import { ActionButton } from "@/components/admin/ActionButton";
import { ActionForm } from "@/components/admin/ActionForm";
import { Field } from "@/components/auth/Field";
import { formatDate } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";
import { addAnnouncement, deleteAnnouncement, toggleAnnouncement } from "../actions";

export default async function AdminAnnouncements() {
  const { data } = await createClient().from("announcements").select("id, title, body, is_active, created_at").order("created_at", { ascending: false }).limit(100);
  const rows = (data ?? []) as { id: string; title: string; body: string; is_active: boolean; created_at: string }[];

  return (
    <div className="space-y-10">
      <section aria-labelledby="nouvelle">
        <h2 id="nouvelle" className="text-2xl font-bold">Nouvelle annonce</h2>
        <p className="mt-2 text-ink-soft">Les annonces actives s'affichent en haut de la page d'accueil.</p>
        <div className="card mt-5 max-w-2xl p-5">
          <ActionForm action={addAnnouncement} submitLabel="Publier l'annonce">
            <Field id="title" label="Titre">
              <input id="title" name="title" className="input" maxLength={200} required />
            </Field>
            <Field id="body" label="Message">
              <textarea id="body" name="body" rows={4} maxLength={3000} className="input py-2.5" required />
            </Field>
          </ActionForm>
        </div>
      </section>

      <section aria-labelledby="liste">
        <h2 id="liste" className="text-2xl font-bold">Annonces ({rows.length})</h2>
        {rows.length === 0 ? (
          <p className="card mt-5 p-5 text-ink-soft">Aucune annonce pour le moment.</p>
        ) : (
          <ul className="mt-5 space-y-3">
            {rows.map((a) => (
              <li key={a.id} className="card p-4">
                <p className="font-semibold">{a.title}</p>
                <p className="mt-1 whitespace-pre-line text-ink-soft">{a.body}</p>
                <p className="mt-2 text-sm text-ink-soft">{formatDate(a.created_at)} · {a.is_active ? "Visible sur le site" : "Masquée"}</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  <ActionButton action={toggleAnnouncement.bind(null, a.id, !a.is_active)} label={a.is_active ? "Masquer" : "Réactiver"} />
                  <ActionButton action={deleteAnnouncement.bind(null, a.id)} label="Supprimer" variant="danger" confirm="Supprimer cette annonce ?" />
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
