import Link from "next/link";
import { formatDate } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";

const head = { count: "exact" as const, head: true };

export default async function AdminHome() {
  const supabase = createClient();
  const weekAgo = new Date(Date.now() - 7 * 24 * 3600 * 1000).toISOString();
  const [students, recent, published, drafts, quizzes, downloads, views, attempts, latest, reports, messages] = await Promise.all([
    supabase.from("profiles").select("*", head),
    supabase.from("profiles").select("*", head).gte("created_at", weekAgo),
    supabase.from("resources").select("*", head).eq("is_published", true),
    supabase.from("resources").select("*", head).eq("is_published", false),
    supabase.from("quizzes").select("*", head).eq("is_published", true),
    supabase.from("resource_downloads").select("*", head),
    supabase.from("resource_views").select("*", head),
    supabase.from("quiz_attempts").select("*", head),
    supabase.from("profiles").select("id, first_name, last_name, city, created_at").order("created_at", { ascending: false }).limit(5),
    supabase.from("reports").select("*", head).eq("resolved", false),
    supabase.from("contact_messages").select("*", head).eq("is_read", false),
  ]);
  const n = (r: { count: number | null }) => r.count ?? 0;

  const stats = [
    { label: "Élèves inscrits", value: n(students) },
    { label: "Inscrits sur 7 jours", value: n(recent) },
    { label: "Ressources publiées", value: n(published) },
    { label: "Brouillons", value: n(drafts) },
    { label: "Quiz publiés", value: n(quizzes) },
    { label: "Téléchargements", value: n(downloads) },
    { label: "Consultations", value: n(views) },
    { label: "Quiz réalisés", value: n(attempts) },
    { label: "Signalements à traiter", value: n(reports), href: "/admin/moderation" },
    { label: "Messages non lus", value: n(messages), href: "/admin/messages" },
  ];
  const recentUsers = (latest.data ?? []) as { id: string; first_name: string; last_name: string; city: string | null; created_at: string }[];

  return (
    <div className="space-y-10">
      <div className="flex flex-wrap gap-3">
        <Link href="/admin/ressources/nouveau" className="btn-primary">Ajouter une ressource</Link>
        <Link href="/admin/quiz/nouveau" className="btn-outline">Créer un quiz</Link>
        <Link href="/admin/annonces" className="btn-outline">Publier une annonce</Link>
      </div>
      <dl className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label} className="card p-5">
            <dd className="font-display text-3xl font-extrabold text-brand">{s.value}</dd>
            <dt className="mt-1 text-sm text-ink-soft">
              {"href" in s && s.href ? <Link href={s.href} className="font-semibold underline">{s.label}</Link> : s.label}
            </dt>
          </div>
        ))}
      </dl>
      <section aria-labelledby="inscriptions">
        <h2 id="inscriptions" className="text-2xl font-bold">Dernières inscriptions</h2>
        {recentUsers.length === 0 ? (
          <p className="card mt-4 p-5 text-ink-soft">Aucune inscription pour le moment.</p>
        ) : (
          <ul className="card mt-4 divide-y divide-line">
            {recentUsers.map((u) => (
              <li key={u.id} className="flex items-center justify-between gap-3 p-4">
                <span className="font-semibold">{u.first_name} {u.last_name}</span>
                <span className="text-sm text-ink-soft">{[u.city, formatDate(u.created_at)].filter(Boolean).join(" · ")}</span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
