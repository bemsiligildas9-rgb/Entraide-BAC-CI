import Link from "next/link";

export default function NotFound() {
  return (
    <div className="container-page py-24">
      <h1 className="text-4xl font-extrabold">Page introuvable</h1>
      <p className="mt-3 text-ink-soft">Le lien est peut-être incorrect, ou la page a été déplacée.</p>
      <Link href="/" className="btn-primary mt-8">Retour à l'accueil</Link>
    </div>
  );
}
