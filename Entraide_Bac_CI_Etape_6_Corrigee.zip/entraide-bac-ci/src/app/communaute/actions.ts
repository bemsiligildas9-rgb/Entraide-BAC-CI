"use server";

import { z } from "zod";
import type { ActionResult } from "@/lib/action-result";
import { checkText } from "@/lib/moderation";
import { createClient } from "@/lib/supabase/server";

async function userContext() {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  return user ? { supabase, user } : null;
}

const LOGIN: ActionResult = { ok: false, error: "Connecte-toi pour participer à la communauté." };
const uuid = z.string().uuid();

// Les messages d'erreur des limites anti-spam (déclencheurs SQL) sont destinés à l'utilisateur.
function fail(error: { code?: string; message?: string }): ActionResult {
  if (error.message?.startsWith("Limite atteinte")) return { ok: false, error: error.message };
  if (error.code === "23505") return { ok: false, error: "Tu as déjà fait cette action." };
  return { ok: false, error: "L'opération a échoué. Réessaie dans un instant." };
}

const postSchema = z.object({
  kind: z.enum(["question", "methode"]),
  title: z.string().trim().min(5, "Le titre doit contenir au moins 5 caractères").max(200, "Titre trop long (200 caractères maximum)"),
  body: z.string().trim().min(5, "Le message doit contenir au moins 5 caractères").max(5000, "Message trop long (5000 caractères maximum)"),
  subjectId: z.number().int().positive().nullable(),
});

export async function createPost(raw: unknown): Promise<ActionResult> {
  const ctx = await userContext();
  if (!ctx) return LOGIN;
  const parsed = postSchema.safeParse(raw);
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message };
  const v = parsed.data;
  const blocked = checkText(`${v.title}\n${v.body}`);
  if (blocked) return { ok: false, error: blocked };
  const { data, error } = await ctx.supabase
    .from("posts")
    .insert({ author_id: ctx.user.id, kind: v.kind, title: v.title, body: v.body, subject_id: v.subjectId, status: "visible" })
    .select("id")
    .single();
  if (error) return fail(error);
  return { ok: true, id: data.id as string };
}

const commentSchema = z.object({
  postId: z.string().uuid(),
  body: z.string().trim().min(2, "Écris au moins 2 caractères").max(5000, "Commentaire trop long (5000 caractères maximum)"),
});

export async function addComment(raw: unknown): Promise<ActionResult> {
  const ctx = await userContext();
  if (!ctx) return LOGIN;
  const parsed = commentSchema.safeParse(raw);
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message };
  const blocked = checkText(parsed.data.body);
  if (blocked) return { ok: false, error: blocked };
  const { error } = await ctx.supabase
    .from("comments")
    .insert({ post_id: parsed.data.postId, author_id: ctx.user.id, body: parsed.data.body, status: "visible" });
  if (error) return fail(error);
  return { ok: true, message: "Réponse publiée." };
}

const reportSchema = z
  .object({
    postId: z.string().uuid().optional(),
    commentId: z.string().uuid().optional(),
    reason: z.string().trim().min(3, "Explique brièvement le problème").max(500, "500 caractères maximum"),
  })
  .refine((v) => Boolean(v.postId) !== Boolean(v.commentId), { message: "Contenu à signaler introuvable" });

export async function reportContent(raw: unknown): Promise<ActionResult> {
  const ctx = await userContext();
  if (!ctx) return { ok: false, error: "Connecte-toi pour signaler un contenu." };
  const parsed = reportSchema.safeParse(raw);
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message };
  const { error } = await ctx.supabase.from("reports").insert({
    reporter_id: ctx.user.id,
    post_id: parsed.data.postId ?? null,
    comment_id: parsed.data.commentId ?? null,
    reason: parsed.data.reason,
  });
  if (error) {
    return error.code === "23505"
      ? { ok: false, error: "Tu as déjà signalé ce contenu. Merci, la modération s'en occupe." }
      : fail(error);
  }
  return { ok: true, message: "Merci, ton signalement a été transmis à la modération." };
}

export async function deleteOwnPost(id: string): Promise<ActionResult> {
  const ctx = await userContext();
  if (!ctx) return LOGIN;
  if (!uuid.safeParse(id).success) return { ok: false, error: "Identifiant invalide." };
  const { error } = await ctx.supabase.from("posts").delete().eq("id", id).eq("author_id", ctx.user.id);
  if (error) return fail(error);
  return { ok: true, message: "Publication supprimée." };
}

export async function deleteOwnComment(id: string): Promise<ActionResult> {
  const ctx = await userContext();
  if (!ctx) return LOGIN;
  if (!uuid.safeParse(id).success) return { ok: false, error: "Identifiant invalide." };
  const { error } = await ctx.supabase.from("comments").delete().eq("id", id).eq("author_id", ctx.user.id);
  if (error) return fail(error);
  return { ok: true, message: "Commentaire supprimé." };
}
