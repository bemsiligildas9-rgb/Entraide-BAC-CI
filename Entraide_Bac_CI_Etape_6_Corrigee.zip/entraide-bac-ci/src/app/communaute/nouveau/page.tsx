import type { Metadata } from "next";
import { PostForm } from "@/components/community/PostForm";
import { requireUser } from "@/lib/auth";
import { getSubjects } from "@/lib/data";

export const metadata: Metadata = { title: "Nouvelle publication", robots: { index: false } };

export default async function NewPostPage() {
  await requireUser();
  const subjects = await getSubjects();
  return (
    <div className="container-page max-w-2xl py-12 sm:py-16">
      <h1 className="text-3xl font-extrabold sm:text-4xl">Nouvelle publication</h1>
      <p className="mt-3 text-ink-soft">
        Sois clair et respectueux. Les insultes, la publicité et les fausses informations sont interdites et peuvent être supprimées par la modération.
      </p>
      <div className="mt-8"><PostForm subjects={subjects} /></div>
    </div>
  );
}
