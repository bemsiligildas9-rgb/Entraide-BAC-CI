import { MessageSquare, ThumbsUp } from "lucide-react";
import type { Metadata } from "next";
import Link from "next/link";
import { Pagination } from "@/components/Pagination";
import { getUser } from "@/lib/auth";
import { postKindLabels, getPosts, type PostKind } from "@/lib/community";
import { getSubjects } from "@/lib/data";
import { formatDate, str } from "@/lib/labels";

export const metadata: Metadata = {
  title: "Communauté d'entraide",
  description: "Pose tes questions, partage tes méthodes et aide d'autres élèves à préparer le BEPC et le Bac.",
  alternates: { canonical: "/communaute" },
};

const PAGE_SIZE = 15;
type SP = Record<string, string | string[] | undefined>;

export default async function CommunityPage({ searchParams }: { searchParams: SP }) {
  const v = {
    q: str(searchParams.q)?.slice(0, 80),
    matiere: str(searchParams.matiere),
    type: str(searchParams.type) === "question" || str(searchParams.type) === "methode" ? (str(searchParams.type) as PostKind) : undefined,
  };
  const page = Math.max(1, Number(str(searchParams.page)) || 1);
  const [user, subjects] = await Promise.all([getUser(), getSubjects()]);
  const { items, total } = await getPosts({ q: v.q, kind: v.type, subjectId: subjects.find((s) => s.slug === v.matiere)?.id, page, pageSize: PAGE_SIZE });
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  return (
    <div className="container-page py-12 sm:py-16">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-4xl font-extrabold sm:text-5xl">Communauté d'entraide</h1>
          <p className="mt-3 max-w-2xl text-lg text-ink-soft">Pose une question, partage une méthode, aide les autres. Reste respectueux : les contenus sont modérés.</p>
        </div>
        <Link href={user ? "/communaute/nouveau" : "/connexion?redirige=/communaute/nouveau"} className="btn-primary">Poser une question</Link>
      </div>

      <form action="/communaute" method="get" role="search" className="card mt-8 grid gap-3 p-4 sm:grid-cols-[1fr_auto_auto_auto]">
        <div>
          <label htmlFor="q" className="sr-only">Rechercher une question</label>
          <input id="q" name="q" type="search" defaultValue={v.q} placeholder="Rechercher une question…" className="input" maxLength={80} />
        </div>
        <div>
          <label htmlFor="matiere" className="sr-only">Matière</label>
          <select id="matiere" name="matiere" defaultValue={v.matiere ?? ""} className="input">
            <option value="">Toutes les matières</option>
            {subjects.map((s) => <option key={s.id} value={s.slug}>{s.name}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="type" className="sr-only">Type</label>
          <select id="type" name="type" defaultValue={v.type ?? ""} className="input">
            <option value="">Tout</option>
            <option value="question">Questions</option>
            <option value="methode">Méthodes</option>
          </select>
        </div>
        <button type="submit" className="btn-primary">Filtrer</button>
      </form>

      {items.length === 0 ? (
        <p className="card mt-8 p-6 text-ink-soft">Aucune publication pour le moment. Sois le premier à poser une question !</p>
      ) : (
        <ul className="mt-8 space-y-3">
          {items.map((p) => (
            <li key={p.id}>
              <Link href={`/communaute/${p.id}`} className="card block p-5 transition hover:border-brand">
                <p className="text-sm font-semibold text-brand">{postKindLabels[p.kind]}{p.subject ? ` · ${p.subject}` : ""}</p>
                <h2 className="mt-1 font-display text-xl font-bold leading-snug">{p.title}</h2>
                <p className="mt-2 line-clamp-2 text-ink-soft">{p.body}</p>
                <p className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-ink-soft">
                  <span>{p.authorName} · {formatDate(p.created_at)}</span>
                  <span className="inline-flex items-center gap-1"><MessageSquare size={15} /> {p.answers} réponse{p.answers > 1 ? "s" : ""}</span>
                  <span className="inline-flex items-center gap-1"><ThumbsUp size={15} /> {p.reactions}</span>
                </p>
              </Link>
            </li>
          ))}
        </ul>
      )}
      <Pagination basePath="/communaute" params={{ q: v.q, matiere: v.matiere, type: v.type }} page={page} totalPages={totalPages} />
    </div>
  );
}
