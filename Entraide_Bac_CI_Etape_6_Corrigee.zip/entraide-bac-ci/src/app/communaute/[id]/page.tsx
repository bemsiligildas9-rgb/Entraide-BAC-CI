import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ActionButton } from "@/components/admin/ActionButton";
import { CommentForm } from "@/components/community/CommentForm";
import { ReactionButton } from "@/components/community/ReactionButton";
import { ReportButton } from "@/components/community/ReportButton";
import { getUser } from "@/lib/auth";
import { getAuthorNames, postKindLabels, type PostKind } from "@/lib/community";
import { UUID_RE } from "@/lib/files";
import { formatDate } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";
import { deleteOwnComment, deleteOwnPost } from "../actions";

type Props = { params: { id: string } };
type Joined<T> = T | T[] | null;
const one = <T,>(v: Joined<T>): T | null => (Array.isArray(v) ? (v[0] ?? null) : v);

async function loadPost(id: string) {
  if (!UUID_RE.test(id)) return null;
  try {
    const { data } = await createClient()
      .from("posts")
      .select("id, kind, title, body, created_at, author_id, status, subjects(name)")
      .eq("id", id)
      .maybeSingle();
    return data as unknown as { id: string; kind: PostKind; title: string; body: string; created_at: string; author_id: string; status: string; subjects: Joined<{ name: string }> } | null;
  } catch {
    return null;
  }
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const post = await loadPost(params.id);
  if (!post || post.status !== "visible") return { robots: { index: false } };
  return { title: post.title, description: post.body.slice(0, 160), alternates: { canonical: `/communaute/${post.id}` } };
}

export default async function PostPage({ params }: Props) {
  const post = await loadPost(params.id);
  if (!post) notFound();
  const supabase = createClient();
  const user = await getUser();

  const { data: commentRows } = await supabase
    .from("comments")
    .select("id, body, created_at, author_id")
    .eq("post_id", post.id)
    .order("created_at", { ascending: true });
  const comments = (commentRows ?? []) as { id: string; body: string; created_at: string; author_id: string }[];

  const [names, reactionCount, mine] = await Promise.all([
    getAuthorNames([post.author_id, ...comments.map((c) => c.author_id)]),
    supabase.from("post_reactions").select("*", { count: "exact", head: true }).eq("post_id", post.id),
    user ? supabase.from("post_reactions").select("post_id").eq("post_id", post.id).eq("user_id", user.id).maybeSingle() : Promise.resolve({ data: null }),
  ]);

  return (
    <div className="container-page max-w-3xl py-12 sm:py-16">
      <nav aria-label="Fil d'Ariane" className="text-sm text-ink-soft">
        <Link href="/communaute" className="hover:text-brand">Communauté</Link>
      </nav>
      {post.status !== "visible" ? (
        <p className="mt-4 rounded-xl border border-amber-400 bg-amber-50 px-4 py-3 text-sm text-amber-900 dark:bg-amber-500/10 dark:text-amber-200">
          Cette publication est masquée par la modération : seuls toi et les administrateurs peuvent la voir.
        </p>
      ) : null}
      <p className="mt-6 text-sm font-semibold text-brand">{postKindLabels[post.kind]}{one(post.subjects) ? ` · ${one(post.subjects)!.name}` : ""}</p>
      <h1 className="mt-1 text-3xl font-extrabold sm:text-4xl">{post.title}</h1>
      <p className="mt-2 text-sm text-ink-soft">{names.get(post.author_id) ?? "Élève"} · {formatDate(post.created_at)}</p>
      <p className="mt-6 whitespace-pre-line text-lg">{post.body}</p>

      <div className="mt-6 flex flex-wrap items-center gap-3">
        <ReactionButton postId={post.id} initialCount={reactionCount.count ?? 0} initialActive={!!mine.data} loggedIn={!!user} />
        {user?.id === post.author_id ? (
          <ActionButton action={deleteOwnPost.bind(null, post.id)} label="Supprimer ma publication" variant="danger" confirm="Supprimer cette publication et ses réponses ?" />
        ) : (
          <ReportButton postId={post.id} loggedIn={!!user} />
        )}
      </div>

      <section className="mt-12" aria-labelledby="reponses">
        <h2 id="reponses" className="text-2xl font-bold">{comments.length} réponse{comments.length > 1 ? "s" : ""}</h2>
        {comments.length === 0 ? (
          <p className="card mt-4 p-5 text-ink-soft">Personne n'a encore répondu. Tu peux aider !</p>
        ) : (
          <ul className="mt-4 space-y-3">
            {comments.map((c) => (
              <li key={c.id} className="card p-5">
                <p className="text-sm text-ink-soft">{names.get(c.author_id) ?? "Élève"} · {formatDate(c.created_at)}</p>
                <p className="mt-2 whitespace-pre-line">{c.body}</p>
                <div className="mt-2">
                  {user?.id === c.author_id ? (
                    <ActionButton action={deleteOwnComment.bind(null, c.id)} label="Supprimer" variant="danger" confirm="Supprimer ce commentaire ?" />
                  ) : (
                    <ReportButton commentId={c.id} loggedIn={!!user} />
                  )}
                </div>
              </li>
            ))}
          </ul>
        )}

        <div className="mt-8">
          {user ? (
            <CommentForm postId={post.id} />
          ) : (
            <p className="card p-5">
              <Link href={`/connexion?redirige=${encodeURIComponent(`/communaute/${post.id}`)}`} className="font-semibold text-brand hover:underline">Connecte-toi</Link>{" "}
              ou <Link href="/inscription" className="font-semibold text-brand hover:underline">crée un compte</Link> pour répondre.
            </p>
          )}
        </div>
      </section>
    </div>
  );
}
