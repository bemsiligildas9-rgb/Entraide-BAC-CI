import { NextResponse } from "next/server";
import { safeRedirectPath } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";

// Reçoit le lien envoyé par e-mail (confirmation du compte, réinitialisation du mot de passe).
export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get("code");
  const next = safeRedirectPath(searchParams.get("next"));

  if (code) {
    const { error } = await createClient().auth.exchangeCodeForSession(code);
    if (!error) return NextResponse.redirect(`${origin}${next}`);
  }
  return NextResponse.redirect(`${origin}/connexion?erreur=lien`);
}
