import { NextResponse } from "next/server";
import { getUser } from "@/lib/auth";
import { slugify, UUID_RE } from "@/lib/files";
import { createClient } from "@/lib/supabase/server";

export async function GET(request: Request, { params }: { params: { id: string } }) {
  const { origin } = new URL(request.url);
  const id = params.id;
  if (!UUID_RE.test(id)) return NextResponse.redirect(`${origin}/documents`);

  const user = await getUser();
  if (!user) {
    return NextResponse.redirect(`${origin}/connexion?redirige=${encodeURIComponent(`/documents/${id}`)}`);
  }

  const supabase = createClient();
  const { data: r } = await supabase.from("resources").select("title, file_path").eq("id", id).eq("is_published", true).maybeSingle();
  if (!r?.file_path) return NextResponse.redirect(`${origin}/documents/${id}`);

  const ext = r.file_path.split(".").pop() ?? "pdf";
  const { data: signed } = await supabase.storage
    .from("documents")
    .createSignedUrl(r.file_path, 60, { download: `${slugify(r.title)}.${ext}` });
  if (!signed?.signedUrl) return NextResponse.redirect(`${origin}/documents/${id}`);

  await supabase.from("resource_downloads").insert({ user_id: user.id, resource_id: id });
  return NextResponse.redirect(signed.signedUrl);
}
