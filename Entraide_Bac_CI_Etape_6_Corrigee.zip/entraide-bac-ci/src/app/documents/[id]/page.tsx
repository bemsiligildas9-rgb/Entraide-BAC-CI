import { Download, ExternalLink } from "lucide-react";
import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { FavoriteButton } from "@/components/FavoriteButton";
import { ResourceCard } from "@/components/ResourceCard";
import { getUser } from "@/lib/auth";
import { getFavoriteIds, getResources } from "@/lib/data";
import { formatSize, UUID_RE, youtubeEmbed } from "@/lib/files";
import { formatDate, kindSingular } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";
import type { ResourceKind } from "@/lib/types";

type Props = { params: { id: string } };
type Joined<T> = T | T[] | null;
const one = <T,>(v: Joined<T>): T | null => (Array.isArray(v) ? (v[0] ?? null) : v);

async function loadResource(id: string) {
  if (!UUID_RE.test(id)) return null;
  try {
    const { data } = await createClient()
      .from("resources")
      .select("id, kind, title, description, published_at, exam_year, epreuve, file_path, file_size, video_url, subject_id, subjects(name, slug), levels(name), series(name)")
      .eq("id", id)
      .eq("is_published", true)
      .maybeSingle();
    return data as unknown as {
      id: string;
      kind: ResourceKind;
      title: string;
      description: string | null;
      published_at: string;
      exam_year: number | null;
      epreuve: string | null;
      file_path: string | null;
      file_size: number | null;
      video_url: string | null;
      subject_id: number;
      subjects: Joined<{ name: string; slug: string }>;
      levels: Joined<{ name: string }>;
      series: Joined<{ name: string }>;
    } | null;
  } catch {
    return null;
  }
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const r = await loadResource(params.id);
  if (!r) return {};
  return { title: r.title, description: r.description?.slice(0, 160) ?? `${kindSingular[r.kind]} — ${one(r.subjects)?.name ?? ""}`, alternates: { canonical: `/documents/${r.id}` } };
}

export default async function DocumentPage({ params }: Props) {
  const r = await loadResource(params.id);
  if (!r) notFound();

  const user = await getUser();
  const supabase = createClient();
  const subject = one(r.subjects);
  const level = one(r.levels);
  const serie = one(r.series);

  let signedUrl: string | null = null;
  if (user) {
    // Historique de consultation (échec silencieux : ne doit jamais bloquer la page)
    await supabase.from("resource_views").insert({ user_id: user.id, resource_id: r.id });
    if (r.file_path) {
      const { data } = await supabase.storage.from("documents").createSignedUrl(r.file_path, 3600);
      signedUrl = data?.signedUrl ?? null;
    }
  }

  const ext = r.file_path?.split(".").pop()?.toLowerCase();
  const embed = r.video_url ? youtubeEmbed(r.video_url) : null;
  const suggestions = (await getResources({ subjectId: r.subject_id, pageSize: 5 })).items.filter((s) => s.id !== r.id).slice(0, 4);
  const favorites = await getFavoriteIds(user?.id, [r.id, ...suggestions.map((s) => s.id)]);
  const meta = [subject?.name, level?.name, serie?.name, r.exam_year ? String(r.exam_year) : null, r.epreuve, formatSize(r.file_size)].filter(Boolean);

  return (
    <div className="container-page py-12 sm:py-16">
      <nav aria-label="Fil d'Ariane" className="text-sm text-ink-soft">
        <Link href="/documents" className="hover:text-brand">Documents</Link>
        {subject ? (
          <>
            {" / "}
            <Link href={`/matieres/${subject.slug}`} className="hover:text-brand">{subject.name}</Link>
          </>
        ) : null}
      </nav>
      <p className="mt-6 text-sm font-semibold text-brand">{kindSingular[r.kind]}</p>
      <h1 className="mt-1 max-w-3xl text-3xl font-extrabold sm:text-4xl">{r.title}</h1>
      {meta.length > 0 ? <p className="mt-2 text-ink-soft">{meta.join(" · ")}</p> : null}
      <p className="mt-1 text-sm text-ink-soft">Publié le {formatDate(r.published_at)}</p>
      {r.description ? <p className="mt-5 max-w-2xl whitespace-pre-line text-lg">{r.description}</p> : null}

      <div className="mt-6 flex flex-wrap items-center gap-2">
        {r.file_path ? (
          <a href={`/documents/${r.id}/telecharger`} className="btn-primary">
            <Download size={17} /> Télécharger
          </a>
        ) : null}
        {signedUrl ? (
          <a href={signedUrl} target="_blank" rel="noopener noreferrer" className="btn-outline">
            <ExternalLink size={17} /> Ouvrir dans un nouvel onglet
          </a>
        ) : null}
        {r.video_url && !embed ? (
          <a href={r.video_url} target="_blank" rel="noopener noreferrer" className="btn-primary">
            <ExternalLink size={17} /> Regarder la vidéo
          </a>
        ) : null}
        <FavoriteButton resourceId={r.id} initial={favorites.has(r.id)} loggedIn={!!user} />
      </div>

      {!user && (r.file_path || r.video_url) ? (
        <p className="card mt-8 p-5">
          <Link href={`/connexion?redirige=${encodeURIComponent(`/documents/${r.id}`)}`} className="font-semibold text-brand hover:underline">Connecte-toi</Link>{" "}
          ou <Link href="/inscription" className="font-semibold text-brand hover:underline">crée un compte</Link> pour consulter et télécharger ce document.
        </p>
      ) : null}

      {embed ? (
        <div className="mt-8 aspect-video max-w-3xl overflow-hidden rounded-card border border-line">
          <iframe src={embed} title={r.title} className="h-full w-full" allowFullScreen loading="lazy" referrerPolicy="strict-origin-when-cross-origin" />
        </div>
      ) : null}

      {signedUrl && ext === "pdf" ? (
        <section className="mt-8" aria-labelledby="apercu">
          <h2 id="apercu" className="text-xl font-bold">Aperçu</h2>
          <iframe src={signedUrl} title={`Aperçu : ${r.title}`} className="mt-3 h-[70vh] w-full rounded-card border border-line bg-surface" />
          <p className="mt-2 text-sm text-ink-soft">Si l'aperçu ne s'affiche pas sur ton téléphone, ouvre le document dans un nouvel onglet.</p>
        </section>
      ) : null}
      {signedUrl && ext && ["png", "jpg", "jpeg", "webp"].includes(ext) ? (
        <section className="mt-8">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={signedUrl} alt={r.title} className="max-w-full rounded-card border border-line" />
        </section>
      ) : null}

      {suggestions.length > 0 ? (
        <section className="mt-16" aria-labelledby="suggestions">
          <h2 id="suggestions" className="text-2xl font-bold">Dans la même matière</h2>
          <ul className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {suggestions.map((s) => (
              <li key={s.id}>
                <ResourceCard resource={s} isFavorite={favorites.has(s.id)} loggedIn={!!user} />
              </li>
            ))}
          </ul>
        </section>
      ) : null}
    </div>
  );
}
