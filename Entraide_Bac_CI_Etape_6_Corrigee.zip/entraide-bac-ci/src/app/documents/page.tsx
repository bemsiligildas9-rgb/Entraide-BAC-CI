import type { Metadata } from "next";
import { LibraryFilters } from "@/components/LibraryFilters";
import { Pagination } from "@/components/Pagination";
import { ResourceCard } from "@/components/ResourceCard";
import { getUser } from "@/lib/auth";
import { getFavoriteIds, getLevels, getResources, getSeries, getSubjects } from "@/lib/data";
import { parseKind, str } from "@/lib/labels";

export const metadata: Metadata = {
  title: "Bibliothèque de documents",
  description: "Cours, exercices, corrigés, fiches de révision et vidéos pour le BEPC et le Bac. Recherche et filtres par matière, série et classe.",
  alternates: { canonical: "/documents" },
};

const PAGE_SIZE = 12;
type SP = Record<string, string | string[] | undefined>;

export default async function DocumentsPage({ searchParams }: { searchParams: SP }) {
  const v = {
    q: str(searchParams.q)?.slice(0, 80),
    kind: parseKind(str(searchParams.kind)),
    matiere: str(searchParams.matiere),
    serie: str(searchParams.serie),
    niveau: str(searchParams.niveau),
  };
  const page = Math.max(1, Number(str(searchParams.page)) || 1);

  const [user, subjects, series, levels] = await Promise.all([getUser(), getSubjects(), getSeries(), getLevels()]);
  const { items, total } = await getResources({
    q: v.q,
    kind: v.kind,
    subjectId: subjects.find((s) => s.slug === v.matiere)?.id,
    serieId: series.find((s) => s.slug === v.serie)?.id,
    levelId: levels.find((l) => l.slug === v.niveau)?.id,
    page,
    pageSize: PAGE_SIZE,
  });
  const favorites = await getFavoriteIds(user?.id, items.map((i) => i.id));
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  return (
    <div className="container-page py-12 sm:py-16">
      <h1 className="text-4xl font-extrabold sm:text-5xl">Bibliothèque de documents</h1>
      <p className="mt-3 max-w-2xl text-lg text-ink-soft">Cours, exercices, corrigés, fiches de révision et vidéos classés par matière, série et classe.</p>
      <div className="mt-8">
        <LibraryFilters action="/documents" values={v} subjects={subjects} series={series} levels={levels} showKind />
      </div>
      <p className="mt-6 text-sm text-ink-soft" aria-live="polite">
        {total === 0 ? "Aucun document" : `${total} document${total > 1 ? "s" : ""}`}
      </p>
      {items.length === 0 ? (
        <p className="card mt-4 p-6 text-ink-soft">Aucun document ne correspond à ta recherche. Essaie d'autres filtres ou réinitialise-les.</p>
      ) : (
        <ul className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((r) => (
            <li key={r.id}>
              <ResourceCard resource={r} isFavorite={favorites.has(r.id)} loggedIn={!!user} />
            </li>
          ))}
        </ul>
      )}
      <Pagination basePath="/documents" params={{ ...v }} page={page} totalPages={totalPages} />
    </div>
  );
}
