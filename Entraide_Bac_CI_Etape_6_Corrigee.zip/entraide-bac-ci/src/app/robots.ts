import type { MetadataRoute } from "next";
import { site } from "@/lib/site";

export default function robots(): MetadataRoute.Robots {
  const base = site.url.replace(/\/$/, "");
  return {
    rules: [
      {
        userAgent: "*",
        allow: "/",
        disallow: ["/admin", "/tableau-de-bord", "/auth/", "/connexion", "/reinitialiser-mot-de-passe", "/mot-de-passe-oublie", "/notifications", "/recherche", "/documents/*/telecharger"],
      },
    ],
    sitemap: `${base}/sitemap.xml`,
    host: base,
  };
}
