import { BookOpenCheck, FolderOpen, Smartphone, Users } from "lucide-react";
import Link from "next/link";
import { getUser } from "@/lib/auth";
import { getActiveAnnouncements, getLatestResources, getSeries, getSubjects } from "@/lib/data";
import { formatDate, kindSingular, serieTaglines } from "@/lib/labels";
import { site } from "@/lib/site";

const reasons = [
  { icon: FolderOpen, title: "Tout au même endroit", text: "Cours, exercices, corrigés, annales et fiches de révision sont classés par série et par matière." },
  { icon: BookOpenCheck, title: "Pour t'entraîner", text: "Des quiz corrigés automatiquement, avec l'explication de chaque réponse et l'historique de tes résultats." },
  { icon: Smartphone, title: "Pensé pour le téléphone", text: "Un site léger et rapide, qui reste agréable à utiliser avec une connexion mobile." },
  { icon: Users, title: "L'entraide entre élèves", text: "Pose une question, partage ta méthode et aide les autres à progresser." },
];

export default async function HomePage() {
  const [user, series, subjects, latest, announcements] = await Promise.all([
    getUser(),
    getSeries(),
    getSubjects(8),
    getLatestResources(6),
    getActiveAnnouncements(2),
  ]);

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@graph": [
              { "@type": "Organization", name: site.name, url: site.url, founder: { "@type": "Person", name: site.owner } },
              {
                "@type": "WebSite",
                name: site.name,
                url: site.url,
                inLanguage: "fr",
                potentialAction: { "@type": "SearchAction", target: `${site.url}/recherche?q={search_term_string}`, "query-input": "required name=search_term_string" },
              },
            ],
          }),
        }}
      />
      {announcements.length > 0 ? (
        <section aria-label="Annonces" className="border-b border-line bg-surface">
          <ul className="container-page divide-y divide-line">
            {announcements.map((a) => (
              <li key={a.id} className="py-3 text-sm sm:text-base">
                <span className="font-bold">{a.title}</span>
                <span className="text-ink-soft"> — {a.body}</span>
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      {/* Bannière */}
      <section className="seyes text-white">
        <div className="container-page py-16 pl-8 sm:py-24 sm:pl-16 lg:pl-28">
          <h1 className="hero-in max-w-3xl font-display text-5xl font-extrabold leading-[1.02] !text-white sm:text-7xl">
            {site.slogan}
          </h1>
          <p className="hero-in-2 mt-6 max-w-xl text-lg text-white/80">
            {site.description} Une plateforme créée par {site.owner}.
          </p>
          <form action="/recherche" method="get" role="search" className="hero-in-2 mt-8 flex max-w-xl gap-2">
            <label htmlFor="hero-q" className="sr-only">Rechercher sur le site</label>
            <input id="hero-q" name="q" type="search" maxLength={80} placeholder="Rechercher un cours, une matière, un quiz…" className="input !bg-white !text-night placeholder:!text-slate-500" />
            <button type="submit" className="btn bg-cyan-300 text-night hover:bg-cyan-200">Chercher</button>
          </form>
          <div className="hero-in-2 mt-6 flex flex-col gap-3 sm:flex-row">
            <Link href={user ? "/tableau-de-bord" : "/inscription"} className="btn bg-white text-night hover:bg-white/90">
              Commencer à apprendre
            </Link>
            <Link href="#categories" className="btn border border-white/35 text-white hover:bg-white/10">
              Explorer les cours
            </Link>
          </div>
          {series.length > 0 ? (
            <div className="hero-in-2 mt-10">
              <p className="text-sm font-semibold text-white/70">Je prépare :</p>
              <ul className="mt-3 flex flex-wrap gap-2">
                {series.map((s) => (
                  <li key={s.id}>
                    <Link href={`/series/${s.slug}`} className="inline-flex min-h-[40px] items-center rounded-pill border border-cyan-300/50 px-4 text-sm font-semibold text-white transition hover:bg-cyan-300 hover:text-night">
                      {s.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ) : null}
        </div>
      </section>

      {/* Catégories */}
      <section id="categories" className="container-page scroll-mt-20 pt-20">
        <h2 className="text-3xl font-bold sm:text-4xl">Choisis ton examen</h2>
        <p className="mt-3 max-w-xl text-ink-soft">Chaque série a ses matières, ses cours et ses annales.</p>
        {series.length === 0 ? (
          <p className="card mt-8 p-6 text-ink-soft">Les séries s'afficheront ici dès que la base de données sera configurée (voir le README).</p>
        ) : (
          <ul className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {series.map((s) => (
              <li key={s.id}>
                <Link href={`/series/${s.slug}`} className="card group flex h-full flex-col p-6 transition hover:-translate-y-0.5 hover:border-brand">
                  <span className="font-display text-2xl font-bold text-ink group-hover:text-brand">Préparation {s.name}</span>
                  <span className="mt-2 text-ink-soft">{serieTaglines[s.slug] ?? ""}</span>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </section>

      {/* Matières populaires */}
      <section id="matieres" className="container-page scroll-mt-20 pt-20">
        <h2 className="text-3xl font-bold sm:text-4xl">Nos matières populaires</h2>
        {subjects.length === 0 ? (
          <p className="card mt-8 p-6 text-ink-soft">Les matières s'afficheront ici dès que la base de données sera configurée.</p>
        ) : (
          <ul className="mt-8 flex flex-wrap gap-3">
            {subjects.map((m) => (
              <li key={m.id}>
                <Link href={`/matieres/${m.slug}`} className="inline-flex min-h-[48px] items-center rounded-card border border-line bg-surface px-5 font-semibold text-ink transition hover:border-brand hover:text-brand">
                  {m.name}
                </Link>
              </li>
            ))}
          </ul>
        )}
      </section>

      {/* Pourquoi */}
      <section className="container-page pt-20">
        <h2 className="text-3xl font-bold sm:text-4xl">Pourquoi choisir {site.name} ?</h2>
        <ul className="mt-8 grid gap-x-10 gap-y-8 sm:grid-cols-2">
          {reasons.map(({ icon: Icon, title, text }) => (
            <li key={title} className="flex gap-4">
              <span className="mt-1 inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-brand/10 text-brand">
                <Icon size={22} />
              </span>
              <div>
                <h3 className="text-lg font-bold">{title}</h3>
                <p className="mt-1 text-ink-soft">{text}</p>
              </div>
            </li>
          ))}
        </ul>
      </section>

      {/* Dernières ressources */}
      <section id="ressources" className="container-page scroll-mt-20 pt-20">
        <h2 className="text-3xl font-bold sm:text-4xl">Dernières ressources publiées</h2>
        {latest.length === 0 ? (
          <p className="card mt-8 p-6 text-ink-soft">Aucune ressource n'est encore publiée. Elles apparaîtront ici dès que l'administrateur en ajoutera.</p>
        ) : (
          <ul className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {latest.map((r) => (
              <li key={r.id}>
                <Link href={`/documents/${r.id}`} className="card flex h-full flex-col p-5 transition hover:border-brand">
                  <span className="text-sm font-semibold text-brand">{kindSingular[r.kind]}{r.subjects ? ` · ${r.subjects.name}` : ""}</span>
                  <span className="mt-2 font-display text-lg font-bold leading-snug">{r.title}</span>
                  <span className="mt-auto pt-4 text-sm text-ink-soft">{formatDate(r.published_at)}</span>
                </Link>
              </li>
            ))}
          </ul>
        )}
        <div className="mt-6 flex flex-wrap gap-3">
          <Link href="/documents" className="btn-outline">Parcourir tous les documents</Link>
          <Link href="/annales" className="btn-outline">Voir les annales</Link>
          <Link href="/quiz" className="btn-outline">Faire un quiz</Link>
        </div>
      </section>

      {/* Communauté */}
      <section className="container-page pt-20">
        <div className="rounded-[20px] bg-brand px-6 py-12 text-white sm:px-12 dark:bg-surface dark:text-ink">
          <h2 className="max-w-xl text-3xl font-bold !text-inherit sm:text-4xl">Rejoignez notre communauté</h2>
          <p className="mt-3 max-w-xl text-white/90 dark:text-ink-soft">
            Crée ton compte pour suivre ta progression, enregistrer tes ressources favorites et t'entraider avec d'autres élèves.
          </p>
          <Link href={user ? "/tableau-de-bord" : "/inscription"} className="btn mt-7 bg-white text-night hover:bg-white/90">
            {user ? "Aller à mon espace" : "Créer mon compte"}
          </Link>
        </div>
      </section>
    </>
  );
}
