import type { Metadata } from "next";
import Link from "next/link";
import { Prose } from "@/components/Prose";

export const metadata: Metadata = {
  title: "Questions fréquentes",
  description: "Réponses aux questions les plus courantes sur Entraide Bac CI : compte, documents, quiz, communauté.",
  alternates: { canonical: "/faq" },
};

const faq: { q: string; a: string }[] = [
  { q: "Comment créer un compte ?", a: "Clique sur « Inscription », renseigne ton nom, ton adresse e-mail, ton mot de passe, ta classe, ta série et ta ville, puis confirme ton adresse e-mail grâce au message que tu reçois." },
  { q: "J'ai oublié mon mot de passe, que faire ?", a: "Sur la page de connexion, clique sur « Mot de passe oublié ? », saisis ton adresse e-mail et suis le lien reçu pour en choisir un nouveau." },
  { q: "Faut-il un compte pour télécharger les documents ?", a: "Tu peux parcourir la bibliothèque sans compte, mais il faut être connecté pour consulter les fichiers et les télécharger." },
  { q: "D'où viennent les annales et les cours ?", a: "Ils sont ajoutés par l'administrateur à partir de documents autorisés. Aucun faux sujet n'est publié. Vérifie toujours auprès de ton établissement pour tes examens." },
  { q: "Comment fonctionnent les quiz ?", a: "Tu réponds aux questions, puis le score est calculé automatiquement. Pour chaque question, tu vois la bonne réponse et une explication. Tes résultats sont conservés dans ton tableau de bord." },
  { q: "Comment poser une question à la communauté ?", a: "Rends-toi dans « Communauté », clique sur « Poser une question », choisis éventuellement une matière et détaille ta demande. Les autres élèves pourront te répondre." },
  { q: "Comment signaler un contenu inapproprié ?", a: "Sous chaque publication ou commentaire, clique sur « Signaler » et explique brièvement le problème. La modération examine les signalements." },
  { q: "Comment modifier mes informations ou mon mot de passe ?", a: "Dans ton espace, ouvre l'onglet « Mon profil » : tu peux y changer tes informations et ton mot de passe." },
  { q: "Comment contacter l'équipe ?", a: "Utilise le formulaire de la page Contact. Selon la configuration, tu y trouveras aussi un lien WhatsApp, une adresse e-mail et nos réseaux sociaux." },
];

export default function FaqPage() {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faq.map((f) => ({ "@type": "Question", name: f.q, acceptedAnswer: { "@type": "Answer", text: f.a } })),
  };
  return (
    <Prose title="Questions fréquentes" intro="Tu ne trouves pas ta réponse ? Écris-nous depuis la page Contact.">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <div className="space-y-3 !mt-6">
        {faq.map((f) => (
          <details key={f.q} className="card group p-4">
            <summary className="flex min-h-[44px] cursor-pointer list-none items-center justify-between gap-4 font-display text-lg font-bold text-ink">
              {f.q}
              <span aria-hidden="true" className="text-brand transition group-open:rotate-45">+</span>
            </summary>
            <p className="mt-2 !text-ink-soft">{f.a}</p>
          </details>
        ))}
      </div>
      <p>
        <Link href="/contact">Contacter l'équipe</Link>
      </p>
    </Prose>
  );
}
