import { Search } from "lucide-react";
import type { Metadata } from "next";
import Link from "next/link";
import { ResourceCard } from "@/components/ResourceCard";
import { getUser } from "@/lib/auth";
import { cleanTerm, getPosts, postKindLabels } from "@/lib/community";
import { getFavoriteIds, getResources, getSubjects } from "@/lib/data";
import { formatDate, str } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";

export const metadata: Metadata = { title: "Recherche", robots: { index: false } };

export default async function SearchPage({ searchParams }: { searchParams: { q?: string | string[] } }) {
  const q = str(searchParams.q)?.slice(0, 80) ?? "";
  const term = cleanTerm(q);
  const user = await getUser();

  let docs: Awaited<ReturnType<typeof getResources>> = { items: [], total: 0 };
  let posts: Awaited<ReturnType<typeof getPosts>> = { items: [], total: 0 };
  let quizzes: { id: string; title: string }[] = [];
  let subjects: { id: number; slug: string; name: string }[] = [];

  if (term.length >= 2) {
    const [d, p, qz, allSubjects] = await Promise.all([
      getResources({ q: term, pageSize: 6 }),
      getPosts({ q: term, pageSize: 5 }),
      createClient().from("quizzes").select("id, title").eq("is_published", true).ilike("title", `%${term}%`).limit(5),
      getSubjects(),
    ]);
    docs = d;
    posts = p;
    quizzes = (qz.data ?? []) as { id: string; title: string }[];
    const low = term.toLowerCase();
    subjects = allSubjects.filter((s) => s.name.toLowerCase().includes(low));
  }
  const favorites = await getFavoriteIds(user?.id, docs.items.map((i) => i.id));
  const nothing = term.length >= 2 && docs.items.length + posts.items.length + quizzes.length + subjects.length === 0;

  return (
    <div className="container-page py-12 sm:py-16">
      <h1 className="text-4xl font-extrabold sm:text-5xl">Recherche</h1>
      <form action="/recherche" method="get" role="search" className="mt-6 flex max-w-2xl gap-2">
        <label htmlFor="q" className="sr-only">Rechercher sur le site</label>
        <input id="q" name="q" type="search" defaultValue={q} placeholder="Cours, matière, quiz, question…" className="input" maxLength={80} autoFocus={!q} />
        <button type="submit" className="btn-primary"><Search size={18} /> Chercher</button>
      </form>

      {term.length < 2 ? (
        <p className="mt-8 text-ink-soft">Saisis au moins 2 caractères pour lancer la recherche.</p>
      ) : nothing ? (
        <p className="card mt-8 p-6 text-ink-soft">Aucun résultat pour « {q} ». Essaie un autre mot-clé.</p>
      ) : (
        <div className="mt-10 space-y-12">
          {subjects.length > 0 ? (
            <section aria-labelledby="r-matieres">
              <h2 id="r-matieres" className="text-2xl font-bold">Matières</h2>
              <ul className="mt-4 flex flex-wrap gap-3">
                {subjects.map((s) => (
                  <li key={s.id}><Link href={`/matieres/${s.slug}`} className="inline-flex min-h-[44px] items-center rounded-card border border-line bg-surface px-4 font-semibold hover:border-brand hover:text-brand">{s.name}</Link></li>
                ))}
              </ul>
            </section>
          ) : null}
          {docs.items.length > 0 ? (
            <section aria-labelledby="r-docs">
              <div className="flex items-baseline justify-between gap-3">
                <h2 id="r-docs" className="text-2xl font-bold">Documents</h2>
                {docs.total > docs.items.length ? <Link href={`/documents?q=${encodeURIComponent(term)}`} className="font-semibold text-brand hover:underline">Voir les {docs.total} résultats</Link> : null}
              </div>
              <ul className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {docs.items.map((r) => (
                  <li key={r.id}><ResourceCard resource={r} isFavorite={favorites.has(r.id)} loggedIn={!!user} /></li>
                ))}
              </ul>
            </section>
          ) : null}
          {quizzes.length > 0 ? (
            <section aria-labelledby="r-quiz">
              <h2 id="r-quiz" className="text-2xl font-bold">Quiz</h2>
              <ul className="card mt-4 divide-y divide-line">
                {quizzes.map((z) => (
                  <li key={z.id}><Link href={`/quiz/${z.id}`} className="block p-4 font-semibold hover:text-brand">{z.title}</Link></li>
                ))}
              </ul>
            </section>
          ) : null}
          {posts.items.length > 0 ? (
            <section aria-labelledby="r-com">
              <div className="flex items-baseline justify-between gap-3">
                <h2 id="r-com" className="text-2xl font-bold">Communauté</h2>
                {posts.total > posts.items.length ? <Link href={`/communaute?q=${encodeURIComponent(term)}`} className="font-semibold text-brand hover:underline">Voir les {posts.total} résultats</Link> : null}
              </div>
              <ul className="card mt-4 divide-y divide-line">
                {posts.items.map((p) => (
                  <li key={p.id}>
                    <Link href={`/communaute/${p.id}`} className="block p-4 hover:text-brand">
                      <span className="text-sm text-ink-soft">{postKindLabels[p.kind]} · {formatDate(p.created_at)}</span>
                      <span className="block font-semibold">{p.title}</span>
                    </Link>
                  </li>
                ))}
              </ul>
            </section>
          ) : null}
        </div>
      )}
    </div>
  );
}
