import type { Metadata } from "next";
import { LibraryFilters } from "@/components/LibraryFilters";
import { Pagination } from "@/components/Pagination";
import { ResourceCard } from "@/components/ResourceCard";
import { getUser } from "@/lib/auth";
import { getAnnaleFacets, getFavoriteIds, getResources, getSeries, getSubjects } from "@/lib/data";
import { str, toInt } from "@/lib/labels";

export const metadata: Metadata = {
  title: "Annales du BEPC et du Bac",
  description: "Anciens sujets d'examens du BEPC et du Baccalauréat, classés par année, série, matière et type d'épreuve.",
  alternates: { canonical: "/annales" },
};

const PAGE_SIZE = 24;
type SP = Record<string, string | string[] | undefined>;

export default async function AnnalesPage({ searchParams }: { searchParams: SP }) {
  const v = {
    serie: str(searchParams.serie),
    matiere: str(searchParams.matiere),
    annee: str(searchParams.annee),
    epreuve: str(searchParams.epreuve),
  };
  const page = Math.max(1, Number(str(searchParams.page)) || 1);

  const [user, subjects, series, facets] = await Promise.all([getUser(), getSubjects(), getSeries(), getAnnaleFacets()]);
  const { items, total } = await getResources({
    kind: "annale",
    serieId: series.find((s) => s.slug === v.serie)?.id,
    strictSerie: true,
    subjectId: subjects.find((s) => s.slug === v.matiere)?.id,
    year: toInt(v.annee),
    epreuve: v.epreuve,
    orderByYear: true,
    page,
    pageSize: PAGE_SIZE,
  });
  const favorites = await getFavoriteIds(user?.id, items.map((i) => i.id));
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  // Regroupement par année (les résultats sont déjà triés de la plus récente à la plus ancienne)
  const groups = new Map<string, typeof items>();
  for (const r of items) {
    const key = r.exam_year ? String(r.exam_year) : "Année non précisée";
    groups.set(key, [...(groups.get(key) ?? []), r]);
  }

  return (
    <div className="container-page py-12 sm:py-16">
      <h1 className="text-4xl font-extrabold sm:text-5xl">Annales du BEPC et du Bac</h1>
      <p className="mt-3 max-w-2xl text-lg text-ink-soft">Seuls les sujets ajoutés par l'administrateur à partir de sources autorisées sont publiés ici.</p>
      <div className="mt-8">
        <LibraryFilters action="/annales" values={v} subjects={subjects} series={series} years={facets.years} epreuves={facets.epreuves} showSearch={false} />
      </div>
      <p className="mt-6 text-sm text-ink-soft" aria-live="polite">
        {total === 0 ? "Aucun sujet" : `${total} sujet${total > 1 ? "s" : ""}`}
      </p>
      {items.length === 0 ? (
        <p className="card mt-4 p-6 text-ink-soft">Aucune annale n'est publiée pour ces critères pour le moment.</p>
      ) : (
        Array.from(groups.entries()).map(([year, list]) => (
          <section key={year} className="mt-8">
            <h2 className="text-2xl font-bold">{year}</h2>
            <ul className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {list.map((r) => (
                <li key={r.id}>
                  <ResourceCard resource={r} isFavorite={favorites.has(r.id)} loggedIn={!!user} />
                </li>
              ))}
            </ul>
          </section>
        ))
      )}
      <Pagination basePath="/annales" params={{ ...v }} page={page} totalPages={totalPages} />
    </div>
  );
}
