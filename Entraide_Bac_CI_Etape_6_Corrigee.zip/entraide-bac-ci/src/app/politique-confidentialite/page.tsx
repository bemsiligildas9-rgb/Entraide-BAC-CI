import type { Metadata } from "next";
import Link from "next/link";
import { Prose } from "@/components/Prose";
import { site } from "@/lib/site";

export const metadata: Metadata = {
  title: "Politique de confidentialité",
  description: `Comment ${site.name} collecte, utilise et protège tes données personnelles.`,
  alternates: { canonical: "/politique-confidentialite" },
};

export default function PrivacyPage() {
  return (
    <Prose title="Politique de confidentialité" intro="Dernière mise à jour : octobre 2026">
      <p>
        Le site s'adresse à des élèves, dont des mineurs. Nous collectons le minimum de données nécessaire et nous invitons les parents à accompagner
        leurs enfants dans l'usage d'Internet. Le responsable du site est {site.owner} (<Link href="/contact">contact</Link>).
      </p>
      <h2>Données collectées</h2>
      <ul>
        <li><strong>Compte :</strong> nom, prénom, adresse e-mail, classe, série, ville, établissement (facultatif) et mot de passe. Le mot de passe est protégé par un hachage : nous ne pouvons pas le lire.</li>
        <li><strong>Activité :</strong> ressources consultées et téléchargées, favoris, résultats de quiz, afin d'alimenter ton tableau de bord.</li>
        <li><strong>Communauté :</strong> questions, réponses, commentaires, réactions et signalements que tu publies.</li>
        <li><strong>Contact :</strong> nom, adresse e-mail et message envoyés via le formulaire.</li>
      </ul>
      <h2>Utilisation des données</h2>
      <p>
        Tes données servent à créer et sécuriser ton compte, adapter les ressources à ta série, afficher ta progression, faire fonctionner et modérer
        la communauté, et répondre à tes messages. Nous ne vendons pas tes données et ne les utilisons pas pour de la publicité.
      </p>
      <h2>Ce que voient les autres élèves</h2>
      <p>Dans la communauté, seuls ton prénom et l'initiale de ton nom sont affichés. Ton e-mail, ta ville et ton établissement ne sont jamais publics.</p>
      <h2>Hébergement et prestataires</h2>
      <p>
        Le site s'appuie sur des prestataires techniques pour l'authentification, la base de données, le stockage des fichiers et l'hébergement web
        (Supabase et Vercel). Ils traitent les données uniquement pour faire fonctionner le service.
      </p>
      <h2>Cookies et stockage local</h2>
      <p>
        Le site utilise uniquement des cookies nécessaires à ta connexion et mémorise ton choix de thème (clair ou sombre) dans ton navigateur.
        Il n'utilise ni cookies publicitaires ni outil de suivi d'audience.
      </p>
      <h2>Durée de conservation</h2>
      <p>Tes données sont conservées tant que ton compte existe. Tu peux demander sa suppression à tout moment ; ses données sont alors effacées.</p>
      <h2>Tes droits</h2>
      <p>
        Tu peux accéder à tes données, les rectifier (depuis « Mon profil »), t'opposer à leur traitement ou demander leur suppression en nous
        contactant. En Côte d'Ivoire, la protection des données personnelles est encadrée par la loi n° 2013-450 du 19 juin 2013, dont le respect
        est contrôlé par l'ARTCI, auprès de laquelle tu peux aussi t'adresser.
      </p>
      <h2>Sécurité</h2>
      <p>Le site utilise le protocole HTTPS, des mots de passe hachés et des règles d'accès strictes : chaque élève n'accède qu'à ses propres données personnelles.</p>
      <h2>Modifications</h2>
      <p>Cette politique peut évoluer ; la date de mise à jour est indiquée en haut de la page.</p>
    </Prose>
  );
}
