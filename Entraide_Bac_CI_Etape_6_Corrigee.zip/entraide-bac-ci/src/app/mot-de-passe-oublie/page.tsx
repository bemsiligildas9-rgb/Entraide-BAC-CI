import type { Metadata } from "next";
import { AuthCard } from "@/components/auth/AuthCard";
import { MotDePasseOublieForm } from "@/components/auth/MotDePasseOublieForm";

export const metadata: Metadata = { title: "Mot de passe oublié", robots: { index: false } };

export default function MotDePasseOubliePage() {
  return (
    <AuthCard title="Mot de passe oublié" intro="Indique ton adresse e-mail : nous t'enverrons un lien pour choisir un nouveau mot de passe.">
      <MotDePasseOublieForm />
    </AuthCard>
  );
}
