import type { Metadata } from "next";
import Link from "next/link";
import { Prose } from "@/components/Prose";
import { site } from "@/lib/site";

export const metadata: Metadata = {
  title: "Conditions d'utilisation",
  description: `Conditions d'utilisation de la plateforme ${site.name}.`,
  alternates: { canonical: "/conditions-utilisation" },
};

export default function TermsPage() {
  return (
    <Prose title="Conditions d'utilisation" intro="Dernière mise à jour : octobre 2026">
      <p>
        En utilisant {site.fullName} (le « site »), tu acceptes les présentes conditions. Si tu n'es pas d'accord, merci de ne pas utiliser le site.
        Le site est édité par {site.owner}.
      </p>
      <h2>1. Le service</h2>
      <p>
        Le site propose des ressources éducatives (cours, exercices, corrigés, annales, fiches, vidéos), des quiz d'entraînement et un espace
        d'entraide entre élèves. Les contenus sont fournis à titre d'aide à la révision.
      </p>
      <h2>2. Ton compte</h2>
      <ul>
        <li>Les informations fournies à l'inscription doivent être exactes.</li>
        <li>Ton mot de passe est personnel : ne le partage pas. Tu es responsable de l'activité de ton compte.</li>
        <li>Tu peux modifier tes informations depuis ton profil et demander la suppression de ton compte en nous contactant.</li>
      </ul>
      <h2>3. Utilisation des ressources</h2>
      <p>
        Les ressources sont destinées à un usage personnel et éducatif. Les droits sur les contenus appartiennent à leurs auteurs ou ayants droit.
        Il est interdit de les revendre ou de les republier à des fins commerciales sans autorisation. Si tu penses qu'un contenu porte atteinte à
        tes droits, <Link href="/contact">contacte-nous</Link> : nous l'examinerons rapidement.
      </p>
      <h2>4. Règles de la communauté</h2>
      <ul>
        <li>Respecte les autres : pas d'insultes, de harcèlement, de moqueries ni de propos discriminatoires.</li>
        <li>Pas de publicité, de spam, de liens douteux ni de partage d'informations personnelles (les tiennes ou celles d'autrui).</li>
        <li>Ne diffuse pas de fausses informations, et ne publie pas de contenu dont tu n'as pas le droit de disposer.</li>
        <li>Tout contenu peut être signalé. La modération peut masquer ou supprimer un contenu et suspendre ou supprimer un compte en cas d'abus.</li>
      </ul>
      <h2>5. Responsabilité</h2>
      <p>
        Nous nous efforçons de proposer des contenus exacts, mais des erreurs peuvent subsister et nous ne garantissons ni l'absence d'erreur ni
        un résultat aux examens. Les contenus partagés par les élèves n'engagent que leurs auteurs. Vérifie toujours les consignes officielles de ton
        établissement. Le site peut être temporairement indisponible pour des raisons techniques ou de maintenance.
      </p>
      <h2>6. Modification des conditions</h2>
      <p>Ces conditions peuvent évoluer. La date de mise à jour figure en haut de la page ; continuer à utiliser le site vaut acceptation de la version en vigueur.</p>
      <h2>7. Contact</h2>
      <p>Pour toute question : <Link href="/contact">page Contact</Link>. Voir aussi notre <Link href="/politique-confidentialite">politique de confidentialité</Link>.</p>
    </Prose>
  );
}
