"use server";

import { z } from "zod";
import type { ActionResult } from "@/lib/action-result";
import { createClient } from "@/lib/supabase/server";

const schema = z.object({
  name: z.string().trim().min(2, "Indique ton nom").max(100, "Nom trop long"),
  email: z.string().trim().toLowerCase().email("Adresse e-mail invalide").max(200),
  message: z.string().trim().min(10, "Ton message doit contenir au moins 10 caractères").max(4000, "Message trop long (4000 caractères maximum)"),
  website: z.string().optional(), // champ piège : un humain ne le voit pas et ne le remplit pas
});

export async function sendContactMessage(raw: unknown): Promise<ActionResult> {
  const parsed = schema.safeParse(raw);
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message };
  const v = parsed.data;
  if (v.website) return { ok: true, message: "Message envoyé." }; // robot : on fait semblant sans rien enregistrer
  const { error } = await createClient().from("contact_messages").insert({ name: v.name, email: v.email, message: v.message });
  if (error) {
    return {
      ok: false,
      error: error.message?.startsWith("Trop de messages") ? error.message : "Envoi impossible pour le moment. Réessaie dans un instant.",
    };
  }
  return { ok: true, message: "Message envoyé. Merci, l'équipe te répondra dès que possible." };
}
