import { Facebook, Instagram, Mail, MessageCircle, Music2 } from "lucide-react";
import type { Metadata } from "next";
import { ContactForm } from "@/components/ContactForm";
import { createClient } from "@/lib/supabase/server";

export const metadata: Metadata = {
  title: "Contact",
  description: "Contacte l'équipe Entraide Bac CI : formulaire, e-mail et réseaux sociaux.",
  alternates: { canonical: "/contact" },
};

async function getSettings() {
  const out: Record<string, string> = {};
  try {
    const { data } = await createClient().from("site_settings").select("key, value");
    for (const r of (data ?? []) as { key: string; value: unknown }[]) if (typeof r.value === "string" && r.value) out[r.key] = r.value;
  } catch {
    /* réglages indisponibles */
  }
  return out;
}

export default async function ContactPage() {
  const s = await getSettings();
  const links = [
    { key: "facebook_url", label: "Facebook", icon: Facebook },
    { key: "tiktok_url", label: "TikTok", icon: Music2 },
    { key: "instagram_url", label: "Instagram", icon: Instagram },
  ].filter((l) => s[l.key]);

  return (
    <div className="container-page py-12 sm:py-16">
      <h1 className="text-4xl font-extrabold sm:text-5xl">Contacter l'équipe</h1>
      <p className="mt-3 max-w-2xl text-lg text-ink-soft">Une question, une suggestion, un document à proposer ou un problème à signaler ? Écris-nous.</p>

      <div className="mt-10 grid gap-10 lg:grid-cols-[1.4fr_1fr]">
        <section aria-labelledby="formulaire" className="card p-6">
          <h2 id="formulaire" className="text-2xl font-bold">Envoyer un message</h2>
          <div className="mt-5"><ContactForm /></div>
        </section>

        {s.contact_email || s.whatsapp_url || links.length > 0 ? (
          <aside aria-labelledby="canaux">
            <h2 id="canaux" className="text-2xl font-bold">Autres moyens de nous joindre</h2>
            <ul className="mt-5 space-y-3">
              {s.whatsapp_url ? (
                <li>
                  <a href={s.whatsapp_url} target="_blank" rel="noopener noreferrer" className="btn-primary w-full justify-start">
                    <MessageCircle size={18} /> Écrire sur WhatsApp
                  </a>
                </li>
              ) : null}
              {s.contact_email ? (
                <li>
                  <a href={`mailto:${s.contact_email}`} className="btn-outline w-full justify-start break-all">
                    <Mail size={18} /> {s.contact_email}
                  </a>
                </li>
              ) : null}
              {links.map(({ key, label, icon: Icon }) => (
                <li key={key}>
                  <a href={s[key]} target="_blank" rel="noopener noreferrer" className="btn-outline w-full justify-start">
                    <Icon size={18} /> {label}
                  </a>
                </li>
              ))}
            </ul>
          </aside>
        ) : null}
      </div>
    </div>
  );
}
