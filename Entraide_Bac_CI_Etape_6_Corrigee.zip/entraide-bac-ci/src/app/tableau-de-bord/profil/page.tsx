import type { Metadata } from "next";
import { PasswordForm } from "@/components/auth/PasswordForm";
import { ProfileForm } from "@/components/dashboard/ProfileForm";
import { getProfile, requireUser } from "@/lib/auth";
import { getLevels, getSeries } from "@/lib/data";

export const metadata: Metadata = { title: "Mon profil" };

export default async function ProfilePage() {
  const user = await requireUser();
  const [profile, levels, series] = await Promise.all([getProfile(user.id), getLevels(), getSeries()]);

  return (
    <div className="max-w-2xl space-y-12">
      <section aria-labelledby="infos">
        <h1 id="infos" className="text-3xl font-extrabold">Mon profil</h1>
        <p className="mt-2 text-ink-soft">Adresse e-mail du compte : {user.email}</p>
        <div className="mt-6">
          {profile ? (
            <ProfileForm profile={profile} levels={levels} series={series} />
          ) : (
            <p className="card p-5 text-ink-soft">Profil introuvable. Vérifie que le schéma SQL a bien été exécuté (voir le README).</p>
          )}
        </div>
      </section>
      <section aria-labelledby="mdp">
        <h2 id="mdp" className="text-2xl font-bold">Changer mon mot de passe</h2>
        <div className="mt-6">
          <PasswordForm />
        </div>
      </section>
    </div>
  );
}
