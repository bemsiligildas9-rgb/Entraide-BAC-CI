import Link from "next/link";
import { getProfile, requireUser } from "@/lib/auth";
import { getLevels, getSeries, getSubjectsForSerie } from "@/lib/data";
import { formatDate, kindSingular } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";
import type { ResourceKind } from "@/lib/types";

type Joined<T> = T | T[] | null;
const one = <T,>(v: Joined<T>): T | null => (Array.isArray(v) ? (v[0] ?? null) : v);

async function count(table: string, userId: string) {
  try {
    const { count: n } = await createClient().from(table).select("*", { count: "exact", head: true }).eq("user_id", userId);
    return n ?? 0;
  } catch {
    return 0;
  }
}

export default async function DashboardPage() {
  const user = await requireUser();
  const supabase = createClient();
  const [profile, levels, series] = await Promise.all([getProfile(user.id), getLevels(), getSeries()]);

  const level = levels.find((l) => l.id === profile?.level_id);
  const serie = series.find((s) => s.id === profile?.serie_id);

  const [subjects, viewsCount, downloadsCount, quizCount, favorites, recentViews, attempts] = await Promise.all([
    serie ? getSubjectsForSerie(serie.id) : Promise.resolve([]),
    count("resource_views", user.id),
    count("resource_downloads", user.id),
    count("quiz_attempts", user.id),
    supabase
      .from("favorites")
      .select("resource_id, resources(id, title, kind, subjects(slug))")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(5),
    supabase
      .from("resource_views")
      .select("id, viewed_at, resources(id, title, kind, subjects(slug))")
      .eq("user_id", user.id)
      .order("viewed_at", { ascending: false })
      .limit(5),
    supabase
      .from("quiz_attempts")
      .select("id, score, total, created_at, quizzes(title)")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(20),
  ]);

  type Res = { id: string; title: string; kind: ResourceKind; subjects: Joined<{ slug: string }> };
  const favs = ((favorites.data ?? []) as unknown as { resource_id: string; resources: Joined<Res> }[])
    .map((f) => one(f.resources))
    .filter((r): r is Res => !!r);
  const views = ((recentViews.data ?? []) as unknown as { id: number; viewed_at: string; resources: Joined<Res> }[])
    .map((v) => ({ id: v.id, at: v.viewed_at, res: one(v.resources) }))
    .filter((v): v is { id: number; at: string; res: Res } => !!v.res);
  const results = ((attempts.data ?? []) as unknown as { id: string; score: number; total: number; created_at: string; quizzes: Joined<{ title: string }> }[]).map(
    (a) => ({ ...a, title: one(a.quizzes)?.title ?? "Quiz", pct: Math.round((a.score / a.total) * 100) }),
  );
  const average = results.length ? Math.round(results.reduce((sum, r) => sum + r.pct, 0) / results.length) : null;

  const stats = [
    { label: "Cours consultés", value: viewsCount },
    { label: "Documents téléchargés", value: downloadsCount },
    { label: "Quiz réalisés", value: quizCount },
    { label: "Score moyen", value: average === null ? "—" : `${average} %` },
  ];

  const resHref = (r: Res) => `/documents/${r.id}`;

  return (
    <div className="space-y-12">
      <header>
        <h1 className="text-3xl font-extrabold sm:text-4xl">Bonjour {profile?.first_name ?? ""} !</h1>
        <p className="mt-2 text-ink-soft">
          {[level?.name, serie?.name, profile?.city, profile?.school].filter(Boolean).join(" · ") || "Complète ton profil pour personnaliser ton espace."}
        </p>
      </header>

      <dl className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label} className="card p-5">
            <dd className="font-display text-3xl font-extrabold text-brand">{s.value}</dd>
            <dt className="mt-1 text-sm text-ink-soft">{s.label}</dt>
          </div>
        ))}
      </dl>

      <section aria-labelledby="progression">
        <h2 id="progression" className="text-2xl font-bold">Ma progression</h2>
        {average === null ? (
          <p className="card mt-4 p-5 text-ink-soft">Tes résultats de quiz apparaîtront ici pour suivre tes progrès.</p>
        ) : (
          <div className="card mt-4 p-5">
            <p className="text-sm text-ink-soft">Moyenne sur tes {results.length} derniers quiz</p>
            <div className="mt-3 h-3 overflow-hidden rounded-pill bg-surface" role="progressbar" aria-valuenow={average} aria-valuemin={0} aria-valuemax={100} aria-label="Score moyen">
              <div className="h-full rounded-pill bg-brand" style={{ width: `${average}%` }} />
            </div>
            <ul className="mt-5 divide-y divide-line">
              {results.slice(0, 5).map((r) => (
                <li key={r.id} className="flex items-center justify-between gap-4 py-3">
                  <span className="font-semibold">{r.title}</span>
                  <span className="text-sm text-ink-soft">{r.score}/{r.total} · {formatDate(r.created_at)}</span>
                </li>
              ))}
            </ul>
            <Link href="/tableau-de-bord/resultats" className="btn-outline mt-4">Voir tout l'historique</Link>
          </div>
        )}
      </section>

      <section aria-labelledby="matieres">
        <h2 id="matieres" className="text-2xl font-bold">Mes matières</h2>
        {subjects.length === 0 ? (
          <p className="card mt-4 p-5 text-ink-soft">
            Choisis ta série dans <Link href="/tableau-de-bord/profil" className="font-semibold text-brand hover:underline">ton profil</Link> pour voir tes matières.
          </p>
        ) : (
          <ul className="mt-4 flex flex-wrap gap-3">
            {subjects.map((m) => (
              <li key={m.id}>
                <Link href={`/matieres/${m.slug}?serie=${serie?.slug}`} className="inline-flex min-h-[44px] items-center rounded-card border border-line bg-surface px-4 font-semibold transition hover:border-brand hover:text-brand">
                  {m.name}
                </Link>
              </li>
            ))}
          </ul>
        )}
      </section>

      <div className="grid gap-10 lg:grid-cols-2">
        <section aria-labelledby="favoris">
          <h2 id="favoris" className="text-2xl font-bold">Mes favoris</h2>
          {favs.length === 0 ? (
            <p className="card mt-4 p-5 text-ink-soft">Tu n'as pas encore de favori.</p>
          ) : (
            <ul className="card mt-4 divide-y divide-line">
              {favs.map((r) => (
                <li key={r.id}>
                  <Link href={resHref(r)} className="block p-4 hover:text-brand">
                    <span className="text-sm text-ink-soft">{kindSingular[r.kind]}</span>
                    <span className="block font-semibold">{r.title}</span>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </section>
        <section aria-labelledby="historique">
          <h2 id="historique" className="text-2xl font-bold">Derniers cours consultés</h2>
          {views.length === 0 ? (
            <p className="card mt-4 p-5 text-ink-soft">Les ressources que tu consultes apparaîtront ici.</p>
          ) : (
            <ul className="card mt-4 divide-y divide-line">
              {views.map((v) => (
                <li key={v.id}>
                  <Link href={resHref(v.res)} className="block p-4 hover:text-brand">
                    <span className="text-sm text-ink-soft">{kindSingular[v.res.kind]} · {formatDate(v.at)}</span>
                    <span className="block font-semibold">{v.res.title}</span>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  );
}
