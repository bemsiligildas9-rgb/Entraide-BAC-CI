import type { Metadata } from "next";
import { DashboardTabs } from "@/components/dashboard/DashboardTabs";
import { requireUser } from "@/lib/auth";

export const metadata: Metadata = { title: "Mon espace", robots: { index: false, follow: false } };

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  await requireUser();
  return (
    <div className="container-page py-10 sm:py-14">
      <DashboardTabs />
      <div className="pt-8">{children}</div>
    </div>
  );
}
