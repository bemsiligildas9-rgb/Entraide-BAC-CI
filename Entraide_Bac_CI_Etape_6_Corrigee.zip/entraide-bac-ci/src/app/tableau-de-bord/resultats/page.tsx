import type { Metadata } from "next";
import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { formatDate } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";

export const metadata: Metadata = { title: "Mes résultats" };

type Joined<T> = T | T[] | null;
const one = <T,>(v: Joined<T>): T | null => (Array.isArray(v) ? (v[0] ?? null) : v);

export default async function ResultsPage() {
  const user = await requireUser();
  const { data } = await createClient()
    .from("quiz_attempts")
    .select("id, quiz_id, score, total, created_at, quizzes(title, subjects(name))")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })
    .limit(100);

  type Row = { id: string; quiz_id: string; score: number; total: number; created_at: string; quizzes: Joined<{ title: string; subjects: Joined<{ name: string }> }> };
  const attempts = ((data ?? []) as unknown as Row[]).map((a) => {
    const quiz = one(a.quizzes);
    return { ...a, title: quiz?.title ?? "Quiz", subject: one(quiz?.subjects ?? null)?.name ?? "Autres", pct: Math.round((a.score / a.total) * 100) };
  });

  const bySubject = new Map<string, { sum: number; n: number }>();
  for (const a of attempts) {
    const cur = bySubject.get(a.subject) ?? { sum: 0, n: 0 };
    bySubject.set(a.subject, { sum: cur.sum + a.pct, n: cur.n + 1 });
  }
  const subjectStats = Array.from(bySubject.entries())
    .map(([name, { sum, n }]) => ({ name, n, avg: Math.round(sum / n) }))
    .sort((a, b) => a.avg - b.avg);

  return (
    <div className="max-w-3xl space-y-12">
      <section aria-labelledby="par-matiere">
        <h1 id="par-matiere" className="text-3xl font-extrabold">Ma progression par matière</h1>
        {subjectStats.length === 0 ? (
          <p className="card mt-5 p-5 text-ink-soft">
            Tu n'as pas encore passé de quiz. <Link href="/quiz" className="font-semibold text-brand hover:underline">Commence un quiz</Link> pour voir tes résultats ici.
          </p>
        ) : (
          <ul className="mt-5 space-y-4">
            {subjectStats.map((s) => (
              <li key={s.name} className="card p-4">
                <div className="flex items-baseline justify-between gap-3">
                  <span className="font-semibold">{s.name}</span>
                  <span className="text-sm text-ink-soft">{s.avg} % de moyenne · {s.n} quiz</span>
                </div>
                <div className="mt-2 h-2.5 overflow-hidden rounded-pill bg-surface" role="progressbar" aria-valuenow={s.avg} aria-valuemin={0} aria-valuemax={100} aria-label={`Moyenne en ${s.name}`}>
                  <div className="h-full rounded-pill bg-brand" style={{ width: `${s.avg}%` }} />
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>

      {attempts.length > 0 ? (
        <section aria-labelledby="historique">
          <h2 id="historique" className="text-2xl font-bold">Historique des résultats</h2>
          <ul className="card mt-5 divide-y divide-line">
            {attempts.map((a) => (
              <li key={a.id} className="flex flex-wrap items-center justify-between gap-3 p-4">
                <div>
                  <p className="font-semibold">{a.title}</p>
                  <p className="text-sm text-ink-soft">{a.subject} · {formatDate(a.created_at)}</p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-display text-lg font-bold text-brand">{a.score}/{a.total}</span>
                  <Link href={`/quiz/${a.quiz_id}`} className="btn-outline">Refaire</Link>
                </div>
              </li>
            ))}
          </ul>
        </section>
      ) : null}
    </div>
  );
}
