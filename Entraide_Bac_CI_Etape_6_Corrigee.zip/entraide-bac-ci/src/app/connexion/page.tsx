import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { AuthCard } from "@/components/auth/AuthCard";
import { ConnexionForm } from "@/components/auth/ConnexionForm";
import { getUser, safeRedirectPath } from "@/lib/auth";

export const metadata: Metadata = { title: "Connexion", robots: { index: false } };

export default async function ConnexionPage({ searchParams }: { searchParams: { redirige?: string; erreur?: string } }) {
  const target = safeRedirectPath(searchParams.redirige);
  if (await getUser()) redirect(target);
  return (
    <AuthCard title="Connexion" intro="Retrouve tes cours, tes favoris et tes résultats.">
      <ConnexionForm
        redirectTo={target}
        notice={searchParams.erreur === "lien" ? "Ce lien n'est plus valide. Connecte-toi, ou demande un nouveau lien." : undefined}
      />
    </AuthCard>
  );
}
