import type { Metadata } from "next";
import { AuthCard } from "@/components/auth/AuthCard";
import { PasswordForm } from "@/components/auth/PasswordForm";
import { requireUser } from "@/lib/auth";

export const metadata: Metadata = { title: "Nouveau mot de passe", robots: { index: false } };

export default async function ReinitialiserPage() {
  await requireUser();
  return (
    <AuthCard title="Nouveau mot de passe" intro="Choisis un mot de passe d'au moins 8 caractères.">
      <PasswordForm redirectAfter="/tableau-de-bord" />
    </AuthCard>
  );
}
