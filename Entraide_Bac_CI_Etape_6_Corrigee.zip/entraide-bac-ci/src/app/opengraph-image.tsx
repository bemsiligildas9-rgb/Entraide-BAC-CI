import { ImageResponse } from "next/og";

export const alt = "Entraide Bac CI — Réussir le Bac, ensemble !";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default function OpengraphImage() {
  return new ImageResponse(
    (
      <div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", justifyContent: "center", padding: "0 90px", background: "#10233F", color: "#FFFFFF" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 20 }}>
          <div style={{ width: 84, height: 84, borderRadius: 24, background: "#1769E0", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <div style={{ width: 44, height: 34, background: "#FFFFFF", borderRadius: 6 }} />
          </div>
          <div style={{ fontSize: 44, fontWeight: 700, display: "flex" }}>Entraide Bac CI</div>
        </div>
        <div style={{ fontSize: 88, fontWeight: 800, lineHeight: 1.05, marginTop: 48, display: "flex" }}>Réussir le Bac, ensemble !</div>
        <div style={{ fontSize: 32, color: "#22D3EE", marginTop: 36, display: "flex" }}>Cours, annales, quiz et entraide — By Gildas</div>
      </div>
    ),
    size,
  );
}
