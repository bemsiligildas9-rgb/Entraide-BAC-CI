import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { QuizRunner, type QuizQuestion } from "@/components/quiz/QuizRunner";
import { getUser } from "@/lib/auth";
import { UUID_RE } from "@/lib/files";
import { createClient } from "@/lib/supabase/server";

type Props = { params: { id: string } };
type Joined<T> = T | T[] | null;
const one = <T,>(v: Joined<T>): T | null => (Array.isArray(v) ? (v[0] ?? null) : v);

async function loadQuiz(id: string) {
  if (!UUID_RE.test(id)) return null;
  try {
    const { data } = await createClient()
      .from("quizzes")
      .select("id, title, description, subjects(name), levels(name), series(name)")
      .eq("id", id)
      .eq("is_published", true)
      .maybeSingle();
    return data as unknown as {
      id: string;
      title: string;
      description: string | null;
      subjects: Joined<{ name: string }>;
      levels: Joined<{ name: string }>;
      series: Joined<{ name: string }>;
    } | null;
  } catch {
    return null;
  }
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const quiz = await loadQuiz(params.id);
  return quiz ? { title: quiz.title, description: quiz.description?.slice(0, 160) } : {};
}

export default async function QuizPage({ params }: Props) {
  const quiz = await loadQuiz(params.id);
  if (!quiz) notFound();
  const user = await getUser();

  let questions: QuizQuestion[] = [];
  if (user) {
    const { data } = await createClient()
      .from("quiz_questions")
      .select("id, prompt, choices, multiple")
      .eq("quiz_id", quiz.id)
      .order("position")
      .order("id");
    questions = ((data ?? []) as { id: string; prompt: string; choices: unknown; multiple: boolean }[]).map((q) => ({
      id: q.id,
      prompt: q.prompt,
      choices: Array.isArray(q.choices) ? q.choices.map(String) : [],
      multiple: q.multiple,
    }));
  }

  const meta = [one(quiz.subjects)?.name, one(quiz.levels)?.name, one(quiz.series)?.name].filter(Boolean);

  return (
    <div className="container-page max-w-3xl py-12 sm:py-16">
      <nav aria-label="Fil d'Ariane" className="text-sm text-ink-soft">
        <Link href="/quiz" className="hover:text-brand">Quiz</Link>
      </nav>
      <h1 className="mt-4 text-3xl font-extrabold sm:text-4xl">{quiz.title}</h1>
      {meta.length > 0 ? <p className="mt-2 text-ink-soft">{meta.join(" · ")}</p> : null}
      {quiz.description ? <p className="mt-4 text-lg">{quiz.description}</p> : null}

      <div className="mt-8">
        {!user ? (
          <p className="card p-5">
            <Link href={`/connexion?redirige=${encodeURIComponent(`/quiz/${quiz.id}`)}`} className="font-semibold text-brand hover:underline">Connecte-toi</Link>{" "}
            ou <Link href="/inscription" className="font-semibold text-brand hover:underline">crée un compte</Link> pour passer ce quiz et enregistrer ton résultat.
          </p>
        ) : questions.length === 0 ? (
          <p className="card p-5 text-ink-soft">Ce quiz ne contient pas encore de question.</p>
        ) : (
          <QuizRunner quizId={quiz.id} questions={questions} />
        )}
      </div>
    </div>
  );
}
