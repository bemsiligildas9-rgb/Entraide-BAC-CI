import type { Metadata } from "next";
import Link from "next/link";
import { LibraryFilters } from "@/components/LibraryFilters";
import { getUser } from "@/lib/auth";
import { getSeries, getSubjects } from "@/lib/data";
import { str } from "@/lib/labels";
import { getLastScores, getQuizzes } from "@/lib/quiz";

export const metadata: Metadata = {
  title: "Quiz et exercices d'entraînement",
  description: "Entraîne-toi avec des QCM corrigés automatiquement, avec l'explication de chaque réponse.",
  alternates: { canonical: "/quiz" },
};

type SP = Record<string, string | string[] | undefined>;

export default async function QuizListPage({ searchParams }: { searchParams: SP }) {
  const v = { matiere: str(searchParams.matiere), serie: str(searchParams.serie) };
  const [user, subjects, series] = await Promise.all([getUser(), getSubjects(), getSeries()]);
  const quizzes = await getQuizzes({
    subjectId: subjects.find((s) => s.slug === v.matiere)?.id,
    serieId: series.find((s) => s.slug === v.serie)?.id,
  });
  const scores = await getLastScores(user?.id);

  return (
    <div className="container-page py-12 sm:py-16">
      <h1 className="text-4xl font-extrabold sm:text-5xl">Quiz d'entraînement</h1>
      <p className="mt-3 max-w-2xl text-lg text-ink-soft">
        Réponds aux questions, découvre ton score et lis l'explication de chaque réponse. Un compte est nécessaire pour enregistrer tes résultats.
      </p>
      <div className="mt-8">
        <LibraryFilters action="/quiz" values={v} subjects={subjects} series={series} showSearch={false} />
      </div>
      {quizzes.length === 0 ? (
        <p className="card mt-8 p-6 text-ink-soft">Aucun quiz n'est publié pour ces critères pour le moment.</p>
      ) : (
        <ul className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {quizzes.map((z) => {
            const last = scores.get(z.id);
            const meta = [z.subjects?.name, z.levels?.name, z.series?.name].filter(Boolean);
            return (
              <li key={z.id} className="card flex flex-col p-5">
                <h2 className="font-display text-lg font-bold leading-snug">{z.title}</h2>
                {meta.length > 0 ? <p className="mt-1 text-sm text-ink-soft">{meta.join(" · ")}</p> : null}
                {z.description ? <p className="mt-3 line-clamp-3 text-ink-soft">{z.description}</p> : null}
                <p className="mt-3 text-sm text-ink-soft">
                  {z.questionCount} question{z.questionCount > 1 ? "s" : ""}
                  {last ? ` · dernier score : ${last.score}/${last.total}` : ""}
                </p>
                <Link href={`/quiz/${z.id}`} className="btn-primary mt-4 self-start">{last ? "Refaire" : "Commencer"}</Link>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
