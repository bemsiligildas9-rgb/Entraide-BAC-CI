import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { AuthCard } from "@/components/auth/AuthCard";
import { InscriptionForm } from "@/components/auth/InscriptionForm";
import { getUser } from "@/lib/auth";
import { getLevels, getSeries } from "@/lib/data";

export const metadata: Metadata = { title: "Inscription", description: "Crée ton compte Entraide Bac CI pour suivre ta progression." };

export default async function InscriptionPage() {
  if (await getUser()) redirect("/tableau-de-bord");
  const [levels, series] = await Promise.all([getLevels(), getSeries()]);
  return (
    <AuthCard title="Créer mon compte" intro="Quelques informations pour adapter les ressources à ta classe et à ta série.">
      <InscriptionForm levels={levels} series={series} />
    </AuthCard>
  );
}
