-- =====================================================================
-- Entraide Bac CI — By Gildas : schéma de base de données (étape 1)
-- À exécuter dans Supabase > SQL Editor (ou via la CLI Supabase).
-- RLS (Row Level Security) est activée sur TOUTES les tables.
-- =====================================================================

create extension if not exists pgcrypto;

-- ---------- Types ----------
create type public.app_role as enum ('student', 'admin');
create type public.resource_kind as enum ('cours', 'exercice', 'corrige', 'annale', 'fiche', 'methode', 'video');
create type public.content_status as enum ('visible', 'pending', 'hidden');
create type public.post_kind as enum ('question', 'methode');

-- ---------- Fonctions utilitaires ----------
create function public.set_updated_at() returns trigger
language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

-- ---------- Rôles (jamais modifiables par un utilisateur) ----------
create table public.user_roles (
  user_id uuid primary key references auth.users (id) on delete cascade,
  role public.app_role not null default 'student'
);
alter table public.user_roles enable row level security;

-- Vérifie le droit administrateur côté base de données.
create function public.is_admin() returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.user_roles where user_id = auth.uid() and role = 'admin'
  );
$$;

-- Lecture : son propre rôle, ou tous si admin. AUCUNE politique d'écriture :
-- seuls le SQL Editor et la clé service_role (serveur) peuvent attribuer un rôle.
create policy "roles_select_own_or_admin" on public.user_roles
  for select to authenticated using (user_id = auth.uid() or public.is_admin());

-- ---------- Référentiels ----------
create table public.levels (
  id smallint generated always as identity primary key,
  slug text not null unique,
  name text not null,
  position smallint not null default 0
);

create table public.series (
  id smallint generated always as identity primary key,
  slug text not null unique,
  name text not null,
  exam text not null check (exam in ('BEPC', 'BAC')),
  position smallint not null default 0
);

create table public.subjects (
  id int generated always as identity primary key,
  slug text not null unique,
  name text not null,
  description text,
  icon text,
  position smallint not null default 0
);

create table public.serie_subjects (
  serie_id smallint not null references public.series (id) on delete cascade,
  subject_id int not null references public.subjects (id) on delete cascade,
  primary key (serie_id, subject_id)
);

create table public.chapters (
  id bigint generated always as identity primary key,
  subject_id int not null references public.subjects (id) on delete cascade,
  serie_id smallint references public.series (id) on delete cascade,
  level_id smallint references public.levels (id) on delete set null,
  title text not null check (char_length(title) between 2 and 200),
  position smallint not null default 0,
  created_at timestamptz not null default now()
);
create index chapters_subject_idx on public.chapters (subject_id, serie_id, position);

-- ---------- Profils élèves ----------
create table public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  first_name text not null check (char_length(first_name) between 1 and 80),
  last_name text not null check (char_length(last_name) between 1 and 80),
  school text check (char_length(school) <= 120),
  city text check (char_length(city) <= 80),
  level_id smallint references public.levels (id) on delete set null,
  serie_id smallint references public.series (id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger profiles_updated before update on public.profiles
  for each row execute function public.set_updated_at();

-- Création automatique du profil et du rôle "student" à l'inscription.
-- Le rôle n'est JAMAIS lu depuis les métadonnées envoyées par l'utilisateur.
create function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, first_name, last_name, school, city, level_id, serie_id)
  values (
    new.id,
    left(coalesce(nullif(trim(new.raw_user_meta_data ->> 'first_name'), ''), 'Élève'), 80),
    left(coalesce(nullif(trim(new.raw_user_meta_data ->> 'last_name'), ''), '-'), 80),
    nullif(left(trim(new.raw_user_meta_data ->> 'school'), 120), ''),
    nullif(left(trim(new.raw_user_meta_data ->> 'city'), 80), ''),
    (select id from public.levels where slug = new.raw_user_meta_data ->> 'level'),
    (select id from public.series where slug = new.raw_user_meta_data ->> 'serie')
  );
  insert into public.user_roles (user_id, role) values (new.id, 'student');
  return new;
end $$;

create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------- Ressources (cours, exercices, corrigés, annales, fiches, vidéos) ----------
create table public.resources (
  id uuid primary key default gen_random_uuid(),
  kind public.resource_kind not null,
  title text not null check (char_length(title) between 3 and 200),
  description text check (char_length(description) <= 2000),
  subject_id int not null references public.subjects (id) on delete restrict,
  level_id smallint references public.levels (id) on delete set null,
  serie_id smallint references public.series (id) on delete set null,
  chapter_id bigint references public.chapters (id) on delete set null,
  file_path text,          -- chemin dans le bucket privé "documents"
  file_size bigint,
  video_url text check (video_url is null or video_url ~* '^https://'),
  exam_year smallint check (exam_year between 1960 and 2100),  -- annales uniquement
  epreuve text,            -- type d'épreuve (annales)
  is_published boolean not null default false,
  published_at timestamptz not null default now(),
  created_by uuid references auth.users (id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  search tsvector generated always as (
    to_tsvector('french'::regconfig, coalesce(title, '') || ' ' || coalesce(description, ''))
  ) stored,
  check (file_path is not null or video_url is not null)
);
create index resources_search_idx on public.resources using gin (search);
create index resources_filter_idx on public.resources (subject_id, serie_id, kind, published_at desc);
create index resources_annales_idx on public.resources (exam_year) where kind = 'annale';
create trigger resources_updated before update on public.resources
  for each row execute function public.set_updated_at();

-- ---------- Quiz ----------
create table public.quizzes (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 3 and 200),
  description text,
  subject_id int references public.subjects (id) on delete set null,
  level_id smallint references public.levels (id) on delete set null,
  serie_id smallint references public.series (id) on delete set null,
  is_published boolean not null default false,
  created_by uuid references auth.users (id) on delete set null,
  created_at timestamptz not null default now()
);

create table public.quiz_questions (
  id uuid primary key default gen_random_uuid(),
  quiz_id uuid not null references public.quizzes (id) on delete cascade,
  position smallint not null default 0,
  prompt text not null,
  choices jsonb not null check (jsonb_typeof(choices) = 'array' and jsonb_array_length(choices) between 2 and 8),
  correct_indexes int[] not null check (cardinality(correct_indexes) >= 1),
  explanation text
);
create index quiz_questions_quiz_idx on public.quiz_questions (quiz_id, position);

create table public.quiz_attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  quiz_id uuid not null references public.quizzes (id) on delete cascade,
  score int not null check (score >= 0),
  total int not null check (total > 0),
  answers jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  check (score <= total)
);
create index quiz_attempts_user_idx on public.quiz_attempts (user_id, created_at desc);

-- ---------- Activité de l'élève ----------
create table public.favorites (
  user_id uuid not null references auth.users (id) on delete cascade,
  resource_id uuid not null references public.resources (id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, resource_id)
);

create table public.resource_views (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users (id) on delete cascade,
  resource_id uuid not null references public.resources (id) on delete cascade,
  viewed_at timestamptz not null default now()
);
create index resource_views_user_idx on public.resource_views (user_id, viewed_at desc);

create table public.resource_downloads (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users (id) on delete cascade,
  resource_id uuid not null references public.resources (id) on delete cascade,
  downloaded_at timestamptz not null default now()
);
create index resource_downloads_user_idx on public.resource_downloads (user_id, downloaded_at desc);

-- ---------- Annonces et notifications ----------
create table public.announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 3 and 200),
  body text not null check (char_length(body) <= 3000),
  is_active boolean not null default true,
  created_by uuid references auth.users (id) on delete set null,
  created_at timestamptz not null default now()
);

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  title text not null,
  body text,
  link text,
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index notifications_user_idx on public.notifications (user_id, created_at desc);

-- ---------- Communauté ----------
create table public.posts (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references auth.users (id) on delete cascade,
  kind public.post_kind not null default 'question',
  title text not null check (char_length(title) between 5 and 200),
  body text not null check (char_length(body) between 5 and 5000),
  subject_id int references public.subjects (id) on delete set null,
  status public.content_status not null default 'visible',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  search tsvector generated always as (
    to_tsvector('french'::regconfig, coalesce(title, '') || ' ' || coalesce(body, ''))
  ) stored
);
create index posts_search_idx on public.posts using gin (search);
create index posts_recent_idx on public.posts (created_at desc);
create trigger posts_updated before update on public.posts
  for each row execute function public.set_updated_at();

create table public.comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts (id) on delete cascade,
  author_id uuid not null references auth.users (id) on delete cascade,
  body text not null check (char_length(body) between 2 and 5000),
  is_answer boolean not null default false,
  status public.content_status not null default 'visible',
  created_at timestamptz not null default now()
);
create index comments_post_idx on public.comments (post_id, created_at);

create table public.post_reactions (
  user_id uuid not null references auth.users (id) on delete cascade,
  post_id uuid not null references public.posts (id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, post_id)
);

create table public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references auth.users (id) on delete cascade,
  post_id uuid references public.posts (id) on delete cascade,
  comment_id uuid references public.comments (id) on delete cascade,
  reason text not null check (char_length(reason) between 3 and 500),
  resolved boolean not null default false,
  created_at timestamptz not null default now(),
  check ((post_id is not null) <> (comment_id is not null))
);

-- Seul un administrateur peut changer le statut de modération d'un contenu.
create function public.guard_status_change() returns trigger
language plpgsql as $$
begin
  if new.status is distinct from old.status and not public.is_admin() then
    raise exception 'Action non autorisée';
  end if;
  return new;
end $$;
create trigger posts_guard before update on public.posts
  for each row execute function public.guard_status_change();
create trigger comments_guard before update on public.comments
  for each row execute function public.guard_status_change();

-- ---------- Réglages du site (contacts et réseaux, modifiables depuis l'admin) ----------
create table public.site_settings (
  key text primary key,
  value jsonb not null default '""'::jsonb,
  updated_at timestamptz not null default now()
);
create trigger site_settings_updated before update on public.site_settings
  for each row execute function public.set_updated_at();

-- =====================================================================
-- RLS : activation + politiques pour chaque table
-- =====================================================================
alter table public.levels enable row level security;
alter table public.series enable row level security;
alter table public.subjects enable row level security;
alter table public.serie_subjects enable row level security;
alter table public.chapters enable row level security;
alter table public.profiles enable row level security;
alter table public.resources enable row level security;
alter table public.quizzes enable row level security;
alter table public.quiz_questions enable row level security;
alter table public.quiz_attempts enable row level security;
alter table public.favorites enable row level security;
alter table public.resource_views enable row level security;
alter table public.resource_downloads enable row level security;
alter table public.announcements enable row level security;
alter table public.notifications enable row level security;
alter table public.posts enable row level security;
alter table public.comments enable row level security;
alter table public.post_reactions enable row level security;
alter table public.reports enable row level security;
alter table public.site_settings enable row level security;

-- Référentiels : lecture publique, écriture admin
do $$
declare t text;
begin
  foreach t in array array['levels','series','subjects','serie_subjects','chapters','site_settings'] loop
    execute format('create policy "%1$s_read_all" on public.%1$s for select to anon, authenticated using (true)', t);
    execute format('create policy "%1$s_admin_write" on public.%1$s for all to authenticated using (public.is_admin()) with check (public.is_admin())', t);
  end loop;
end $$;

-- Profils : chacun lit et modifie le sien (pas de colonne de rôle ici) ; l'admin lit tout
create policy "profiles_select" on public.profiles
  for select to authenticated using (id = auth.uid() or public.is_admin());
create policy "profiles_update_own" on public.profiles
  for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

-- Ressources : publiques si publiées, tout pour l'admin
create policy "resources_read_published" on public.resources
  for select to anon, authenticated
  using ((is_published and published_at <= now()) or public.is_admin());
create policy "resources_admin_write" on public.resources
  for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- Quiz
create policy "quizzes_read_published" on public.quizzes
  for select to anon, authenticated using (is_published or public.is_admin());
create policy "quizzes_admin_write" on public.quizzes
  for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "quiz_questions_read" on public.quiz_questions
  for select to anon, authenticated
  using (public.is_admin() or exists (select 1 from public.quizzes q where q.id = quiz_id and q.is_published));
create policy "quiz_questions_admin_write" on public.quiz_questions
  for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "attempts_select" on public.quiz_attempts
  for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy "attempts_insert_own" on public.quiz_attempts
  for insert to authenticated with check (user_id = auth.uid());

-- Activité personnelle
create policy "favorites_own" on public.favorites
  for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "views_select" on public.resource_views
  for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy "views_insert_own" on public.resource_views
  for insert to authenticated with check (user_id = auth.uid());
create policy "downloads_select" on public.resource_downloads
  for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy "downloads_insert_own" on public.resource_downloads
  for insert to authenticated with check (user_id = auth.uid());

-- Annonces
create policy "announcements_read_active" on public.announcements
  for select to anon, authenticated using (is_active or public.is_admin());
create policy "announcements_admin_write" on public.announcements
  for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- Notifications : chacun lit/marque les siennes ; seul l'admin en crée
create policy "notifications_select_own" on public.notifications
  for select to authenticated using (user_id = auth.uid());
create policy "notifications_update_own" on public.notifications
  for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "notifications_admin_insert" on public.notifications
  for insert to authenticated with check (public.is_admin());

-- Communauté
create policy "posts_read" on public.posts
  for select to anon, authenticated
  using (status = 'visible' or author_id = auth.uid() or public.is_admin());
create policy "posts_insert_own" on public.posts
  for insert to authenticated with check (author_id = auth.uid() and status = 'visible');
create policy "posts_update_own_or_admin" on public.posts
  for update to authenticated
  using (author_id = auth.uid() or public.is_admin())
  with check (author_id = auth.uid() or public.is_admin());
create policy "posts_delete_own_or_admin" on public.posts
  for delete to authenticated using (author_id = auth.uid() or public.is_admin());

create policy "comments_read" on public.comments
  for select to anon, authenticated
  using (status = 'visible' or author_id = auth.uid() or public.is_admin());
create policy "comments_insert_own" on public.comments
  for insert to authenticated with check (author_id = auth.uid() and status = 'visible');
create policy "comments_update_own_or_admin" on public.comments
  for update to authenticated
  using (author_id = auth.uid() or public.is_admin())
  with check (author_id = auth.uid() or public.is_admin());
create policy "comments_delete_own_or_admin" on public.comments
  for delete to authenticated using (author_id = auth.uid() or public.is_admin());

create policy "reactions_read" on public.post_reactions
  for select to anon, authenticated using (true);
create policy "reactions_own_write" on public.post_reactions
  for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy "reports_insert_own" on public.reports
  for insert to authenticated with check (reporter_id = auth.uid());
create policy "reports_admin_read" on public.reports
  for select to authenticated using (public.is_admin());
create policy "reports_admin_update" on public.reports
  for update to authenticated using (public.is_admin()) with check (public.is_admin());

-- =====================================================================
-- Stockage des documents : bucket PRIVÉ "documents"
-- Lecture réservée aux utilisateurs connectés ; écriture réservée à l'admin.
-- =====================================================================
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('documents', 'documents', false, 52428800, array['application/pdf', 'image/png', 'image/jpeg', 'image/webp'])
on conflict (id) do nothing;

create policy "documents_read_authenticated" on storage.objects
  for select to authenticated using (bucket_id = 'documents');
create policy "documents_admin_insert" on storage.objects
  for insert to authenticated with check (bucket_id = 'documents' and public.is_admin());
create policy "documents_admin_update" on storage.objects
  for update to authenticated using (bucket_id = 'documents' and public.is_admin());
create policy "documents_admin_delete" on storage.objects
  for delete to authenticated using (bucket_id = 'documents' and public.is_admin());
