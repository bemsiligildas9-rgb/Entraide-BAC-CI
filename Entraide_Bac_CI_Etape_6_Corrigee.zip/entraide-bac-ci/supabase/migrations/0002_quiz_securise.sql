-- =====================================================================
-- Étape 4 : quiz sécurisés
-- À exécuter APRÈS 0001_schema.sql.
--  - Les bonnes réponses et explications passent dans une table réservée à l'admin.
--  - La correction se fait côté serveur (fonction submit_quiz_attempt) : un élève ne peut
--    ni lire les réponses avant d'avoir répondu, ni s'attribuer un faux score.
-- =====================================================================

alter table public.quiz_questions add column if not exists multiple boolean not null default false;

create table public.quiz_answer_keys (
  question_id uuid primary key references public.quiz_questions (id) on delete cascade,
  correct_indexes int[] not null check (cardinality(correct_indexes) >= 1),
  explanation text
);
alter table public.quiz_answer_keys enable row level security;

create policy "answer_keys_admin_all" on public.quiz_answer_keys
  for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- Reprise d'éventuelles données existantes, puis retrait des colonnes sensibles
insert into public.quiz_answer_keys (question_id, correct_indexes, explanation)
select id, correct_indexes, explanation from public.quiz_questions
on conflict do nothing;

update public.quiz_questions set multiple = true where cardinality(correct_indexes) > 1;

alter table public.quiz_questions drop column correct_indexes;
alter table public.quiz_questions drop column explanation;

-- Les scores ne peuvent plus être insérés directement par les élèves
drop policy if exists "attempts_insert_own" on public.quiz_attempts;

-- Correction automatique : une question est juste si l'ensemble des réponses cochées
-- correspond exactement à l'ensemble des bonnes réponses.
create function public.submit_quiz_attempt(p_quiz_id uuid, p_answers jsonb)
returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  v_uid uuid := auth.uid();
  v_score int := 0;
  v_total int := 0;
  v_results jsonb := '[]'::jsonb;
  v_given int[];
  v_correct int[];
  v_ok boolean;
  v_attempt uuid;
  q record;
begin
  if v_uid is null then
    raise exception 'Connexion requise';
  end if;
  if p_answers is null or jsonb_typeof(p_answers) <> 'object' then
    raise exception 'Réponses invalides';
  end if;
  if not exists (select 1 from public.quizzes where id = p_quiz_id and is_published) then
    raise exception 'Quiz introuvable';
  end if;

  for q in
    select qq.id, k.correct_indexes, k.explanation
    from public.quiz_questions qq
    join public.quiz_answer_keys k on k.question_id = qq.id
    where qq.quiz_id = p_quiz_id
    order by qq.position, qq.id
  loop
    v_total := v_total + 1;

    if jsonb_typeof(p_answers -> q.id::text) = 'array' then
      select coalesce(array_agg(distinct t.x::int order by t.x::int), '{}'::int[])
        into v_given
        from jsonb_array_elements_text(p_answers -> q.id::text) as t(x)
        where t.x ~ '^[0-9]{1,2}$';
    else
      v_given := '{}'::int[];
    end if;

    v_correct := array(select distinct i from unnest(q.correct_indexes) as i order by i);
    v_ok := v_given = v_correct;
    if v_ok then
      v_score := v_score + 1;
    end if;

    v_results := v_results || jsonb_build_object(
      'question_id', q.id,
      'given', to_jsonb(v_given),
      'correct', to_jsonb(v_correct),
      'ok', v_ok,
      'explanation', q.explanation
    );
  end loop;

  if v_total = 0 then
    raise exception 'Ce quiz ne contient aucune question';
  end if;

  insert into public.quiz_attempts (user_id, quiz_id, score, total, answers)
  values (v_uid, p_quiz_id, v_score, v_total, v_results)
  returning id into v_attempt;

  return jsonb_build_object('attempt_id', v_attempt, 'score', v_score, 'total', v_total, 'results', v_results);
end $$;

revoke all on function public.submit_quiz_attempt(uuid, jsonb) from public, anon;
grant execute on function public.submit_quiz_attempt(uuid, jsonb) to authenticated;
