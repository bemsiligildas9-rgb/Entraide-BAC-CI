-- =====================================================================
-- Étape 6 : communauté, contact, notifications
-- À exécuter APRÈS 0001 et 0002.
-- =====================================================================

-- ---------- Profils publics : prénom + initiale du nom uniquement ----------
-- Vue exécutée avec les droits du propriétaire (voulu) : elle n'expose que le nom d'affichage,
-- jamais l'établissement, la ville ou l'identifiant de connexion. Supabase peut signaler cette
-- vue dans ses "Security Advisors" : c'est attendu ici.
create view public.public_profiles as
  select id, first_name || ' ' || left(last_name, 1) || '.' as display_name
  from public.profiles;
grant select on public.public_profiles to anon, authenticated;

-- ---------- Un seul signalement par personne et par contenu ----------
create unique index reports_unique_post on public.reports (reporter_id, post_id) where post_id is not null;
create unique index reports_unique_comment on public.reports (reporter_id, comment_id) where comment_id is not null;

-- ---------- Limites anti-spam sur la communauté ----------
create function public.limit_community_activity() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if tg_table_name = 'posts' then
    if (select count(*) from public.posts where author_id = new.author_id and created_at > now() - interval '1 hour') >= 10 then
      raise exception 'Limite atteinte : 10 publications par heure. Réessaie plus tard.';
    end if;
  else
    if (select count(*) from public.comments where author_id = new.author_id and created_at > now() - interval '1 hour') >= 30 then
      raise exception 'Limite atteinte : 30 commentaires par heure. Réessaie plus tard.';
    end if;
  end if;
  return new;
end $$;
create trigger posts_rate_limit before insert on public.posts for each row execute function public.limit_community_activity();
create trigger comments_rate_limit before insert on public.comments for each row execute function public.limit_community_activity();

-- ---------- Notification de l'auteur quand quelqu'un répond ----------
create function public.notify_post_author() returns trigger
language plpgsql security definer set search_path = '' as $$
declare
  v_author uuid;
  v_title text;
begin
  select author_id, title into v_author, v_title from public.posts where id = new.post_id;
  if v_author is not null and v_author <> new.author_id then
    insert into public.notifications (user_id, title, body, link)
    values (v_author, 'Nouvelle réponse à ta publication', left(v_title, 120), '/communaute/' || new.post_id);
  end if;
  return new;
end $$;
create trigger comments_notify after insert on public.comments for each row execute function public.notify_post_author();

-- ---------- Messages de contact ----------
create table public.contact_messages (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 2 and 100),
  email text not null check (char_length(email) between 5 and 200 and email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'),
  message text not null check (char_length(message) between 10 and 4000),
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);
create index contact_messages_recent_idx on public.contact_messages (created_at desc);
alter table public.contact_messages enable row level security;

-- Tout visiteur peut écrire (formulaire public), seul l'admin peut lire, gérer ou supprimer.
create policy "contact_insert_anyone" on public.contact_messages
  for insert to anon, authenticated with check (is_read = false);
create policy "contact_admin_select" on public.contact_messages
  for select to authenticated using (public.is_admin());
create policy "contact_admin_update" on public.contact_messages
  for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "contact_admin_delete" on public.contact_messages
  for delete to authenticated using (public.is_admin());

-- Anti-inondation : 20 messages maximum sur 10 minutes pour l'ensemble du site.
create function public.limit_contact_flood() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if (select count(*) from public.contact_messages where created_at > now() - interval '10 minutes') >= 20 then
    raise exception 'Trop de messages en ce moment. Réessaie dans quelques minutes.';
  end if;
  return new;
end $$;
create trigger contact_flood before insert on public.contact_messages for each row execute function public.limit_contact_flood();
