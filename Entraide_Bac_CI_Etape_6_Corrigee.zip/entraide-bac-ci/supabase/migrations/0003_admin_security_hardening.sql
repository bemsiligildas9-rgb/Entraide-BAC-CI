-- =====================================================================
-- Entraide Bac CI — Étape 5 : protections de sécurité conservées à l'étape 6
-- À exécuter après 0001_schema.sql et 0002_quiz_securise.sql.
-- =====================================================================

-- Bucket documents privé : les élèves ne lisent que les fichiers rattachés
-- à une ressource publiée dont la date de publication est atteinte.
drop policy if exists "documents_read_authenticated" on storage.objects;
drop policy if exists "documents_read_published_resources" on storage.objects;

create policy "documents_read_published_resources"
  on storage.objects
  for select to authenticated
  using (
    bucket_id = 'documents'
    and exists (
      select 1
      from public.resources r
      where r.file_path = storage.objects.name
        and r.is_published = true
        and r.published_at <= now()
    )
  );

-- Seules les coordonnées publiques du site peuvent être lues sans privilège.
drop policy if exists "site_settings_read_all" on public.site_settings;
drop policy if exists "site_settings_read_public_keys" on public.site_settings;

create policy "site_settings_read_public_keys"
  on public.site_settings
  for select to anon, authenticated
  using (
    key in (
      'contact_email',
      'whatsapp_url',
      'facebook_url',
      'tiktok_url',
      'instagram_url'
    )
  );

-- Ne jamais ajouter de politique permettant aux élèves d'écrire des scores
-- ou de modifier les rôles. La clé service_role reste exclusivement serveur.
