-- Données de base : structure scolaire uniquement. AUCUN faux sujet, cours ou statistique.
-- L'administrateur pourra ajuster les matières par série depuis l'espace admin (étape 5).

insert into public.levels (slug, name, position) values
  ('6eme', '6ème', 1), ('5eme', '5ème', 2), ('4eme', '4ème', 3), ('3eme', '3ème', 4),
  ('seconde', 'Seconde', 5), ('premiere', 'Première', 6), ('terminale', 'Terminale', 7);

insert into public.series (slug, name, exam, position) values
  ('bepc', 'BEPC', 'BEPC', 1),
  ('a', 'BAC A', 'BAC', 2), ('c', 'BAC C', 'BAC', 3), ('d', 'BAC D', 'BAC', 4),
  ('e', 'BAC E', 'BAC', 5), ('f', 'BAC F', 'BAC', 6), ('g', 'BAC G', 'BAC', 7);

insert into public.subjects (slug, name, position) values
  ('mathematiques', 'Mathématiques', 1),
  ('physique-chimie', 'Physique-Chimie', 2),
  ('svt', 'Sciences de la Vie et de la Terre (SVT)', 3),
  ('francais', 'Français', 4),
  ('anglais', 'Anglais', 5),
  ('philosophie', 'Philosophie', 6),
  ('histoire-geographie', 'Histoire-Géographie', 7),
  ('edhc', 'Éducation aux Droits de l''Homme et à la Citoyenneté (EDHC)', 8);

-- Matières par série (point de départ à compléter par l'administrateur)
insert into public.serie_subjects (serie_id, subject_id)
select s.id, m.id
from (values
  ('bepc', 'mathematiques'), ('bepc', 'physique-chimie'), ('bepc', 'svt'), ('bepc', 'francais'),
  ('bepc', 'anglais'), ('bepc', 'histoire-geographie'), ('bepc', 'edhc'),
  ('a', 'francais'), ('a', 'philosophie'), ('a', 'anglais'), ('a', 'histoire-geographie'), ('a', 'mathematiques'),
  ('c', 'mathematiques'), ('c', 'physique-chimie'), ('c', 'svt'), ('c', 'francais'),
  ('c', 'anglais'), ('c', 'philosophie'), ('c', 'histoire-geographie'),
  ('d', 'mathematiques'), ('d', 'physique-chimie'), ('d', 'svt'), ('d', 'francais'),
  ('d', 'anglais'), ('d', 'philosophie'), ('d', 'histoire-geographie'),
  ('e', 'mathematiques'), ('e', 'physique-chimie'), ('e', 'francais'),
  ('e', 'anglais'), ('e', 'philosophie'), ('e', 'histoire-geographie'),
  ('f', 'mathematiques'), ('f', 'francais'), ('f', 'anglais'), ('f', 'philosophie'),
  ('g', 'mathematiques'), ('g', 'francais'), ('g', 'anglais'), ('g', 'philosophie'), ('g', 'histoire-geographie')
) as v(serie, subject)
join public.series s on s.slug = v.serie
join public.subjects m on m.slug = v.subject;

-- Réglages de contact : vides à dessein (aucun numéro ni e-mail inventé).
insert into public.site_settings (key, value) values
  ('contact_email', '""'), ('whatsapp_url', '""'), ('facebook_url', '""'),
  ('tiktok_url', '""'), ('instagram_url', '""')
on conflict (key) do nothing;
